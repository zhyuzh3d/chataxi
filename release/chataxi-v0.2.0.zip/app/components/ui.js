(function (app) {
  "use strict";
  var utils = app.utils;
  var toastTimer = null;
  var modal = null;

  function icon(name) { return '<i class="fa-solid fa-' + utils.escapeHtml(name) + '" aria-hidden="true"></i>'; }
  function avatar(name, color, className) {
    var label = Array.from(String(name || "AI").trim()).slice(0, 2).join("").toUpperCase() || "AI";
    color = /^#[0-9a-f]{6}$/i.test(color || "") ? color : "#656c58";
    return '<span class="avatar ' + utils.escapeHtml(className || "") + '" style="background:' + color + '" aria-hidden="true">' + utils.escapeHtml(label) + '</span>';
  }
  function toast(message, duration) {
    var root = document.getElementById("toastRoot");
    clearTimeout(toastTimer);
    root.innerHTML = '<div class="toast" role="status">' + utils.escapeHtml(message) + '</div>';
    toastTimer = setTimeout(function () { root.innerHTML = ""; }, duration || 3200);
  }
  function action(fn) {
    return function () {
      var result;
      try { result = fn.apply(this, arguments); }
      catch (error) { toast(utils.cleanError(error), 5000); return; }
      return Promise.resolve(result).catch(function (error) { toast(utils.cleanError(error), 5000); });
    };
  }
  function closeModal(force, submitted) {
    if (!modal || (modal.busy && force !== true)) return;
    var previous = modal;
    modal = null;
    document.getElementById("modalRoot").innerHTML = "";
    document.getElementById("appShell").removeAttribute("aria-hidden");
    document.body.classList.remove("modal-open");
    document.removeEventListener("keydown", previous.keydown, true);
    if (previous.focus && previous.focus.isConnected) previous.focus.focus();
    if (!submitted && previous.options.onDismiss) previous.options.onDismiss();
  }
  function openModal(options) {
    closeModal(true);
    var root = document.getElementById("modalRoot");
    var current = { options: options, focus: document.activeElement, busy: false };
    modal = current;
    root.innerHTML = '<div class="modal-backdrop"><section class="modal-sheet" role="dialog" aria-modal="true" aria-labelledby="modalTitle" tabindex="-1">' +
      '<div class="modal-handle" aria-hidden="true"></div><header class="modal-head"><div><p class="eyebrow">' + utils.escapeHtml(options.eyebrow || "CHATAXI") + '</p><h2 id="modalTitle">' + utils.escapeHtml(options.title) + '</h2></div><button class="icon-button" type="button" data-close-modal aria-label="关闭">' + icon("xmark") + '</button></header>' +
      '<form id="modalForm"><div class="modal-body">' + options.html + '</div><div class="modal-actions">' +
      (options.cancelText === null ? '' : '<button class="button secondary" type="button" data-close-modal>' + utils.escapeHtml(options.cancelText || "取消") + '</button>') +
      '<button class="button ' + (options.danger ? 'danger' : 'primary') + '" id="modalSubmit" type="submit">' + utils.escapeHtml(options.submitText || "保存") + '</button></div></form></section></div>';
    document.body.classList.add("modal-open");
    document.getElementById("appShell").setAttribute("aria-hidden", "true");
    var form = document.getElementById("modalForm");
    form.querySelectorAll("[name]").forEach(function (field) { if (!field.id) field.id = "field-" + field.name.replace(/[^a-zA-Z0-9_-]/g, "-"); });
    root.querySelectorAll("[data-close-modal]").forEach(function (button) { button.addEventListener("click", function () { closeModal(); }); });
    root.querySelector(".modal-backdrop").addEventListener("click", function (event) { if (event.target === event.currentTarget) closeModal(); });
    current.keydown = function (event) {
      if (event.key === "Escape") { event.preventDefault(); closeModal(); }
      if (event.key !== "Tab") return;
      var focusable = Array.prototype.filter.call(root.querySelectorAll('button, input, select, textarea, summary, [tabindex="0"]'), function (item) { return !item.disabled && item.getClientRects().length; });
      if (!focusable.length) { event.preventDefault(); return; }
      var first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || focusable.indexOf(document.activeElement) < 0)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || focusable.indexOf(document.activeElement) < 0)) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", current.keydown, true);
    form.addEventListener("submit", async function (event) {
      event.preventDefault();
      if (current.busy) return;
      current.busy = true;
      var buttons = root.querySelectorAll(".modal-actions button, [data-close-modal]");
      buttons.forEach(function (button) { button.disabled = true; });
      var submit = form.querySelector('[type="submit"]');
      var label = submit.textContent; submit.textContent = "正在保存…";
      try {
        var value = await options.onSubmit(form);
        if (value !== false && modal === current) {
          closeModal(true, true);
          if (options.onSuccess) await options.onSuccess(value);
        }
      } catch (error) {
        if (modal !== current) { toast(utils.cleanError(error), 5000); return; }
        var existing = form.querySelector(".form-error");
        if (!existing) { existing = document.createElement("div"); existing.className = "error-box form-error"; existing.setAttribute("role", "alert"); existing.tabIndex = -1; form.querySelector(".modal-body").prepend(existing); }
        existing.textContent = utils.cleanError(error); existing.focus();
      } finally {
        current.busy = false; submit.textContent = label;
        buttons.forEach(function (button) { button.disabled = false; });
      }
    });
    // Focus the dialog heading without raising the mobile keyboard before the user chooses a field.
    root.querySelector(".modal-sheet").focus();
    return form;
  }
  function confirm(options) {
    return new Promise(function (resolve) {
      openModal({ title: options.title || "请确认", html: '<p class="dialog-copy">' + utils.escapeHtml(options.message || "确定继续吗？") + '</p>', submitText: options.confirmText || "确定", danger: Boolean(options.danger), onDismiss: function () { resolve(false); }, onSubmit: function () { return true; }, onSuccess: function () { resolve(true); } });
    });
  }
  function empty(iconName, title, text, actionHtml) {
    return '<div class="empty-state"><div class="empty-state-inner"><div class="empty-icon">' + icon(iconName) + '</div><h2>' + utils.escapeHtml(title) + '</h2><p>' + utils.escapeHtml(text) + '</p>' + (actionHtml || "") + '</div></div>';
  }
  function pageHeader(title, subtitle, actions) {
    document.getElementById("pageTitle").textContent = title;
    document.getElementById("pageSubtitle").textContent = subtitle;
    document.getElementById("topbarActions").innerHTML = actions || "";
  }
  function search(placeholder) {
    return '<label class="search-field">' + icon("magnifying-glass") + '<input type="search" id="listSearch" aria-label="' + utils.escapeHtml(placeholder) + '" placeholder="' + utils.escapeHtml(placeholder) + '"></label>';
  }
  app.components = { icon: icon, avatar: avatar, toast: toast, action: action, openModal: openModal, closeModal: closeModal, confirm: confirm, empty: empty, pageHeader: pageHeader, search: search };
})(window.chataxi);
