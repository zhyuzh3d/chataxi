(function (app) {
  "use strict";
  app.services = app.services || {};
  app.services.catalog = {
    llmPresets: [
      { id: "llmserver", name: "llmserver（局域网）", family: "llmserver", apiStyle: "openai-responses", endpoint: "http://192.168.1.2:4815/v1/responses", model: "", note: "推荐：统一模型、权限和计费" },
      { id: "openai", name: "OpenAI", family: "openai", apiStyle: "openai-responses", endpoint: "https://api.openai.com/v1/responses", model: "", note: "Responses API" },
      { id: "deepseek", name: "DeepSeek", family: "deepseek", apiStyle: "openai-chat", endpoint: "https://api.deepseek.com/chat/completions", model: "deepseek-chat", note: "兼容 Chat Completions" },
      { id: "xai", name: "xAI / Grok", family: "xai", apiStyle: "openai-chat", endpoint: "https://api.x.ai/v1/chat/completions", model: "", note: "兼容 Chat Completions" },
      { id: "anthropic", name: "Claude", family: "anthropic", apiStyle: "anthropic-messages", endpoint: "https://api.anthropic.com/v1/messages", model: "", note: "Anthropic Messages" },
      { id: "gemini", name: "Gemini", family: "gemini", apiStyle: "gemini-generate-content", endpoint: "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent", model: "", note: "Gemini GenerateContent" },
      { id: "kimi", name: "Kimi / Moonshot", family: "kimi", apiStyle: "openai-chat", endpoint: "https://api.moonshot.cn/v1/chat/completions", model: "", note: "可编辑的兼容入口" },
      { id: "glm", name: "GLM / 智谱", family: "glm", apiStyle: "openai-chat", endpoint: "https://open.bigmodel.cn/api/paas/v4/chat/completions", model: "", note: "可编辑的兼容入口" },
      { id: "custom", name: "自定义服务", family: "custom", apiStyle: "openai-responses", endpoint: "", model: "", note: "填写完整 HTTP(S) 端点" }
    ],
    ttsPresets: [
      { id: "openai", name: "OpenAI 风格 TTS", type: "openai", endpoint: "https://api.openai.com/v1/audio/speech", model: "gpt-4o-mini-tts", voice: "coral", format: "mp3" },
      { id: "elevenlabs", name: "ElevenLabs", type: "elevenlabs", endpoint: "https://api.elevenlabs.io/v1/text-to-speech/{voice}", model: "eleven_multilingual_v2", voice: "", format: "mp3" },
      { id: "custom", name: "自定义 JSON TTS", type: "custom", endpoint: "", model: "", voice: "", format: "mp3" }
    ],
    asrPresets: [
      { id: "openai", name: "OpenAI 风格 ASR", type: "openai", endpoint: "https://api.openai.com/v1/audio/transcriptions", model: "gpt-4o-mini-transcribe", language: "zh" },
      { id: "custom", name: "自定义 multipart ASR", type: "custom", endpoint: "", model: "", language: "zh" }
    ],
    apiStyles: [
      { id: "openai-responses", name: "OpenAI Responses" },
      { id: "openai-chat", name: "OpenAI Chat Completions" },
      { id: "anthropic-messages", name: "Anthropic Messages" },
      { id: "gemini-generate-content", name: "Gemini GenerateContent" }
    ]
  };
})(window.chataxi);
