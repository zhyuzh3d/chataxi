(function (app) {
  "use strict";

  async function hydrateMessages(messages, settings) {
    var lastUserIndex = -1;
    for (var index = messages.length - 1; index >= 0; index -= 1) {
      if (messages[index].kind === "user") { lastUserIndex = index; break; }
    }
    var hydrated = [];
    messages.forEach(function (message, index) {
      hydrated.push({
        role: message.kind === "assistant" ? "assistant" : "user",
        roleName: message.roleName || "",
        text: message.text || "",
        images: []
      });
    });
    if (lastUserIndex >= 0) {
      var sourceImages = messages[lastUserIndex].media || [];
      for (var mediaIndex = 0; mediaIndex < sourceImages.length; mediaIndex += 1) {
        var media = sourceImages[mediaIndex];
        var dataUrl = media.dataUrl || (media.mediaId ? await app.data.media.toDataUrl(media.mediaId) : null);
        if (!dataUrl) throw new Error("这条消息的图片已不可用，请重新选择图片发送");
        if (dataUrl) hydrated[lastUserIndex].images.push({ dataUrl: dataUrl, detail: settings.imageDetail || "auto" });
      }
    }
    return hydrated;
  }

  function truncate(messages, limit) {
    var selected = messages.slice(-Math.min(100, Math.max(4, Number(limit || 40))));
    var remaining = 48000, output = [];
    for (var index = selected.length - 1; index >= 0 && remaining > 0; index -= 1) {
      var message = selected[index], text = String(message.text || "");
      if (text.length > remaining) {
        message = Object.assign({}, message, { text: text.slice(-remaining), contextTruncated: true });
        output.unshift(message); break;
      }
      remaining -= text.length; output.unshift(message);
    }
    return output;
  }

  function removeRoleEcho(text, roleName) {
    var value = String(text || "").trim();
    var prefix = "[" + String(roleName || "").trim() + "]";
    if (prefix !== "[]" && value.indexOf(prefix) === 0) value = value.slice(prefix.length).trim();
    return value;
  }

  async function complete(role, messages, task) {
    var profile = await app.data.store.get("llm-profiles", role.llmProfileId);
    if (!profile || !profile.enabled) throw new Error("角色绑定的模型配置不存在或已停用");
    if (!profile.model) throw new Error("模型配置缺少模型名称");
    var settings = await app.data.store.get("meta", "settings");
    var selected = truncate(messages, settings.historyLimit);
    var hydrated = await hydrateMessages(selected, settings);
    if (task && task.cancelled) { var stopped = new Error("本轮已停止"); stopped.cancelled = true; throw stopped; }
    var request = app.services.providers.build(profile, role, hydrated);
    var bodyText = JSON.stringify(request.body);
    var bodyBytes = new TextEncoder().encode(bodyText).length;
    if (bodyBytes > 900 * 1024) throw new Error("请求内容超过 900 KiB，请减少图片或新建对话");
    var result = await app.platform.network.requestJson({
      url: request.url,
      method: "POST",
      headers: request.headers,
      bodyText: bodyText,
      contentType: "application/json",
      timeoutMs: 120000,
      task: task
    });
    var parsed = app.services.providers.parse(profile, result.data);
    parsed.text = removeRoleEcho(parsed.text, role.name);
    parsed.profileName = profile.name;
    parsed.contextTrimmed = selected.length < messages.length || selected.some(function (message) { return message.contextTruncated; });
    return parsed;
  }

  async function test(profile) {
    profile = Object.assign({}, profile, { allowImageGeneration: false, maxOutputTokens: 256 });
    var role = { systemPrompt: "只执行连接测试。" };
    var request = app.services.providers.build(profile, role, [{ role: "user", text: "仅回复 OK。", images: [] }]);
    var result = await app.platform.network.requestJson({
      url: request.url,
      method: "POST",
      headers: request.headers,
      bodyText: JSON.stringify(request.body),
      contentType: "application/json",
      timeoutMs: 60000
    });
    return app.services.providers.parse(profile, result.data);
  }

  app.services.llm = { complete: complete, test: test, truncate: truncate, hydrateMessages: hydrateMessages, removeRoleEcho: removeRoleEcho };
})(window.chataxi);
