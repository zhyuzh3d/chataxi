(function (app) {
  "use strict";
  var store = app.data.store;

  function roleStatus(role, profiles) {
    if (role.enabled === false) return "角色已停用";
    var profile = profiles.find(function (item) { return item.id === role.llmProfileId; });
    if (!profile) return "需要绑定模型连接";
    if (profile.enabled === false) return "模型连接已停用";
    if (!profile.endpoint || !profile.model) return "模型配置不完整";
    return "";
  }

  async function availableRoles() {
    var profiles = await store.list("llm-profiles");
    return (await store.list("roles")).filter(function (role) { return !roleStatus(role, profiles); });
  }

  async function remove(kind, id) {
    var collection = kind + "-profiles";
    var profile = await store.get(collection, id);
    if (!profile) return;
    if (profile.type === "system") throw new Error("系统配置不能删除");
    var roles = await store.list("roles");
    if (kind === "llm") {
      var refs = roles.filter(function (role) { return role.llmProfileId === id; });
      if (refs.length) throw new Error("仍被“" + refs.map(function (role) { return role.name; }).join("、") + "”使用，请先更换角色的模型连接");
    } else {
      var settings = await store.get("meta", "settings");
      var field = kind === "tts" ? "defaultTtsProfileId" : "defaultAsrProfileId";
      if (settings[field] === id) { settings[field] = "system-" + kind; await store.put("meta", "settings", settings); }
      if (kind === "tts") {
        for (var i = 0; i < roles.length; i += 1) {
          if (roles[i].ttsProfileId === id) { roles[i].ttsProfileId = ""; await store.put("roles", roles[i].id, roles[i]); }
        }
      }
    }
    await store.remove(collection, id);
  }

  async function validateEnabled(kind, profile) {
    if (profile.type === "system" && profile.enabled === false) throw new Error("系统配置始终保留可选；可在通用设置关闭自动朗读或更换默认服务");
    if (profile.enabled !== false || kind === "llm") return;
    var settings = await store.get("meta", "settings");
    if (settings[kind === "tts" ? "defaultTtsProfileId" : "defaultAsrProfileId"] === profile.id) throw new Error("请先更换默认配置，再停用此服务");
    if (kind === "tts") {
      var roles = await store.list("roles");
      if (roles.some(function (role) { return role.ttsProfileId === profile.id; })) throw new Error("请先更换角色的朗读配置，再停用此服务");
    }
  }

  app.services.profiles = { roleStatus: roleStatus, availableRoles: availableRoles, remove: remove, validateEnabled: validateEnabled };
})(window.chataxi);
