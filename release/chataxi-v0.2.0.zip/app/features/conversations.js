(function (app) {
  "use strict";
  var u = app.utils, ui = app.components, store = app.data.store;
  var filter = "all";
  var query = "";

  async function guidedStart() {
    var profiles = (await store.list("llm-profiles")).filter(function (item) { return item.enabled !== false && item.model && item.endpoint; });
    if (!profiles.length) {
      await app.navigate("settings", { settingsTab: "llm" });
      app.features.settings.openLlm(null, guidedStart);
      return;
    }
    var roles = await app.services.profiles.availableRoles();
    if (!roles.length) {
      await app.navigate("roles");
      await app.features.roles.openEditor(null, function (role) { return openEditor(null, role.id); });
      return;
    }
    await openEditor();
  }

  async function render() {
    var conversations = (await store.list("conversations")).sort(function (a, b) { return Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)) || b.updatedAt - a.updatedAt; });
    var roles = await store.list("roles"), llms = await store.list("llm-profiles"), drafts = await store.list("drafts");
    if (app.state.route !== "conversations") return;
    var roleMap = {}, draftMap = {};
    roles.forEach(function (role) { roleMap[role.id] = role; });
    drafts.forEach(function (draft) { if (draft.text || (draft.media || []).length) draftMap[draft.id] = draft; });
    var available = roles.filter(function (role) { return !app.services.profiles.roleStatus(role, llms); });
    var connected = llms.some(function (profile) { return profile.enabled !== false && profile.endpoint && profile.model; });
    ui.pageHeader("chataxi", "让好想法，一路同行", '<button class="button primary compact" type="button" data-create>' + ui.icon("plus") + '<span>新对话</span></button>');
    var main = document.getElementById("mainContent"); main.className = "main";
    var intro = '<div class="page-heading"><div><p class="eyebrow">YOUR CONVERSATIONS</p><h1>对话</h1><p>一个想法，从这里出发。</p></div><span class="count-label">' + conversations.length + ' 个对话</span></div>';
    if (!conversations.length) {
      main.innerHTML = '<section class="page">' + intro + '<div class="welcome-card"><div class="welcome-emblem" aria-hidden="true">' + ui.icon("taxi") + '</div><p class="eyebrow">你好，欢迎上车</p><h2>为你的想法，<br>找一位好搭档。</h2><p>连接你自己的模型，赋予角色个性。<br>专注交流，也让不同观点相遇。</p><div class="setup-steps">' +
        [{ title: "连接模型", text: "使用你的 API 或局域网服务", done: connected }, { title: "创建角色", text: "设定身份、提示词与模型", done: available.length > 0 }, { title: "开始对话", text: "单聊深入，群聊集思广益", done: false }].map(function (step, i) {
          return '<div class="setup-step ' + (step.done ? "done" : "") + '"><span class="step-number">' + (step.done ? ui.icon("check") : String(i + 1).padStart(2, "0")) + '</span><div><strong>' + step.title + '</strong><span>' + step.text + '</span></div><small>' + (step.done ? "已完成" : "") + '</small></div>';
        }).join("") + '</div><button class="button primary full" type="button" data-create>' + (available.length ? "开始第一次对话" : connected ? "继续 · 创建角色" : "开始 · 连接模型") + ui.icon("arrow-right") + '</button><p class="privacy-note">角色、连接和对话保存在当前设备</p></div></section>';
    } else {
      main.innerHTML = '<section class="page">' + intro + '<div class="list-toolbar">' + ui.search("搜索标题、角色或最近消息") + '<div class="segmented" aria-label="筛选对话">' + [{ id: "all", name: "全部" }, { id: "single", name: "单聊" }, { id: "group", name: "群聊" }].map(function (item) { return '<button type="button" data-filter="' + item.id + '" aria-pressed="' + (item.id === filter) + '">' + item.name + '</button>'; }).join("") + '</div></div><div class="list conversation-list" id="conversationList"></div></section>';
      var paint = function () {
        var items = conversations.filter(function (conversation) {
          var names = conversation.roleIds.map(function (id) { return roleMap[id] ? roleMap[id].name : ""; }).join(" ");
          return (filter === "all" || conversation.kind === filter) && (conversation.title + " " + names + " " + conversation.lastMessage).toLowerCase().indexOf(query.toLowerCase()) >= 0;
        });
        document.getElementById("conversationList").innerHTML = items.length ? items.map(function (conversation) {
          var participants = conversation.roleIds.map(function (id) { return roleMap[id]; }).filter(Boolean);
          var draft = draftMap[conversation.id];
          var preview = draft ? "草稿 · " + (draft.text || "[图片]") : conversation.lastMessage || "发出第一条消息吧";
          var unavailable = participants.some(function (role) { return app.services.profiles.roleStatus(role, llms); }) || participants.length !== conversation.roleIds.length;
          return '<article class="card conversation-card"><button class="card-button conversation-open" type="button" data-open="' + u.escapeHtml(conversation.id) + '"><div class="avatar-stack">' + participants.slice(0, 2).map(function (role) { return ui.avatar(role.name, role.avatarColor); }).join("") + '</div><div class="list-copy"><div class="conversation-title"><strong>' + (conversation.pinned ? ui.icon("thumbtack") + ' ' : '') + u.escapeHtml(conversation.title) + '</strong><time>' + u.escapeHtml(u.formatTime(conversation.updatedAt)) + '</time></div><p class="preview ' + (draft ? 'draft-preview' : '') + '">' + u.escapeHtml(preview) + '</p><div class="meta"><span>' + u.escapeHtml(participants.map(function (role) { return role.name; }).join("、")) + '</span><span class="badge ' + (unavailable ? 'warning' : '') + '">' + (unavailable ? '需要修复配置' : conversation.kind === "group" ? '群聊' : '单聊') + '</span></div></div></button><button class="icon-button" type="button" data-manage="' + u.escapeHtml(conversation.id) + '" aria-label="管理 ' + u.escapeHtml(conversation.title) + '">' + ui.icon("ellipsis") + '</button></article>';
        }).join("") : ui.empty("magnifying-glass", "没有找到对话", "换个关键词，或试试其他分类。", '');
        main.querySelectorAll("[data-open]").forEach(function (button) { button.addEventListener("click", ui.action(function () { return app.openChat(button.dataset.open); })); });
        main.querySelectorAll("[data-manage]").forEach(function (button) { button.addEventListener("click", ui.action(function () { return manage(button.dataset.manage); })); });
      };
      var input = document.getElementById("listSearch"); input.value = query;
      input.addEventListener("input", function () { query = input.value; paint(); });
      main.querySelectorAll("[data-filter]").forEach(function (button) { button.addEventListener("click", function () { filter = button.dataset.filter; main.querySelectorAll("[data-filter]").forEach(function (item) { item.setAttribute("aria-pressed", String(item.dataset.filter === filter)); }); paint(); }); });
      paint();
    }
    document.querySelectorAll("[data-create]").forEach(function (button) { button.addEventListener("click", ui.action(guidedStart)); });
  }

  async function openEditor(conversation, roleId) {
    var roles = await app.services.profiles.availableRoles();
    if (!roles.length) { if (conversation) { ui.toast("请先在角色页恢复一个可用角色，再编辑此对话"); return app.navigate("roles"); } return guidedStart(); }
    var editing = Boolean(conversation);
    var initial = conversation ? conversation.roleIds : roleId ? [roleId] : roles.length === 1 ? [roles[0].id] : [];
    var kind = conversation ? conversation.kind : "single";
    var form = ui.openModal({ title: editing ? "编辑对话" : "开始一段新对话", eyebrow: "CONVERSATION", submitText: editing ? "保存更改" : "开始对话", html: '<div class="form-grid"><label class="field"><span>对话标题</span><input name="title" maxlength="80" value="' + u.escapeHtml(conversation ? conversation.title : '') + '" placeholder="可留空，使用角色名称"></label><fieldset><legend>对话方式</legend><div class="choice-grid"><label class="choice-card"><input name="kind" type="radio" value="single"' + (kind === 'single' ? ' checked' : '') + '><strong>单聊</strong><small>与一位角色专注交流</small></label><label class="choice-card"><input name="kind" type="radio" value="group"' + (kind === 'group' ? ' checked' : '') + '><strong>群聊</strong><small>让多位角色依次回答</small></label></div></fieldset><fieldset><legend>选择参与角色</legend><div class="stack">' + roles.map(function (role) { return '<label class="role-choice">' + ui.avatar(role.name, role.avatarColor) + '<span class="list-copy"><strong>' + u.escapeHtml(role.name) + '</strong><span>' + u.escapeHtml(role.description || "AI 角色") + '</span></span><input type="checkbox" name="roleIds" value="' + u.escapeHtml(role.id) + '"' + (initial.indexOf(role.id) >= 0 ? ' checked' : '') + '></label>'; }).join('') + '</div></fieldset><p class="helper" id="selectionSummary" role="status"></p></div>',
      onSubmit: async function (target) {
        var selectedKind = target.querySelector('[name="kind"]:checked').value;
        var selected = Array.prototype.map.call(target.querySelectorAll('[name="roleIds"]:checked'), function (item) { return item.value; });
        if (selectedKind === "single" && selected.length !== 1) throw new Error("单聊请选择一位角色");
        if (selectedKind === "group" && selected.length < 2) throw new Error("群聊请选择至少两位角色");
        var names = roles.filter(function (role) { return selected.indexOf(role.id) >= 0; }).map(function (role) { return role.name; });
        var next = Object.assign({}, conversation || {}, { id: conversation ? conversation.id : u.id("conversation"), title: u.formValue(target, "title") || (selectedKind === "single" ? "与" + names[0] + "的对话" : names.join("、") + "的群聊").slice(0, 80), kind: selectedKind, roleIds: selected, activeRoleIds: selected.slice(), createdAt: conversation ? conversation.createdAt : Date.now(), updatedAt: Date.now() });
        await store.put("conversations", next.id, next); return next;
      }, onSuccess: function (next) { ui.toast(editing ? "对话已更新" : "对话已创建"); return app.openChat(next.id); }
    });
    function sync(changed) {
      var single = form.querySelector('[name="kind"]:checked').value === "single";
      var boxes = form.querySelectorAll('[name="roleIds"]');
      if (single) {
        var first = changed && changed.checked ? changed : form.querySelector('[name="roleIds"]:checked');
        boxes.forEach(function (box) { box.checked = box === first; });
      }
      var count = form.querySelectorAll('[name="roleIds"]:checked').length;
      form.querySelector("#selectionSummary").textContent = single ? "已选择 " + count + " 位角色 · 单聊需要一位" : "已选择 " + count + " 位角色 · 每次发送各回复一次";
      form.querySelector('[type="submit"]').disabled = single ? count !== 1 : count < 2;
    }
    form.querySelectorAll('[name="roleIds"]').forEach(function (box) { box.addEventListener("change", function () { sync(box); }); });
    form.querySelectorAll('[name="kind"]').forEach(function (radio) { radio.addEventListener("change", function () { sync(); }); });
    sync();
  }

  async function exportText(id) {
    var conversation = await store.get("conversations", id), messages = await store.messages(id);
    var text = conversation.title + "\n\n" + messages.map(function (message) { return (message.kind === "user" ? "我" : message.roleName || "AI") + " · " + new Date(message.createdAt).toLocaleString("zh-CN") + "\n" + (message.text || "") + ((message.media || []).length ? "\n[" + message.media.length + " 张图片，未包含在文字导出中]" : "") + (message.status !== "done" ? "\n[" + (message.error || "未完成") + "]" : ""); }).join("\n\n");
    ui.openModal({ title: "导出对话文字", submitText: "复制全部文字", html: '<p class="helper">包含本对话的文字与图片数量，不包含连接、密钥和图片文件。</p><label class="field"><span>对话文字</span><textarea class="export-text" readonly>' + u.escapeHtml(text) + '</textarea></label>', onSubmit: async function () { await app.platform.hermit.copyText(text); ui.toast("已复制"); } });
  }

  async function manage(id) {
    var conversation = await store.get("conversations", id);
    if (!conversation) return;
    var form = ui.openModal({ title: conversation.title, submitText: "完成", cancelText: null, html: '<div class="menu-list"><button class="menu-item" type="button" data-menu="edit">' + ui.icon('pen') + '<span>编辑标题与参与角色</span>' + ui.icon('chevron-right') + '</button><button class="menu-item" type="button" data-menu="pin">' + ui.icon('thumbtack') + '<span>' + (conversation.pinned ? '取消置顶' : '置顶对话') + '</span></button><button class="menu-item" type="button" data-menu="export">' + ui.icon('file-lines') + '<span>导出对话文字</span></button><button class="menu-item danger-text" type="button" data-menu="delete">' + ui.icon('trash') + '<span>删除对话</span></button></div>', onSubmit: function () {} });
    form.querySelectorAll('[data-menu]').forEach(function (button) { button.addEventListener('click', ui.action(async function () {
      var command = button.dataset.menu;
      if (app.features.chatSession.active(id) && (command === "edit" || command === "delete")) { ui.toast("请先停止本轮回复，再修改或删除对话"); return; }
      ui.closeModal();
      if (command === 'edit') return openEditor(conversation);
      if (command === 'export') return exportText(id);
      if (command === 'pin') { conversation.pinned = !conversation.pinned; await store.put("conversations", id, conversation); ui.toast(conversation.pinned ? '对话已置顶' : '已取消置顶'); if (app.state.route === 'conversations') await render(); }
      if (command === 'delete' && await ui.confirm({ title: '删除对话？', message: '“' + conversation.title + '”的消息、草稿和未被其他对话使用的图片将从本机删除，无法撤销。', confirmText: '删除对话', danger: true })) {
        if (app.state.activeConversationId === id) await app.features.chat.close();
        await store.deleteConversation(id); await app.navigate('conversations'); ui.toast('对话已删除');
      }
    })); });
  }
  app.features = app.features || {};
  app.features.conversations = { render: render, openEditor: openEditor, guidedStart: guidedStart, manage: manage, exportText: exportText };
})(window.chataxi);
