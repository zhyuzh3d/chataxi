(function (app) {
  "use strict";
  var u = app.utils, ui = app.components, store = app.data.store;
  var testing = {};
  var names = { llm: '模型连接', tts: '朗读', asr: '语音输入', general: '通用' };
  function option(value, label, selected) { return '<option value="' + u.escapeHtml(value) + '"' + (value === selected ? ' selected' : '') + '>' + u.escapeHtml(label) + '</option>'; }
  function input(name, label, value, extra) { return '<label class="field"><span>' + label + '</span><input name="' + name + '" value="' + u.escapeHtml(value == null ? '' : value) + '" ' + (extra || '') + '></label>'; }
  function select(name, label, options) { return '<label class="field"><span>' + label + '</span><select name="' + name + '">' + options + '</select></label>'; }
  function toggle(name, label, text, value) { return '<label class="switch-row"><span><strong>' + label + '</strong><small>' + text + '</small></span><input name="' + name + '" type="checkbox"' + (value ? ' checked' : '') + '></label>'; }
  function secretField(existing) {
    return '<label class="field"><span>API Key / Token <em>按服务要求填写</em></span><input name="apiKey" type="password" autocomplete="new-password" spellcheck="false" placeholder="' + (existing ? '已保存 · 留空保留原密钥' : '仅在点击保存后存入本机') + '"><small>密钥始终遮罩，建议使用权限受限的 Token。</small></label>' + (existing ? '<label class="check-line"><input type="checkbox" name="clearApiKey">清除已保存的密钥</label>' : '');
  }
  function secretValue(form, old) { return u.checked(form, 'clearApiKey') ? '' : u.formValue(form, 'apiKey') || old.apiKey || ''; }
  function headerField(profile) { return '<label class="field"><span>自定义 Header <em>JSON，选填</em></span><textarea name="customHeaders" spellcheck="false" placeholder="{&quot;X-Client&quot;:&quot;chataxi&quot;}">' + u.escapeHtml(profile.customHeaders || '') + '</textarea></label>'; }
  function presetField(presets) { return select('preset', '选择一个配置起点', option('', '手动填写', '') + presets.map(function (item) { return option(item.id, item.name, ''); }).join('')); }
  async function refresh(kind) { if (app.state.route === 'settings' && app.state.settingsTab === kind) await render(); }

  async function render() {
    var tab = app.state.settingsTab || 'llm';
    ui.pageHeader('设置', '连接你的模型，调整你的习惯');
    var main = document.getElementById('mainContent'); main.className = 'main';
    main.innerHTML = '<section class="page settings-page"><div class="page-heading"><div><p class="eyebrow">MAKE IT YOURS</p><h1>刚好适合你</h1><p>模型、声音与日常偏好。</p></div></div><div class="settings-tabs" role="tablist" aria-label="设置分类">' + Object.keys(names).map(function (key) { return '<button type="button" role="tab" id="tab-' + key + '" aria-controls="settingsContent" tabindex="' + (key === tab ? '0' : '-1') + '" data-tab="' + key + '" aria-selected="' + (key === tab) + '">' + names[key] + '</button>'; }).join('') + '</div><div id="settingsContent" role="tabpanel" aria-labelledby="tab-' + tab + '"></div></section>';
    main.querySelectorAll('[data-tab]').forEach(function (button) {
      button.addEventListener('click', ui.action(async function () { app.state.settingsTab = button.dataset.tab; await render(); var next = document.getElementById('tab-' + app.state.settingsTab); if (next) next.focus(); }));
      button.addEventListener('keydown', function (event) { var keys = Object.keys(names), index = keys.indexOf(button.dataset.tab); if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].indexOf(event.key) < 0) return; event.preventDefault(); var next = event.key === 'Home' ? 0 : event.key === 'End' ? keys.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + keys.length) % keys.length; document.getElementById('tab-' + keys[next]).click(); });
    });
    if (tab === 'general') await renderGeneral(); else await renderProfiles(tab);
  }
  async function renderProfiles(kind) {
    var profiles = await store.list(kind + '-profiles'), settings = await store.get('meta', 'settings');
    if (app.state.route !== 'settings' || app.state.settingsTab !== kind) return;
    var content = document.getElementById('settingsContent');
    var note = kind === 'llm' ? '模型连接可以被多个角色共用。测试会发送一条简短消息，可能产生费用。' : kind === 'tts' ? '自动朗读可在通用设置关闭。第三方试听会调用语音服务，可能产生费用；声音由 AI 合成。' : '系统识别需要设备提供语音识别服务；第三方服务使用短音频文件。识别文字不会自动发送。';
    content.innerHTML = '<div class="settings-section-intro"><p>' + note + '</p><button class="button primary compact" type="button" data-add-profile>' + ui.icon('plus') + '添加' + (kind === 'llm' ? '连接' : '服务') + '</button></div><div class="list profile-list">' + (profiles.length ? profiles.map(function (profile) {
      var system = profile.type === 'system', defaultId = settings[kind === 'tts' ? 'defaultTtsProfileId' : 'defaultAsrProfileId'];
      var test = profile.lastTest;
      var status = profile.enabled === false ? '已停用' : kind !== 'llm' && defaultId === profile.id ? '默认使用' : system ? '系统内置' : '已启用';
      var subtitle = system ? (kind === 'tts' ? '使用手机上的系统声音' : '把说话内容填入输入框') : profile.model || '自定义服务';
      var protocol = kind === 'llm' ? app.services.catalog.apiStyles.find(function (item) { return item.id === profile.apiStyle; }) : null;
      return '<article class="card profile-card"><div class="row"><span class="service-icon">' + ui.icon(kind === 'llm' ? 'server' : kind === 'tts' ? 'volume-high' : 'microphone') + '</span><div class="list-copy"><strong>' + u.escapeHtml(profile.name) + '</strong><span>' + u.escapeHtml(subtitle) + '</span></div><span class="badge ' + (defaultId === profile.id && kind !== 'llm' ? 'success' : '') + '">' + status + '</span></div>' + (!system ? '<div class="connection-details"><span>' + u.escapeHtml(protocol ? protocol.name : profile.type) + '</span><span class="endpoint">' + u.escapeHtml(profile.endpoint) + '</span><span>' + (profile.apiKey ? '密钥已保存 · ••••••••' : '未保存密钥') + '</span></div>' : '') + (test ? '<div class="connection-result ' + (test.ok ? 'success-text' : 'danger-text') + '" role="status">' + ui.icon(test.ok ? 'circle-check' : 'circle-exclamation') + '<span>' + u.escapeHtml(test.message) + '<small>' + u.escapeHtml(u.formatTime(test.at)) + ' 的测试结果</small></span></div>' : '') + '<div class="profile-actions">' + (kind === 'llm' || kind === 'tts' ? '<button class="button secondary" type="button" data-test-profile="' + u.escapeHtml(profile.id) + '"' + (testing[profile.id] || profile.enabled === false ? ' disabled' : '') + '>' + ui.icon(kind === 'llm' ? 'plug' : 'volume-high') + (testing[profile.id] ? '测试中…' : kind === 'llm' ? '测试连接' : '试听') + '</button>' : '') + (kind !== 'llm' && defaultId !== profile.id && profile.enabled !== false ? '<button class="button ghost" type="button" data-default="' + u.escapeHtml(profile.id) + '">设为默认</button>' : '') + '<span class="grow"></span><button class="icon-button" type="button" data-edit-profile="' + u.escapeHtml(profile.id) + '" aria-label="编辑 ' + u.escapeHtml(profile.name) + '">' + ui.icon('pen') + '</button>' + (!system ? '<button class="icon-button danger-text" type="button" data-remove-profile="' + u.escapeHtml(profile.id) + '" aria-label="删除 ' + u.escapeHtml(profile.name) + '">' + ui.icon('trash') + '</button>' : '') + '</div></article>';
    }).join('') : ui.empty('server', '连接你的第一个模型', '使用局域网模型服务，或填写供应商的 API 地址和密钥。', '<button class="button primary" type="button" data-add-profile>添加模型连接</button>')) + '</div>' + (kind === 'tts' ? '<button class="button ghost full stop-preview" type="button" data-stop-voice>' + ui.icon('stop') + '停止试听 / 朗读</button>' : '');
    content.querySelectorAll('[data-add-profile]').forEach(function (button) { button.addEventListener('click', function () { if (kind === 'llm') openLlm(null); else openVoice(kind, null); }); });
    content.querySelectorAll('[data-edit-profile]').forEach(function (button) { button.addEventListener('click', ui.action(async function () { var profile = await store.get(kind + '-profiles', button.dataset.editProfile); if (kind === 'llm') openLlm(profile); else openVoice(kind, profile); })); });
    content.querySelectorAll('[data-remove-profile]').forEach(function (button) { button.addEventListener('click', ui.action(async function () { if (await ui.confirm({ title: '删除这项' + names[kind] + '配置？', message: kind === 'llm' ? '只删除本机连接。仍被角色使用的连接需要先解除绑定。' : '引用此服务的默认设置与角色朗读将恢复系统默认。', confirmText: '删除配置', danger: true })) { await app.services.profiles.remove(kind, button.dataset.removeProfile); await refresh(kind); ui.toast('配置已删除'); } })); });
    content.querySelectorAll('[data-default]').forEach(function (button) { button.addEventListener('click', ui.action(async function () { var latest = await store.get('meta', 'settings'); latest[kind === 'tts' ? 'defaultTtsProfileId' : 'defaultAsrProfileId'] = button.dataset.default; await store.put('meta', 'settings', latest); await refresh(kind); ui.toast('默认服务已更新'); })); });
    content.querySelectorAll('[data-test-profile]').forEach(function (button) { button.addEventListener('click', ui.action(async function () {
      var id = button.dataset.testProfile;
      if (testing[id]) return;
      testing[id] = true; button.disabled = true; button.textContent = kind === 'tts' ? '正在准备声音…' : '测试中…';
      var profile = await store.get(kind + '-profiles', id);
      try {
        if (kind === 'tts') { await app.services.tts.speak('你好，欢迎来到 chataxi。让好想法，一路同行。', { ttsProfileId: id }); }
        else {
          var start = Date.now(); await app.services.llm.test(profile);
          profile.lastTest = { ok: true, message: '连接成功 · ' + ((Date.now() - start) / 1000).toFixed(1) + ' 秒', at: Date.now() };
        }
      } catch (error) {
        if (kind === 'llm') profile.lastTest = { ok: false, message: u.cleanError(error), at: Date.now() };
        else ui.toast(u.cleanError(error), 5000);
      } finally {
        delete testing[id];
        // A test result only belongs to the exact configuration that was tested.
        if (kind === 'llm') { var latest = await store.get('llm-profiles', id); if (latest && latest.updatedAt === profile.updatedAt) { latest.lastTest = profile.lastTest; await store.put('llm-profiles', id, latest); } }
        await refresh(kind);
      }
    })); });
    var stop = content.querySelector('[data-stop-voice]'); if (stop) stop.addEventListener('click', ui.action(function () { return app.services.tts.stop(); }));
  }
  function openLlm(profile, onSaved) {
    var editing = Boolean(profile);
    profile = profile || { id: u.id('llm'), name: '', family: 'custom', apiStyle: 'openai-responses', endpoint: '', model: '', maxOutputTokens: 1024, temperature: '', enabled: true };
    var presets = app.services.catalog.llmPresets;
    var form = ui.openModal({ title: editing ? '编辑模型连接' : '连接一个模型', eyebrow: 'MODEL CONNECTION', submitText: editing ? '保存更改' : '保存连接', html: '<div class="form-grid">' + presetField(presets) + input('name', '连接名称', profile.name, 'required maxlength="80" placeholder="例如：我的模型服务"') + select('apiStyle', '接口协议', app.services.catalog.apiStyles.map(function (item) { return option(item.id, item.name, profile.apiStyle); }).join('')) + input('endpoint', '完整请求地址', profile.endpoint, 'type="url" required spellcheck="false" placeholder="https://…/v1/responses"') + '<p class="helper">填写完整接口路径。HTTP 仅用于你信任的局域网。</p>' + input('model', '模型名称', profile.model, 'required maxlength="160" placeholder="填写服务提供的模型 ID"') + secretField(Boolean(profile.apiKey)) + '<details class="advanced"><summary>高级参数</summary><div class="form-grid"><div class="form-columns">' + input('maxOutputTokens', '最大输出 Token', profile.maxOutputTokens || 1024, 'type="number" min="32" max="32768"') + input('temperature', '温度（可空）', profile.temperature, 'type="number" min="0" max="2" step="0.1"') + '</div>' + select('reasoningEffort', '推理强度 · Responses', ['', 'none', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra'].map(function (value) { return option(value, value || '使用服务默认', profile.reasoningEffort || ''); }).join('')) + toggle('allowImageGeneration', '允许图片生成', '仅适用于支持图片生成的 Responses 服务', profile.allowImageGeneration) + headerField(profile) + '</div></details>' + toggle('enabled', '启用此连接', '停用后，绑定角色暂时无法回复', profile.enabled !== false) + '</div>',
      onSubmit: async function (target) {
        var next = Object.assign({}, profile, { name: u.formValue(target, 'name'), family: target.dataset.family || profile.family, apiStyle: u.formValue(target, 'apiStyle'), endpoint: u.formValue(target, 'endpoint'), model: u.formValue(target, 'model'), apiKey: secretValue(target, profile), maxOutputTokens: Number(u.formValue(target, 'maxOutputTokens') || 1024), temperature: u.formValue(target, 'temperature'), reasoningEffort: u.formValue(target, 'reasoningEffort'), customHeaders: u.formValue(target, 'customHeaders'), allowImageGeneration: u.checked(target, 'allowImageGeneration'), enabled: u.checked(target, 'enabled'), updatedAt: Date.now() });
        if (!next.name || !next.model) throw new Error('请填写连接名称和模型名称');
        u.validateEndpoint(next.endpoint); u.parseHeaders(next.customHeaders);
        if (next.apiStyle !== 'openai-responses') { next.allowImageGeneration = false; next.reasoningEffort = ''; }
        app.services.providers.build(next, { systemPrompt: '' }, [{ role: 'user', text: 'test', images: [] }]);
        delete next.lastTest;
        await store.put('llm-profiles', next.id, next); return next;
      }, onSuccess: async function (next) { ui.toast('模型连接已保存，可点击测试连接'); if (onSaved) return onSaved(next); await refresh('llm'); }
    });
    bindPreset(form, presets, ['name', 'apiStyle', 'endpoint', 'model'], profile);
    function syncProtocol() { var responses = form.elements.namedItem('apiStyle').value === 'openai-responses'; form.elements.namedItem('reasoningEffort').disabled = !responses; form.elements.namedItem('allowImageGeneration').disabled = !responses; }
    form.elements.namedItem('apiStyle').addEventListener('change', syncProtocol); form.elements.namedItem('preset').addEventListener('change', syncProtocol); syncProtocol();
  }
  function bindPreset(form, presets, fields, existing) {
    form.elements.namedItem('preset').addEventListener('change', function (event) {
      var preset = presets.find(function (item) { return item.id === event.target.value; }); if (!preset) return;
      form.dataset.family = preset.family || 'custom';
      fields.forEach(function (key) { var field = form.elements.namedItem(key); if (field) field.value = preset[key] || ''; });
      if (existing.apiKey && preset.endpoint !== existing.endpoint) { var clear = form.elements.namedItem('clearApiKey'); if (clear) clear.checked = true; }
    });
  }
  function openVoice(kind, profile) {
    var editing = Boolean(profile), tts = kind === 'tts';
    profile = profile || { id: u.id(kind), name: '', type: 'openai', endpoint: '', model: '', voice: '', format: 'mp3', language: tts ? 'zh-CN' : 'zh', enabled: true };
    var system = profile.type === 'system', presets = app.services.catalog[tts ? 'ttsPresets' : 'asrPresets'];
    var html = '<div class="form-grid">' + (!system ? presetField(presets) : '<p class="helper">实际可用的声音与识别能力取决于手机提供的系统服务。</p>') + input('name', '配置名称', profile.name, 'required maxlength="80"') + (system ? '' : select('type', '服务协议', (tts ? ['openai', 'elevenlabs', 'custom'] : ['openai', 'custom']).map(function (value) { return option(value, value === 'custom' ? '自定义兼容端点' : value === 'openai' ? 'OpenAI 风格' : 'ElevenLabs', profile.type); }).join('')) + input('endpoint', '完整请求地址', profile.endpoint, 'type="url" required') + input('model', '模型名称', profile.model, 'required maxlength="160"') + (tts ? input('voice', '声音 / Voice ID', profile.voice, 'maxlength="160"') + select('format', '音频格式', ['mp3', 'wav', 'opus', 'aac', 'flac'].map(function (value) { return option(value, value, profile.format || 'mp3'); }).join('')) : '') + secretField(Boolean(profile.apiKey))) + (system || !tts ? input('language', '语言', profile.language || (tts ? 'zh-CN' : 'zh'), 'maxlength="30"') : '') + (system && tts ? '<div class="form-columns">' + input('rate', '语速', profile.rate || 1, 'type="number" min="0.25" max="2" step="0.05"') + input('pitch', '音调', profile.pitch || 1, 'type="number" min="0.5" max="2" step="0.05"') + '</div>' : system ? toggle('onDevice', '仅使用设备离线识别', '设备不支持时会明确提示不可用', profile.onDevice) : '') + (!system ? '<details class="advanced"><summary>高级参数</summary><div class="form-grid">' + headerField(profile) + '</div></details>' + toggle('enabled', '启用此服务', '默认服务或角色引用需先更换，才能停用', profile.enabled !== false) : '') + (!tts && !system ? '<p class="helper">对话中点击语音按钮，选择不超过 650 KiB 的短音频识别。</p>' : '') + '</div>';
    var form = ui.openModal({ title: (editing ? '编辑' : '添加') + names[kind] + '配置', eyebrow: tts ? 'VOICE OUTPUT' : 'VOICE INPUT', html: html, onSubmit: async function (target) {
      var next = Object.assign({}, profile, { name: u.formValue(target, 'name'), language: u.formValue(target, 'language'), enabled: system || u.checked(target, 'enabled'), updatedAt: Date.now() });
      if (!next.name) throw new Error('请填写配置名称');
      if (system) { if (tts) { next.rate = Number(u.formValue(target, 'rate') || 1); next.pitch = Number(u.formValue(target, 'pitch') || 1); } else next.onDevice = u.checked(target, 'onDevice'); }
      else { ['type', 'endpoint', 'model', 'customHeaders'].forEach(function (key) { next[key] = u.formValue(target, key); }); next.apiKey = secretValue(target, profile); if (tts) { next.voice = u.formValue(target, 'voice'); next.format = u.formValue(target, 'format'); } u.validateEndpoint(next.endpoint); u.parseHeaders(next.customHeaders); }
      await app.services.profiles.validateEnabled(kind, next); await store.put(kind + '-profiles', next.id, next); return next;
    }, onSuccess: async function () { ui.toast('配置已保存'); await refresh(kind); } });
    if (!system) {
      bindPreset(form, presets, ['name', 'type', 'endpoint', 'model', 'voice', 'language', 'format'], profile);
      if (tts) {
        var syncFormat = function () { var field = form.elements.namedItem('format'); var unsupported = form.elements.namedItem('type').value === 'elevenlabs'; field.disabled = unsupported; field.closest('label').classList.toggle('is-hidden', unsupported); };
        form.elements.namedItem('type').addEventListener('change', syncFormat); form.elements.namedItem('preset').addEventListener('change', syncFormat); syncFormat();
      }
    }
  }
  async function renderGeneral() {
    var settings = await store.get('meta', 'settings'), tts = await store.list('tts-profiles'), asr = await store.list('asr-profiles');
    var info = await app.platform.hermit.info();
    if (app.state.route !== 'settings' || app.state.settingsTab !== 'general') return;
    var content = document.getElementById('settingsContent');
    content.innerHTML = '<form id="generalForm" class="form-grid"><section class="card card-body form-grid"><h2 class="section-title">对话习惯</h2>' + toggle('autoSpeak', '自动朗读新回复', '群聊完成后朗读最后一位角色的回复', settings.autoSpeak) + toggle('enterToSend', '按 Enter 发送', '关闭时 Enter 换行；始终可用 Ctrl / ⌘ + Enter 发送', Boolean(settings.enterToSend)) + select('defaultTtsProfileId', '默认朗读服务', tts.filter(function (p) { return p.enabled !== false; }).map(function (p) { return option(p.id, p.name, settings.defaultTtsProfileId); }).join('')) + select('defaultAsrProfileId', '默认语音输入', asr.filter(function (p) { return p.enabled !== false; }).map(function (p) { return option(p.id, p.name, settings.defaultAsrProfileId); }).join('')) + '</section><section class="card card-body form-grid"><h2 class="section-title">外观与上下文</h2>' + select('theme', '界面主题', [{ id: 'system', name: '跟随系统' }, { id: 'light', name: '浅色' }, { id: 'dark', name: '深色' }].map(function (item) { return option(item.id, item.name, settings.theme); }).join('')) + input('language', '默认语言', settings.language || 'zh-CN', 'maxlength="30"') + input('historyLimit', '最多发送的历史消息数', settings.historyLimit || 40, 'type="number" min="4" max="100" required') + '<p class="helper">同时限制约 48,000 字符。裁剪只影响本次请求，完整历史仍保存在本机；图片仅携带最近一条用户消息的附件。</p></section><button class="button primary full" type="submit">保存偏好</button><p class="save-status" id="settingsSaveStatus" role="status"></p></form><section class="card card-body environment-card"><h2 class="section-title">关于 chataxi <span class="badge">' + u.escapeHtml(app.version) + '</span></h2><dl class="facts"><div><dt>数据保存</dt><dd>' + (store.backend() === 'hermit' ? 'Hermit 应用数据' : '当前浏览器') + '</dd></div><div><dt>运行方式</dt><dd>' + u.escapeHtml(({ live: '线上实时运行', local: '本地运行', browser: '浏览器预览' })[info.runtimeMode] || info.runtimeMode || '未知') + '</dd></div><div><dt>Hermit Bridge</dt><dd>' + (app.platform.hermit.available() ? '已就绪' : '未连接') + '</dd></div></dl><p class="helper">清除应用数据会删除本机记录。线上实时运行只加载你信任的页面来源，页面代码在请求时可以读取已保存密钥。</p></section>';
    var form = document.getElementById('generalForm');
    form.addEventListener('input', function () { document.getElementById('settingsSaveStatus').textContent = '有未保存的更改'; });
    form.addEventListener('submit', ui.action(async function (event) {
      event.preventDefault(); var button = form.querySelector('[type="submit"]'); if (button.disabled) return; button.disabled = true;
      try {
        var latest = await store.get('meta', 'settings');
        ['autoSpeak', 'enterToSend'].forEach(function (key) { latest[key] = u.checked(form, key); });
        ['defaultTtsProfileId', 'defaultAsrProfileId', 'theme', 'language'].forEach(function (key) { latest[key] = u.formValue(form, key); });
        latest.historyLimit = Number(u.formValue(form, 'historyLimit'));
        await store.put('meta', 'settings', latest); app.applyTheme(latest.theme); document.getElementById('settingsSaveStatus').textContent = '偏好已保存'; ui.toast('偏好已保存');
      } finally { button.disabled = false; }
    }));
  }
  app.features = app.features || {};
  app.features.settings = { render: render, openLlm: openLlm };
})(window.chataxi);
