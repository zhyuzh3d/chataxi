(function (app) {
  "use strict";
  var u = app.utils, ui = app.components, store = app.data.store;
  var templates = [
    { name: "通用助手", description: "一起想清楚，再把事情做好", color: "#59664d", prompt: "你是一位清晰、耐心的个人助手。先理解用户的真实目标，用准确、简洁的中文回答。面对不确定的信息，明确说明，不编造事实。需要时提供可执行的下一步。" },
    { name: "写作伙伴", description: "整理思路，找到恰当的表达", color: "#9a634b", prompt: "你是一位中文写作伙伴。帮助用户梳理观点、组织文章和润色文字，保留作者本意与个人语气。使用自然具体的表达，删去空话；必要时解释关键修改的原因。" },
    { name: "思考搭档", description: "换个角度，检验想法", color: "#596ca0", prompt: "你是一位善于分析的思考搭档。理解问题后，区分事实、假设与判断，指出关键遗漏和反例。不要机械附和，也不要为了反对而反对；给出明确、可检验的建议。" }
  ];
  async function render() {
    var roles = (await store.list("roles")).sort(function (a, b) { return a.name.localeCompare(b.name, "zh-CN"); });
    var profiles = await store.list("llm-profiles");
    if (app.state.route !== "roles") return;
    ui.pageHeader("角色", "给每种对话，一点不同的个性", '<button class="button primary compact" type="button" data-add-role>' + ui.icon("plus") + '<span>新角色</span></button>');
    var main = document.getElementById("mainContent"); main.className = "main";
    main.innerHTML = '<section class="page"><div class="page-heading"><div><p class="eyebrow">YOUR COMPANIONS</p><h1>你的 AI 搭档</h1><p>名字、个性和模型，由你决定。</p></div><span class="count-label">' + roles.length + ' 位角色</span></div>' + (roles.length ? ui.search("搜索角色名称或介绍") + '<div class="role-grid" id="roleList"></div>' : '<div class="welcome-card role-welcome"><div class="empty-icon">' + ui.icon('user-group') + '</div><h2>第一位搭档，会是谁？</h2><p>从一个简单的身份开始，<br>随时调整提示词，让它更懂你的习惯。</p><div class="template-preview">' + templates.map(function (item) { return '<span>' + ui.avatar(item.name, item.color) + u.escapeHtml(item.name) + '</span>'; }).join('') + '</div><button class="button primary" type="button" data-add-role>' + (profiles.some(function (p) { return p.enabled !== false; }) ? '创建第一位角色' : '先连接一个模型') + ui.icon('arrow-right') + '</button></div>') + '</section>';
    if (roles.length) {
      var paint = function (query) {
        var items = roles.filter(function (role) { return (role.name + ' ' + role.description).toLowerCase().indexOf(query.toLowerCase()) >= 0; });
        document.getElementById('roleList').innerHTML = items.length ? items.map(function (role) {
          var status = app.services.profiles.roleStatus(role, profiles);
          var profile = profiles.find(function (item) { return item.id === role.llmProfileId; });
          return '<article class="card role-card"><div class="row-between">' + ui.avatar(role.name, role.avatarColor, 'large') + '<span class="badge ' + (status ? 'warning' : 'success') + '">' + (status ? u.escapeHtml(status) : '可对话') + '</span></div><h2>' + u.escapeHtml(role.name) + '</h2><p class="role-description">' + u.escapeHtml(role.description || '还没有介绍，点击编辑完善角色。') + '</p><div class="role-model">' + ui.icon('microchip') + '<span>' + u.escapeHtml(profile ? profile.name + ' · ' + profile.model : '未绑定模型') + '</span></div><div class="row"><button class="button ' + (status ? 'secondary' : 'primary') + ' grow" type="button" ' + (status ? 'data-edit-role' : 'data-chat-role') + '="' + u.escapeHtml(role.id) + '">' + ui.icon(status ? 'wrench' : 'comment-dots') + (status ? '修复配置' : '开始对话') + '</button><button class="icon-button" type="button" data-edit-role="' + u.escapeHtml(role.id) + '" aria-label="编辑 ' + u.escapeHtml(role.name) + '">' + ui.icon('pen') + '</button></div></article>';
        }).join('') : ui.empty('magnifying-glass', '没有找到角色', '试试其他名字或关键词。', '');
        main.querySelectorAll('[data-edit-role]').forEach(function (button) { button.addEventListener('click', ui.action(async function () { await openEditor(await store.get('roles', button.dataset.editRole)); })); });
        main.querySelectorAll('[data-chat-role]').forEach(function (button) { button.addEventListener('click', ui.action(function () { return app.features.conversations.openEditor(null, button.dataset.chatRole); })); });
      };
      main.querySelector('#listSearch').addEventListener('input', function (event) { paint(event.target.value); }); paint('');
    }
    document.querySelectorAll('[data-add-role]').forEach(function (button) { button.addEventListener('click', ui.action(function () { return openEditor(null); })); });
  }

  async function openEditor(role, onSaved) {
    var profiles = await store.list('llm-profiles');
    var llms = profiles.filter(function (item) { return item.enabled !== false || (role && item.id === role.llmProfileId); });
    if (!llms.length && !role) {
      await app.navigate('settings', { settingsTab: 'llm' });
      app.features.settings.openLlm(null, function () { return app.navigate('roles').then(function () { return openEditor(null, onSaved); }); });
      return;
    }
    var tts = await store.list('tts-profiles');
    var editing = Boolean(role);
    role = role || { id: u.id('role'), name: '', description: '', systemPrompt: '', llmProfileId: llms[0].id, ttsProfileId: '', avatarColor: '#59664d', enabled: true };
    function option(item, selected, label) { return '<option value="' + u.escapeHtml(item.id) + '"' + (item.id === selected ? ' selected' : '') + '>' + u.escapeHtml(label) + '</option>'; }
    var form = ui.openModal({ title: editing ? '编辑角色' : '创建你的 AI 搭档', eyebrow: 'PERSONA', submitText: editing ? '保存更改' : '创建角色', html: '<div class="form-grid">' + (!editing ? '<fieldset><legend>从一个灵感开始</legend><div class="chip-row">' + templates.map(function (item, i) { return '<button class="chip" type="button" data-template="' + i + '">' + u.escapeHtml(item.name) + '</button>'; }).join('') + '</div><p class="helper">点击填入示例，所有内容都可以改。</p></fieldset>' : '') + '<label class="field"><span>角色名称</span><input name="name" required maxlength="40" value="' + u.escapeHtml(role.name) + '" placeholder="你想怎么称呼这位搭档？"></label><label class="field"><span>一句话介绍 <em>选填</em></span><input name="description" maxlength="100" value="' + u.escapeHtml(role.description) + '" placeholder="这位角色擅长什么？"></label><label class="field"><span>角色提示词</span><textarea class="prompt-editor" name="systemPrompt" required maxlength="12000" placeholder="描述身份、目标与回答方式。">' + u.escapeHtml(role.systemPrompt) + '</textarea><small>决定它如何思考与表达，可随时修改。</small></label><label class="field"><span>使用的模型连接</span><select name="llmProfileId" required>' + (!llms.some(function (item) { return item.id === role.llmProfileId; }) ? '<option value="" selected>请选择可用连接</option>' : '') + llms.map(function (item) { return option(item, role.llmProfileId, item.name + ' · ' + item.model + (item.enabled === false ? '（已停用）' : '')); }).join('') + '</select></label><details class="advanced"><summary>外观与朗读</summary><div class="form-grid"><label class="field"><span>头像颜色</span><input class="role-color-input" name="avatarColor" type="color" value="' + u.escapeHtml(role.avatarColor) + '"></label><label class="field"><span>朗读声音</span><select name="ttsProfileId"><option value="">跟随通用设置</option>' + tts.filter(function (item) { return item.enabled !== false || item.id === role.ttsProfileId; }).map(function (item) { return option(item, role.ttsProfileId, item.name); }).join('') + '</select></label></div></details><label class="switch-row"><span><strong>启用角色</strong><small>停用后保留历史，暂停接收新消息</small></span><input name="enabled" type="checkbox"' + (role.enabled !== false ? ' checked' : '') + '></label>' + (editing ? '<button class="button danger full" type="button" data-delete-role>删除角色</button>' : '') + '</div>',
      onSubmit: async function (target) {
        var next = Object.assign({}, role, { name: u.formValue(target, 'name'), description: u.formValue(target, 'description'), systemPrompt: u.formValue(target, 'systemPrompt'), llmProfileId: u.formValue(target, 'llmProfileId'), ttsProfileId: u.formValue(target, 'ttsProfileId'), avatarColor: u.formValue(target, 'avatarColor'), enabled: u.checked(target, 'enabled'), updatedAt: Date.now(), createdAt: role.createdAt || Date.now() });
        if (!next.name || !next.systemPrompt) throw new Error('请填写角色名称与提示词');
        if (next.enabled && app.services.profiles.roleStatus(next, await store.list('llm-profiles'))) throw new Error('请为启用的角色选择一个可用模型连接');
        await store.put('roles', next.id, next); return next;
      }, onSuccess: async function (next) { ui.toast(editing ? '角色已更新' : '角色已创建'); if (onSaved) return onSaved(next); if (app.state.route === 'roles') await render(); }
    });
    form.querySelectorAll('[data-template]').forEach(function (button) { button.addEventListener('click', function () { var item = templates[Number(button.dataset.template)]; ['name', 'description'].forEach(function (key) { form.elements.namedItem(key).value = item[key]; }); form.elements.namedItem('systemPrompt').value = item.prompt; form.elements.namedItem('avatarColor').value = item.color; }); });
    var remove = form.querySelector('[data-delete-role]');
    if (remove) remove.addEventListener('click', ui.action(async function () {
      var refs = (await store.list('conversations')).filter(function (conversation) { return conversation.roleIds.indexOf(role.id) >= 0; });
      if (refs.length) { ui.toast('角色仍参与“' + refs[0].title + '”，请先编辑该对话的参与角色，或停用此角色', 5500); return; }
      if (await ui.confirm({ title: '删除“' + role.name + '”？', message: '角色提示词与模型绑定将从本机删除。', danger: true, confirmText: '删除角色' })) { await store.remove('roles', role.id); if (app.state.route === 'roles') await render(); }
    }));
  }
  app.features = app.features || {};
  app.features.roles = { render: render, openEditor: openEditor };
})(window.chataxi);
