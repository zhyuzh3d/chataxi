(function (app) {
  "use strict";
  var u = app.utils, ui = app.components, store = app.data.store, session = app.features.chatSession;
  var view = null;
  var revision = 0;
  function revoke(urls) { urls.splice(0).forEach(function (url) { URL.revokeObjectURL(url); }); }
  function alive(target) { return view === target && !target.closed; }
  function currentBusy(target) { return Boolean(session.active(target.conversation.id)); }

  async function render(id) {
    if (view) await close();
    var conversation = await store.get('conversations', id);
    if (!conversation) throw new Error('对话不存在');
    var roles = await store.list('roles'), profiles = await store.list('llm-profiles');
    var roleMap = {}; roles.forEach(function (role) { roleMap[role.id] = role; });
    var target = { conversation: conversation, roleMap: roleMap, profiles: profiles, settings: await store.get('meta', 'settings'), draft: await store.get('drafts', id) || { id: id, text: '', media: [] }, urls: [], draftUrls: [], follow: true, closed: false, io: false, speechStarting: false, draftQueue: Promise.resolve(), paint: 0, messageCache: {} };
    // Recover a draft whose user message was accepted before an interrupted draft-clear operation.
    var history = await store.messages(id), lastUser = history.filter(function (item) { return item.kind === 'user'; }).pop();
    if (lastUser && target.draft.messageId === lastUser.id) target.draft = { id: id, text: '', media: [] };
    target.draft.messageId = target.draft.messageId || u.id("message");
    view = target; app.state.activeConversationId = id;
    target.selected = (conversation.activeRoleIds || conversation.roleIds).filter(function (roleId) { return conversation.roleIds.indexOf(roleId) >= 0; });
    if (!target.selected.length) target.selected = conversation.roleIds.slice();
    var participants = conversation.roleIds.map(function (roleId) { return roleMap[roleId]; }).filter(Boolean);
    document.getElementById('appShell').classList.add('chat-open');
    document.getElementById('bottomNav').classList.add('is-hidden');
    document.getElementById('backButton').classList.remove('is-hidden');
    document.querySelector('#brandBlock .brand-mark').classList.add('is-hidden');
    ui.pageHeader(conversation.title, participants.map(function (role) { return role.name; }).join('、'), '<button class="icon-button" type="button" id="stopTtsButton" aria-label="停止朗读" title="停止朗读">' + ui.icon('volume-xmark') + '</button><button class="icon-button" type="button" id="chatMenuButton" aria-label="对话管理">' + ui.icon('ellipsis') + '</button>');
    var main = document.getElementById('mainContent'); main.className = 'main chat-main';
    main.innerHTML = '<section class="chat-layout"><div class="chat-role-strip">' + (conversation.kind === 'group' ? '<span class="strip-label">本轮回复</span><div class="chip-row"><button class="chip" type="button" data-all-roles>全部</button>' + participants.map(function (role) { return '<button class="chip" type="button" data-role-toggle="' + u.escapeHtml(role.id) + '" aria-pressed="' + (target.selected.indexOf(role.id) >= 0) + '">' + ui.avatar(role.name, role.avatarColor, 'tiny') + u.escapeHtml(role.name) + '</button>'; }).join('') + '</div>' : '<span class="single-chat-note">' + ui.icon('comment-dots') + '文字、图片和语音，都从这里开始</span>') + '</div><div class="message-viewport"><div class="message-list" id="messageList" aria-label="对话消息"><div class="message-list-inner" id="messageListInner"></div></div><button type="button" class="button secondary jump-latest is-hidden" id="jumpLatest">' + ui.icon('arrow-down') + '回到最新</button></div><div class="composer"><div class="composer-inner"><div class="attachment-tray is-hidden" id="attachmentTray"></div><div class="composer-box"><textarea id="messageInput" rows="1" maxlength="16000" placeholder="把你的想法写在这里…" aria-label="消息内容"></textarea><div class="composer-toolbar"><div class="row"><button class="icon-button" type="button" id="imageButton" aria-label="添加图片，最多四张" title="添加图片">' + ui.icon('image') + '</button><button class="icon-button" type="button" id="micButton" aria-label="语音输入" title="语音输入">' + ui.icon('microphone') + '</button><span class="composer-hint" id="composerHint"></span></div><button type="button" class="icon-button send-button" id="sendButton" aria-label="发送消息">' + ui.icon('arrow-up') + '</button></div></div><div class="composer-footer"><span id="composerStatus" role="status" aria-live="polite"></span><span id="draftStatus"></span></div></div></div></section>';
    var input = document.getElementById('messageInput'); input.value = target.draft.text || '';
    resizeInput(input);
    input.addEventListener('input', function () { target.draft.text = input.value; resizeInput(input); queueDraft(target); syncComposer(target); });
    input.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' && !event.isComposing && event.keyCode !== 229 && !event.shiftKey && (event.ctrlKey || event.metaKey || target.settings.enterToSend)) { event.preventDefault(); if (!currentBusy(target)) send(target); }
    });
    document.getElementById('sendButton').addEventListener('click', function () { if (currentBusy(target)) { session.stop(id); status(target, '已停止后续回复；已发出的服务请求可能仍计费'); } else send(target); });
    document.getElementById('imageButton').addEventListener('click', ui.action(function () { return chooseImage(target); }));
    document.getElementById('micButton').addEventListener('click', ui.action(function () { return handleSpeech(target); }));
    document.getElementById('chatMenuButton').addEventListener('click', ui.action(function () { return app.features.conversations.manage(id); }));
    document.getElementById('stopTtsButton').addEventListener('click', ui.action(async function () { await app.services.tts.stop(); status(target, '已停止朗读'); }));
    document.getElementById('jumpLatest').addEventListener('click', function () { target.follow = true; scrollBottom(target); });
    document.getElementById('messageList').addEventListener('scroll', function () { var list = document.getElementById('messageList'); target.follow = list.scrollHeight - list.scrollTop - list.clientHeight < 100; document.getElementById('jumpLatest').classList.toggle('is-hidden', target.follow); });
    main.querySelectorAll('[data-role-toggle], [data-all-roles]').forEach(function (button) { button.addEventListener('click', ui.action(async function () {
      if (currentBusy(target)) return;
      var selected = target.selected.slice(), roleId = button.dataset.roleToggle;
      if (!roleId) selected = conversation.roleIds.slice();
      else if (selected.indexOf(roleId) >= 0) { if (selected.length === 1) { ui.toast('至少保留一位回复角色'); return; } selected = selected.filter(function (item) { return item !== roleId; }); }
      else selected.push(roleId);
      var next = await store.get('conversations', id); next.activeRoleIds = conversation.roleIds.filter(function (item) { return selected.indexOf(item) >= 0; });
      await store.put('conversations', id, next); target.selected = next.activeRoleIds;
      syncComposer(target);
    })); });
    var picker = document.getElementById('imagePicker');
    picker.onchange = ui.action(async function () { var files = Array.prototype.slice.call(picker.files || []); picker.value = ''; if (!alive(target)) return; await addFiles(target, files); });
    document.getElementById('audioPicker').onchange = ui.action(async function (event) { var file = event.target.files && event.target.files[0]; event.target.value = ''; if (file && alive(target)) await transcribe(target, file); });
    target.unsubscribe = app.events.on('chat:changed', function (event) {
      if (!alive(target) || event.conversationId !== id) return;
      if (event.phase === 'accepted') {
        target.draft = { id: id, messageId: u.id('message'), text: '', media: [] }; input.value = ''; resizeInput(input); renderDraft(target).catch(showError);
      }
      if (event.phase === 'notice') status(target, event.text);
      else if (event.phase === 'idle') status(target, event.stopped ? '本轮已停止，可重试已停止的回复' : '本轮完成');
      else if (event.phase === 'generating') status(target, session.active(id).label);
      syncComposer(target); renderMessages(target).catch(showError);
    });
    await session.recover(id); await renderDraft(target); await renderMessages(target, true); syncComposer(target);
  }
  function showError(error) { ui.toast(u.cleanError(error), 5000); }
  function status(target, text) { if (alive(target)) document.getElementById('composerStatus').textContent = text; }
  function resizeInput(input) { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 160) + 'px'; }
  function queueDraft(target) { clearTimeout(target.draftTimer); document.getElementById('draftStatus').textContent = '正在保存草稿…'; target.draftTimer = setTimeout(function () { flushDraft(target).catch(function (error) { if (alive(target)) document.getElementById('draftStatus').textContent = '草稿未保存'; showError(error); }); }, 300); }
  function flushDraft(target) {
    clearTimeout(target.draftTimer);
    var draft = u.clone(target.draft); draft.updatedAt = Date.now();
    target.draftQueue = target.draftQueue.catch(function () {}).then(async function () {
      if (draft.text || draft.media.length) await store.put('drafts', target.conversation.id, draft); else await store.remove('drafts', target.conversation.id);
      if (alive(target)) document.getElementById('draftStatus').textContent = draft.text || draft.media.length ? '草稿已保存' : '';
    });
    return target.draftQueue;
  }
  function syncComposer(target) {
    if (!alive(target)) return;
    var busy = currentBusy(target), unavailable = target.selected.some(function (id) { return !target.roleMap[id] || app.services.profiles.roleStatus(target.roleMap[id], target.profiles); });
    var send = document.getElementById('sendButton'); send.innerHTML = ui.icon(busy ? 'stop' : 'arrow-up'); send.setAttribute('aria-label', busy ? '停止本轮回复' : '发送消息'); send.classList.toggle('stopping', busy);
    send.disabled = !busy && (target.io || target.speechStarting || Boolean(target.speechId) || unavailable || (!target.draft.text.trim() && !target.draft.media.length));
    document.getElementById('messageInput').readOnly = busy;
    document.getElementById('imageButton').disabled = busy || target.io;
    document.getElementById('micButton').disabled = busy || target.io || target.speechStarting;
    document.getElementById('composerHint').textContent = busy ? '点击方块停止' : unavailable ? '角色配置需要修复' : target.conversation.kind === 'group' ? '将调用 ' + target.selected.length + ' 位角色' : target.settings.enterToSend ? 'Enter 发送' : 'Enter 换行';
    document.querySelectorAll('[data-role-toggle]').forEach(function (button) { button.disabled = busy; button.setAttribute('aria-pressed', String(target.selected.indexOf(button.dataset.roleToggle) >= 0)); });
    var all = document.querySelector('[data-all-roles]'); if (all) { all.disabled = busy; all.setAttribute('aria-pressed', String(target.selected.length === target.conversation.roleIds.length)); }
    if (unavailable && !busy) status(target, '当前角色或模型已停用，请在角色页修复配置');
  }
  function scrollBottom(target) {
    if (!alive(target)) return;
    var list = document.getElementById('messageList'); list.scrollTop = list.scrollHeight; document.getElementById('jumpLatest').classList.add('is-hidden');
  }
  async function renderMessages(target, forceBottom) {
    target = target || view; if (!target || !alive(target)) return;
    var paint = ++target.paint, messages = await store.messages(target.conversation.id);
    var nodes = [], cache = {}, urls = [], lastDate = '';
    if (!messages.length) {
      var empty = document.createElement('div'); empty.className = 'chat-welcome';
      var participants = target.conversation.roleIds.map(function (id) { return target.roleMap[id]; }).filter(Boolean);
      empty.innerHTML = '<div class="chat-welcome-avatars">' + participants.slice(0, 3).map(function (role) { return ui.avatar(role.name, role.avatarColor, 'large'); }).join('') + '</div><h2>聊点什么？</h2><p>' + u.escapeHtml(participants.length === 1 ? participants[0].description || '从一个问题或想法开始。' : '让不同的视角，带来更多可能。') + '</p><div class="starter-list"><button class="starter" type="button">介绍一下你自己</button><button class="starter" type="button">帮我梳理一个想法</button><button class="starter" type="button">我们一起制定一个计划</button></div>';
      empty.querySelectorAll('.starter').forEach(function (button) { button.addEventListener('click', function () { if (target.draft.text.trim()) { document.getElementById('messageInput').focus(); return; } target.draft.text = button.textContent; var input = document.getElementById('messageInput'); input.value = target.draft.text; input.dispatchEvent(new Event('input')); input.focus(); }); }); nodes.push(empty);
    }
    for (var i = 0; i < messages.length; i += 1) {
      var date = new Date(messages[i].createdAt).toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' });
      if (date !== lastDate) { var separator = document.createElement('div'); separator.className = 'date-divider'; separator.textContent = date; nodes.push(separator); lastDate = date; }
      var signature = JSON.stringify(messages[i]) + ((messages[i].status === "error" || messages[i].status === "cancelled") ? String(currentBusy(target)) : ""), cached = target.messageCache[messages[i].id];
      var node = cached && cached.signature === signature ? cached.node : await messageElement(messages[i], target, urls);
      cache[messages[i].id] = { signature: signature, node: node }; nodes.push(node);
    }
    if (!alive(target) || paint !== target.paint) { revoke(urls); return; }
    var list = document.getElementById('messageList'), top = list.scrollTop, inner = document.getElementById('messageListInner');
    target.urls = target.urls.concat(urls); target.messageCache = cache;
    var fragment = document.createDocumentFragment(); nodes.forEach(function (node) { fragment.appendChild(node); });
    inner.textContent = ''; inner.appendChild(fragment);
    if (forceBottom || target.follow) requestAnimationFrame(function () { scrollBottom(target); }); else list.scrollTop = top;
  }
  async function messageElement(message, target, urls) {
    var user = message.kind === 'user', role = target.roleMap[message.roleId];
    var row = document.createElement('article'); row.className = 'message-row ' + (user ? 'user' : 'assistant'); row.dataset.messageId = message.id;
    if (!user) { var avatar = document.createElement('div'); avatar.innerHTML = ui.avatar(role ? role.name : message.roleName, role ? role.avatarColor : '', 'message-avatar'); row.appendChild(avatar.firstChild); }
    var block = document.createElement('div'); block.className = 'message-block';
    var name = document.createElement('div'); name.className = 'message-name'; name.textContent = user ? '我' : role ? role.name : message.roleName || 'AI'; block.appendChild(name);
    var bubble = document.createElement('div'); bubble.className = 'message-bubble';
    for (var i = 0; i < (message.media || []).length; i += 1) {
      var media = message.media[i], src = '';
      try {
        if (media.mediaId) { var record = await app.data.media.get(media.mediaId); if (record) { src = URL.createObjectURL(record.blob); urls.push(src); } }
        else if (u.isAllowedImageUrl(media.url)) src = media.url;
      } catch (_) {}
      if (!src) { var missing = document.createElement('p'); missing.className = 'helper'; missing.textContent = '图片不可用，文字记录仍保留'; bubble.appendChild(missing); continue; }
      var imageButton = document.createElement('button'); imageButton.type = 'button'; imageButton.className = 'message-image'; imageButton.setAttribute('aria-label', '查看完整图片');
      var image = document.createElement('img'); image.alt = media.alt || '对话图片'; image.referrerPolicy = 'no-referrer'; image.src = src;
      image.onload = function () { if (target.follow) scrollBottom(target); };
      image.onerror = function () { this.alt = '图片加载失败'; this.parentNode.setAttribute('aria-label', '图片加载失败'); };
      imageButton.appendChild(image);
      imageButton.addEventListener('click', function (event) { var selected = event.currentTarget.querySelector('img'); ui.openModal({ title: '查看图片', cancelText: null, submitText: '关闭', html: '<img class="image-preview" referrerpolicy="no-referrer" src="' + u.escapeHtml(selected.src) + '" alt="完整对话图片">', onSubmit: function () {} }); }); bubble.appendChild(imageButton);
    }
    if (message.status === 'pending') { var typing = document.createElement('div'); typing.className = 'typing-bubble'; typing.setAttribute('aria-label', '正在生成回复'); typing.innerHTML = '<span></span><span></span><span></span>'; bubble.appendChild(typing); }
    if (message.text) { var text = document.createElement('div'); text.className = 'message-text'; text.textContent = message.text; bubble.appendChild(text); }
    if (message.status === 'error' || message.status === 'cancelled') {
      var error = document.createElement('p'); error.className = 'message-error'; error.textContent = message.error || '生成失败'; bubble.appendChild(error);
      var retry = document.createElement('button'); retry.type = 'button'; retry.className = 'button ghost'; retry.textContent = '重试这条回复'; retry.disabled = currentBusy(target);
      retry.addEventListener('click', function () { run(target, { retryId: message.id }); }); bubble.appendChild(retry);
    }
    block.appendChild(bubble);
    var meta = document.createElement('div'); meta.className = 'message-meta';
    var time = document.createElement('time'); time.textContent = u.formatTime(message.createdAt); meta.appendChild(time);
    if (message.contextTrimmed) { var note = document.createElement('span'); note.className = 'context-badge'; note.textContent = '已裁剪上下文'; note.title = '这次请求只发送了部分历史，完整记录仍保存在本机'; meta.appendChild(note); }
    if (message.text) {
      var copy = document.createElement('button'); copy.type = 'button'; copy.className = 'icon-button'; copy.setAttribute('aria-label', '复制这条消息'); copy.innerHTML = ui.icon('copy'); copy.addEventListener('click', ui.action(async function () { await app.platform.hermit.copyText(message.text); ui.toast('已复制'); })); meta.appendChild(copy);
      if (!user && message.status === 'done') { var speak = document.createElement('button'); speak.type = 'button'; speak.className = 'icon-button'; speak.setAttribute('aria-label', '朗读这条回复'); speak.innerHTML = ui.icon('volume-high'); speak.addEventListener('click', ui.action(function () { return app.services.tts.speak(message.text, role); })); meta.appendChild(speak); }
    }
    block.appendChild(meta); row.appendChild(block); return row;
  }
  async function send(target) {
    if (!alive(target) || target.io || target.speechStarting || target.speechId || currentBusy(target)) return;
    target.io = true; syncComposer(target);
    try { await flushDraft(target); target.follow = true; await run(target, { userMessageId: target.draft.messageId, text: target.draft.text, media: target.draft.media.slice(), roleIds: target.selected.slice() }); }
    catch (error) { showError(error); status(target, '发送未完成，已保存的内容仍然保留'); }
    finally { target.io = false; syncComposer(target); }
  }
  async function run(target, options) {
    if (!alive(target) || currentBusy(target)) return;
    target.job = session.run(target.conversation.id, options);
    syncComposer(target);
    try { await target.job; } catch (error) { showError(error); status(target, u.cleanError(error)); }
    finally { target.job = null; syncComposer(target); }
  }
  async function addMedia(target, media) {
    if (!alive(target)) { if (media.mediaId) await store.releaseMedia([media.mediaId]); return; }
    target.draft.media.push(media);
    await flushDraft(target); await renderDraft(target); syncComposer(target);
  }
  async function addFiles(target, files) {
    if (!alive(target) || target.io || currentBusy(target)) return;
    if (target.draft.media.length + files.length > 4) throw new Error('每条消息最多选择四张图片');
    target.io = true; syncComposer(target);
    try { for (var i = 0; i < files.length; i += 1) await addMedia(target, await app.services.images.compress(files[i])); }
    finally { target.io = false; if (alive(target)) { await renderDraft(target); syncComposer(target); } }
  }
  async function chooseImage(target) {
    if (target.draft.media.length >= 4) { ui.toast('每条消息最多选择四张图片'); return; }
    if (!app.platform.hermit.available()) { document.getElementById('imagePicker').click(); return; }
    target.io = true; syncComposer(target);
    try {
      var selected = await app.platform.hermit.api().files.pickImage({ maxDimension: 1280, maxBytes: 420 * 1024 });
      if (!selected || selected.cancelled || !alive(target)) return;
      var parts = u.dataUrlToParts(selected.dataUrl);
      if (!parts || !u.isAllowedImageUrl(selected.dataUrl)) throw new Error('没有取得可用图片');
      var blob = u.base64ToBlob(parts.data, parts.mime), record = await app.data.media.put(blob, { name: selected.name || 'image.jpg', mime: parts.mime });
      await addMedia(target, { mediaId: record.id, mime: record.mime, size: blob.size, alt: '用户选择的图片' });
    } finally { target.io = false; syncComposer(target); }
  }
  async function renderDraft(target) {
    if (!alive(target)) return;
    var paint = ++revision, fragment = document.createDocumentFragment(), urls = [];
    for (var i = 0; i < target.draft.media.length; i += 1) {
      var media = target.draft.media[i], record = await app.data.media.get(media.mediaId);
      var item = document.createElement('div'); item.className = 'attachment';
      if (record) { var image = document.createElement('img'); image.src = URL.createObjectURL(record.blob); urls.push(image.src); image.alt = '待发送图片 ' + (i + 1); item.appendChild(image); }
      else item.textContent = '图片丢失';
      var remove = document.createElement('button'); remove.type = 'button'; remove.className = 'icon-button'; remove.dataset.mediaId = media.mediaId; remove.setAttribute('aria-label', '移除待发送图片'); remove.innerHTML = ui.icon('xmark');
      remove.addEventListener('click', ui.action(async function (event) { if (currentBusy(target)) return; var id = event.currentTarget.dataset.mediaId; target.draft.media = target.draft.media.filter(function (entry) { return entry.mediaId !== id; }); await flushDraft(target); await store.releaseMedia([id]); await renderDraft(target); syncComposer(target); })); item.appendChild(remove); fragment.appendChild(item);
    }
    if (!alive(target) || paint !== revision) { revoke(urls); return; }
    revoke(target.draftUrls); target.draftUrls = urls;
    var tray = document.getElementById('attachmentTray'); tray.textContent = ''; tray.appendChild(fragment); tray.classList.toggle('is-hidden', !target.draft.media.length);
  }
  async function transcribe(target, file) {
    if (!alive(target) || target.io) return;
    target.io = true; syncComposer(target); status(target, '正在识别音频…');
    try { var profile = await store.get('asr-profiles', target.settings.defaultAsrProfileId); var text = await app.services.asr.transcribeFile(file, profile); appendTranscript(target, text); }
    catch (error) { showError(error); status(target, '识别失败，仍可输入文字'); }
    finally { target.io = false; syncComposer(target); }
  }
  function appendTranscript(target, text) {
    if (!alive(target)) return;
    var input = document.getElementById('messageInput');
    var combined = (input.value ? input.value + ' ' : '') + text;
    if (combined.length > input.maxLength) { ui.toast('识别结果超过输入上限，请先缩短草稿后重试', 4500); return; }
    input.value = combined; input.dispatchEvent(new Event('input')); status(target, '识别完成，请检查文字后发送');
  }
  async function handleSpeech(target) {
    if (!alive(target)) return;
    if (target.speechId) { await app.services.asr.stopSystem(target.speechId); status(target, '正在整理识别结果…'); return; }
    if (target.speechStarting || target.io || currentBusy(target)) return;
    target.speechStarting = true; syncComposer(target);
    try {
      var profile = await store.get('asr-profiles', target.settings.defaultAsrProfileId || 'system-asr');
      if (!profile || profile.enabled === false) throw new Error('请在设置中选择可用的默认语音输入');
      if (profile.type !== 'system') {
        target.speechStarting = false;
        if (!app.platform.hermit.available()) { document.getElementById('audioPicker').click(); return; }
        target.io = true; syncComposer(target); status(target, '请选择一段短音频…');
        var selected = await app.platform.hermit.api().files.pickInline({ accept: 'audio/*', maxBytes: 650 * 1024 });
        target.io = false;
        if (!selected || selected.cancelled || !alive(target)) { status(target, '已取消语音输入'); return; }
        var parts = u.dataUrlToParts(selected.dataUrl); if (!parts || !/^audio\//i.test(parts.mime)) throw new Error('所选文件不是有效音频');
        var file = u.base64ToBlob(parts.data, parts.mime); file.name = selected.name || 'audio.m4a'; await transcribe(target, file); return;
      }
      var ended = false;
      function finish(text) { ended = true; target.speechId = null; target.speechStarting = false; if (alive(target)) { var button = document.getElementById('micButton'); button.classList.remove('recording'); button.innerHTML = ui.icon('microphone'); button.setAttribute('aria-label', '语音输入'); if (text) status(target, text); syncComposer(target); } }
      status(target, '正在准备语音识别…');
      var subscription = await app.services.asr.startSystem(profile, {
        ready: function () { status(target, '请开始说话'); }, begin: function () { status(target, '正在聆听，点击语音按钮结束'); },
        partial: function (data) { if (data.alternatives && data.alternatives[0]) status(target, data.alternatives[0].text); },
        final: function (data) { if (data.alternatives && data.alternatives[0]) appendTranscript(target, data.alternatives[0].text); finish(); },
        error: function (data) { finish('识别失败：' + (data.message || data.code || '请稍后重试')); },
        end: function () { if (!ended) status(target, '正在整理识别结果…'); }
      });
      if (!alive(target)) { await app.services.asr.cancelSystem(); return; }
      if (!ended) { target.speechId = subscription; var button = document.getElementById('micButton'); button.classList.add('recording'); button.innerHTML = ui.icon('stop'); button.setAttribute('aria-label', '结束语音识别'); }
    } catch (error) { showError(error); status(target, '语音输入不可用，可继续输入文字或更换识别服务'); }
    finally { target.io = false; target.speechStarting = false; syncComposer(target); }
  }
  async function close() {
    var target = view; if (!target) return;
    await flushDraft(target);
    session.stop(target.conversation.id);
    target.closed = true; target.unsubscribe();
    if (target.speechId || target.speechStarting) await app.services.asr.cancelSystem().catch(function () {});
    await app.services.tts.stop().catch(function () {});
    if (target.job) await target.job.catch(function () {});
    view = null; app.state.activeConversationId = null;
    revoke(target.urls); revoke(target.draftUrls);
    document.getElementById('imagePicker').onchange = null; document.getElementById('audioPicker').onchange = null;
  }
  document.addEventListener('visibilitychange', function () { if (document.hidden && view) flushDraft(view).catch(showError); });
  app.events.on('tts:error', function (event) { ui.toast(event.message, 5000); });
  app.events.on('tts:state', function (event) { if (view) { var button = document.getElementById('stopTtsButton'); if (button) { button.classList.toggle('voice-active', event.speaking); button.setAttribute('aria-label', event.speaking ? '正在朗读，点击停止' : '停止朗读'); } } });
  app.features = app.features || {};
  app.features.chat = { render: render, close: close, renderMessages: function () { return renderMessages(view); } };
})(window.chataxi);
