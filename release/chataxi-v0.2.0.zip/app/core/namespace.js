(function (global) {
  "use strict";
  global.chataxi = global.chataxi || {};
  global.chataxi.version = "0.2.0";
  global.chataxi.state = { route: "conversations", activeConversationId: null, settingsTab: "llm" };
})(window);
