(function (app) {
  "use strict";
  var u = app.utils, ui = app.components, store = app.data.store;
  var names = { llm: "语言模型", tts: "朗读", asr: "语音输入" };
  var icons = { llm: "brain", tts: "volume-high", asr: "microphone" };
  var testing = {};

  function field(name, label, value, attrs) {
    return '<label class="field"><span>' + label + '</span><input name="' + name + '" value="' + u.escapeHtml(value || '') + '" ' + (attrs || '') + '></label>';
  }
  function familyOf(kind, service) { return app.services.modelServices.family(kind, service.family || service.type); }
  function collection(kind) { return kind + "-profiles"; }
  function familyItems(kind) { return app.services.modelServices.families(kind).filter(function (item) { return item.id !== "system"; }).map(function (item) { return { id: item.id, name: item.name + " · " + item.description }; }); }
  function apiStyleItems() { return app.services.catalog.apiStyles.map(function (item) { return { id: item.id, name: item.name }; }); }
  function secretField(service) {
    return '<label class="field"><span>API Key <em>' + (service.apiKey ? '已保存' : '保存在当前设备') + '</em></span><input name="apiKey" type="password" autocomplete="new-password" spellcheck="false" placeholder="' + (service.apiKey ? '留空保留现有密钥' : '粘贴 API Key') + '"></label>' +
      (service.apiKey ? '<label class="check-line"><input name="clearApiKey" type="checkbox">清除已保存的 API Key</label>' : '');
  }
  function modelText(service) {
    return app.services.modelServices.models("llm", service).map(function (item) { return item.name || item.id; }).slice(0, 3).join("、") || "保存后在角色中填写或获取模型";
  }

  async function render() {
    var kind = app.state.modelsTab || "llm";
    if (!names[kind]) kind = app.state.modelsTab = "llm";
    ui.pageHeader("模型", "服务与模型能力");
    var main = document.getElementById("mainContent"); main.className = "main";
    main.innerHTML = '<section class="page models-page"><div class="section-tabs" role="tablist" aria-label="模型服务分类">' + Object.keys(names).map(function (key) {
      return '<button type="button" role="tab" id="models-tab-' + key + '" aria-controls="modelsContent" data-model-tab="' + key + '" aria-selected="' + (key === kind) + '">' + ui.icon(icons[key]) + '<span>' + names[key] + '</span></button>';
    }).join("") + '</div><div id="modelsContent" role="tabpanel" aria-labelledby="models-tab-' + kind + '"></div></section>';
    main.querySelectorAll("[data-model-tab]").forEach(function (button) {
      button.addEventListener("click", ui.action(async function () { app.state.modelsTab = button.dataset.modelTab; await render(); }));
    });
    await renderServices(kind);
  }

  async function renderServices(kind) {
    var services = await store.list(collection(kind));
    if (app.state.route !== "models" || app.state.modelsTab !== kind) return;
    var content = document.getElementById("modelsContent");
    var note = kind === "llm" ? "这里连接模型家族；具体模型、温度、输出长度和推理强度在角色中设置。" : kind === "tts" ? "这里连接朗读模型家族；具体模型、音色和音色提示词在角色中设置。" : "Android 系统识别默认可用；对话可覆盖识别服务、模型和语言。";
    content.innerHTML = '<div class="section-toolbar"><p>' + note + '</p><button class="button primary compact" type="button" data-add-service>' + ui.icon("plus") + '添加服务</button></div><div class="list model-service-list">' + services.map(function (service) {
      var definition = familyOf(kind, service), system = definition.id === "system";
      var statusText = service.enabled === false ? "已停用" : system ? "系统默认" : service.apiKey ? "已配置" : definition.keyOptional ? "可连接" : "待填写密钥";
      var modelCount = app.services.modelServices.models(kind, service).length;
      var detail = kind === "llm" ? modelText(service) : kind === "tts" ? (modelCount + " 个模型 · " + app.services.modelServices.voices(service).length + " 个音色") : modelCount + " 个识别模型";
      var actions = (!system && (definition.modelsEndpoint || definition.voicesEndpoint) ? '<button class="button ghost" type="button" data-discover="' + u.escapeHtml(service.id) + '">' + ui.icon("arrows-rotate") + (kind === "tts" && definition.voicesEndpoint ? "更新音色" : "更新模型") + '</button>' : '') +
        (kind !== "asr" ? '<button class="button secondary" type="button" data-test-service="' + u.escapeHtml(service.id) + '"' + (testing[service.id] || service.enabled === false ? ' disabled' : '') + '>' + ui.icon(kind === "llm" ? "plug" : "play") + (testing[service.id] ? "测试中…" : kind === "llm" ? "测试" : "试听") + '</button>' : '') +
        (!system ? '<span class="grow"></span><button class="button ghost" type="button" data-edit-service="' + u.escapeHtml(service.id) + '">' + ui.icon("pen") + '编辑</button><button class="icon-button danger-text" type="button" data-remove-service="' + u.escapeHtml(service.id) + '" aria-label="删除服务">' + ui.icon("trash") + '</button>' : '');
      return '<article class="card model-service-card"><div class="service-summary"><span class="service-icon">' + ui.icon(icons[kind]) + '</span><div class="list-copy"><strong>' + u.escapeHtml(service.name || definition.name) + '</strong><span>' + u.escapeHtml(definition.name + " · " + detail) + '</span></div><span class="badge ' + (service.enabled === false ? "warning" : "success") + '">' + statusText + '</span></div>' + (!system && service.endpoint ? '<div class="service-endpoint">' + u.escapeHtml(service.endpoint) + '</div>' : '') + (actions ? '<div class="profile-actions">' + actions + '</div>' : '') + '</article>';
    }).join("") + '</div>';
    content.querySelector("[data-add-service]").addEventListener("click", function () { openService(kind); });
    content.querySelectorAll("[data-edit-service]").forEach(function (button) { button.addEventListener("click", ui.action(async function () { openService(kind, await store.get(collection(kind), button.dataset.editService)); })); });
    content.querySelectorAll("[data-remove-service]").forEach(function (button) { button.addEventListener("click", ui.action(async function () {
      var service = await store.get(collection(kind), button.dataset.removeService);
      var message = kind === "llm" ? "将删除保存在当前设备上的这项服务配置；角色正在使用时不能删除。" : "将删除这项服务配置；相关默认、角色或对话设置会回落到 Android 系统服务。";
      if (await ui.confirm({ title: "删除“" + service.name + "”？", message: message, confirmText: "删除服务", danger: true })) { await app.services.profiles.remove(kind, service.id); ui.toast("服务已删除"); await renderServices(kind); }
    })); });
    content.querySelectorAll("[data-discover]").forEach(function (button) { button.addEventListener("click", ui.action(async function () {
      button.disabled = true;
      try { var service = await store.get(collection(kind), button.dataset.discover); await app.services.modelServices.discover(kind, service); ui.toast(kind === "tts" ? "音色列表已更新" : "模型列表已更新"); await renderServices(kind); }
      finally { button.disabled = false; }
    })); });
    content.querySelectorAll("[data-test-service]").forEach(function (button) { button.addEventListener("click", ui.action(async function () {
      var id = button.dataset.testService, service = await store.get(collection(kind), id); testing[id] = true; await renderServices(kind);
      try {
        if (kind === "llm") await app.services.llm.test(service, (app.services.modelServices.models(kind, service)[0] || {}).id);
        else await app.services.tts.speak("你好，这是一段 ChatTaxi 朗读测试。", { ttsProfileId: id, ttsModel: (app.services.modelServices.models(kind, service)[0] || {}).id, ttsVoice: (app.services.modelServices.voices(service)[0] || {}).id });
        ui.toast(kind === "llm" ? "模型服务连接成功" : "已开始试听");
      } finally { delete testing[id]; await renderServices(kind); }
    })); });
  }

  function openService(kind, existing, onSaved) {
    var editing = Boolean(existing);
    var initialFamily = existing ? (existing.family || existing.type || "custom") : "openai";
    var definition = app.services.modelServices.family(kind, initialFamily);
    var service = existing || { id: u.id(kind), family: initialFamily, name: definition.name, enabled: true, models: [], voices: [] };
    var html = '<div class="form-grid service-editor">' + ui.picker("family", "模型家族", "") + '<p class="helper" id="familyDescription"></p>' + secretField(service) +
      '<div class="automation-note">' + ui.icon("wand-magic-sparkles") + '<span>协议与地址已按模型家族自动填写；需要兼容私有网关时可在更多设置中修改。</span></div>' +
      '<details class="advanced"><summary>更多设置</summary><div class="form-grid">' + field("name", "服务名称", service.name || definition.name, 'maxlength="80"') + field("endpoint", "完整请求地址", service.endpoint || definition.endpoint, 'type="url"') + (kind === "llm" ? ui.picker("apiStyle", "接口协议", "") : '') + '<label class="field"><span>' + (kind === "tts" ? "TTS 模型 ID" : kind === "asr" ? "识别模型 ID" : "模型 ID") + '</span><textarea name="modelsText" spellcheck="false" placeholder="每行一个模型 ID">' + u.escapeHtml((service.models || []).map(function (item) { return typeof item === "string" ? item : item.id; }).join("\n") || service.model || "") + '</textarea></label>' + (kind === "tts" ? '<label class="field"><span>音色 ID</span><textarea name="voicesText" spellcheck="false" placeholder="每行一个 Voice ID">' + u.escapeHtml((service.voices || []).map(function (item) { return typeof item === "string" ? item : item.id; }).join("\n") || service.voice || "") + '</textarea></label>' : '') + '<label class="field"><span>自定义 Header <em>JSON，选填</em></span><textarea name="customHeaders" spellcheck="false" placeholder="{&quot;X-Client&quot;:&quot;chataxi&quot;}">' + u.escapeHtml(service.customHeaders || "") + '</textarea></label></div></details>' +
      '<label class="switch-row"><span><strong>启用服务</strong><small>停用后保留配置，但角色和对话不能调用</small></span><input name="enabled" type="checkbox"' + (service.enabled !== false ? ' checked' : '') + '></label></div>';
    var form = ui.openModal({ title: (editing ? "编辑" : "添加") + names[kind] + "服务", submitText: editing ? "保存更改" : "连接服务", html: html, onSubmit: async function (target) {
      var familyId = u.formValue(target, "family"), family = app.services.modelServices.family(kind, familyId);
      var sameFamily = (service.family || service.type) === familyId;
      var models = u.formValue(target, "modelsText").split(/[\n,，]/).map(function (value) { return value.trim(); }).filter(Boolean);
      var voices = kind === "tts" ? u.formValue(target, "voicesText").split(/[\n,，]/).map(function (value) { return value.trim(); }).filter(Boolean) : service.voices || [];
      var apiKey = u.checked(target, "clearApiKey") ? "" : u.formValue(target, "apiKey") || (sameFamily ? service.apiKey || "" : "");
      var next = Object.assign({}, service, {
        family: familyId,
        type: family.type || familyId,
        name: u.formValue(target, "name") || family.name,
        endpoint: u.formValue(target, "endpoint") || family.endpoint,
        apiStyle: kind === "llm" ? u.formValue(target, "apiStyle") || family.apiStyle : undefined,
        apiKey: apiKey,
        customHeaders: u.formValue(target, "customHeaders"),
        models: models,
        voices: voices,
        enabled: u.checked(target, "enabled"),
        updatedAt: Date.now(),
        createdAt: service.createdAt || Date.now()
      });
      if (!next.endpoint) throw new Error("请填写服务地址"); u.validateEndpoint(next.endpoint); u.parseHeaders(next.customHeaders); if (!next.name) throw new Error("请填写服务名称");
      if ((family.customEndpoint || family.editableProtocol) && !app.services.modelServices.models(kind, next).length) throw new Error("请在更多设置中填写至少一个模型 ID");
      if (!family.keyOptional && !next.apiKey) throw new Error("请填写 API Key");
      await app.services.profiles.validateEnabled(kind, next);
      await store.put(collection(kind), next.id, next); return next;
    }, onSuccess: async function (next) { ui.toast("服务已保存"); if (onSaved) return onSaved(next); if (app.state.route === "models") await renderServices(kind); } });
    ui.bindPicker(form, "family", familyItems(kind), initialFamily);
    var apiStylePicker = kind === "llm" ? ui.bindPicker(form, "apiStyle", apiStyleItems(), service.apiStyle || definition.apiStyle) : null;
    function syncFamily(reset) {
      var family = app.services.modelServices.family(kind, form.elements.namedItem("family").value);
      form.querySelector("#familyDescription").textContent = family.description;
      if (reset) { form.elements.namedItem("name").value = family.name; form.elements.namedItem("endpoint").value = family.endpoint || ""; form.elements.namedItem("modelsText").value = ""; if (form.elements.namedItem("voicesText")) form.elements.namedItem("voicesText").value = ""; form.elements.namedItem("customHeaders").value = ""; if (apiStylePicker) apiStylePicker.setItems(apiStyleItems(), family.apiStyle || "openai-responses"); }
    }
    form.elements.namedItem("family").addEventListener("change", function () { syncFamily(true); }); syncFamily(false);
    return form;
  }

  app.features = app.features || {};
  app.features.models = { render: render, renderServices: renderServices, openService: openService };
})(window.chataxi);
