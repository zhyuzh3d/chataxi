(function (global) {
  "use strict";
  global.ChatTaxi = global.ChatTaxi || {};
  global.ChatTaxi.version = "0.1.0";
  global.ChatTaxi.state = {
    route: "conversations",
    previousRoute: null,
    activeConversationId: null,
    settingsTab: "llm",
    sending: false,
    speechSubscriptionId: null,
    draftMedia: [],
    selectedRoleIds: []
  };
})(window);
