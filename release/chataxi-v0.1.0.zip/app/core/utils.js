(function (app) {
  "use strict";

  function id(prefix) {
    var random = "";
    if (window.crypto && window.crypto.getRandomValues) {
      var values = new Uint32Array(3);
      window.crypto.getRandomValues(values);
      random = Array.prototype.map.call(values, function (value) { return value.toString(36); }).join("");
    } else {
      random = Math.random().toString(36).slice(2) + Date.now().toString(36);
    }
    return (prefix || "id") + "_" + random;
  }

  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function formatTime(timestamp) {
    var date = new Date(timestamp);
    var now = new Date();
    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
    }
    return date.toLocaleDateString("zh-CN", { month: "numeric", day: "numeric" });
  }

  function debounce(fn, delay) {
    var timer = null;
    return function () {
      var args = arguments;
      var context = this;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(context, args); }, delay);
    };
  }

  function safeJsonParse(text, fallback) {
    try { return JSON.parse(text); } catch (_) { return fallback; }
  }

  function cleanError(error) {
    var raw = error && error.message ? error.message : String(error || "未知错误");
    return raw
      .replace(/Bearer\s+[A-Za-z0-9._~+\/-]+/gi, "Bearer ***")
      .replace(/(api[-_ ]?key[\"'=:\s]+)[A-Za-z0-9._~+\/-]{8,}/gi, "$1***")
      .slice(0, 500);
  }

  function dataUrlToParts(dataUrl) {
    var match = /^data:([^;,]+);base64,([A-Za-z0-9+/=\s]+)$/.exec(dataUrl || "");
    return match ? { mime: match[1], data: match[2].replace(/\s/g, "") } : null;
  }

  function blobToDataUrl(blob) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(String(reader.result)); };
      reader.onerror = function () { reject(reader.error || new Error("无法读取文件")); };
      reader.readAsDataURL(blob);
    });
  }

  function bytesToBase64(bytes) {
    var chunk = 0x8000;
    var binary = "";
    for (var index = 0; index < bytes.length; index += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(index, Math.min(index + chunk, bytes.length)));
    }
    return btoa(binary);
  }

  function base64ToBlob(value, mime) {
    var binary = atob(String(value || "").replace(/\s/g, ""));
    var bytes = new Uint8Array(binary.length);
    for (var index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return new Blob([bytes], { type: mime || "application/octet-stream" });
  }

  function isAllowedImageUrl(value) {
    if (!value || typeof value !== "string") return false;
    if (/^data:image\/(jpeg|png|webp|gif);base64,/i.test(value)) return true;
    try { return new URL(value).protocol === "https:"; } catch (_) { return false; }
  }

  function formValue(form, name) {
    var element = form.elements.namedItem(name);
    return element ? String(element.value || "").trim() : "";
  }

  function checked(form, name) {
    var element = form.elements.namedItem(name);
    return Boolean(element && element.checked);
  }

  function fileSafeName(name) {
    return String(name || "file").replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 100) || "file";
  }

  app.utils = {
    id: id,
    clone: clone,
    escapeHtml: escapeHtml,
    formatTime: formatTime,
    debounce: debounce,
    safeJsonParse: safeJsonParse,
    cleanError: cleanError,
    dataUrlToParts: dataUrlToParts,
    blobToDataUrl: blobToDataUrl,
    bytesToBase64: bytesToBase64,
    base64ToBlob: base64ToBlob,
    isAllowedImageUrl: isAllowedImageUrl,
    formValue: formValue,
    checked: checked,
    fileSafeName: fileSafeName
  };
})(window.ChatTaxi);
