(function (app) {
  "use strict";

  async function startSystem(profile, callbacks) {
    if (!(await app.platform.hermit.awaitReady(1200))) throw new Error("系统语音识别只在 HermitApp 中可用");
    var unsubscribers = [];
    ["ready", "begin", "partial", "final", "error", "end"].forEach(function (kind) {
      unsubscribers.push(app.platform.hermit.on("speech." + kind, function (data) {
        if (callbacks && callbacks[kind]) callbacks[kind](data || {});
        if (kind === "final" || kind === "error") unsubscribers.splice(0).forEach(function (unsubscribe) { unsubscribe(); });
      }));
    });
    try {
      var result = await app.platform.hermit.api().speech.start({
        language: profile.language || "zh-CN",
        partial: true,
        maxResults: 3,
        onDevice: Boolean(profile.onDevice)
      });
      return result.subscriptionId;
    } catch (error) {
      unsubscribers.splice(0).forEach(function (unsubscribe) { unsubscribe(); });
      throw error;
    }
  }

  async function stopSystem(subscriptionId) {
    if (!app.platform.hermit.available()) return;
    await app.platform.hermit.api().speech.stop({ subscriptionId: subscriptionId || undefined });
  }

  async function cancelSystem() {
    if (!app.platform.hermit.available()) return;
    await app.platform.hermit.api().speech.cancel();
  }

  function multipart(fields, file) {
    var boundary = "----ChatTaxi" + app.utils.id("boundary").replace(/[^A-Za-z0-9]/g, "");
    var encoder = new TextEncoder();
    var chunks = [];
    Object.keys(fields).forEach(function (name) {
      if (fields[name] == null || fields[name] === "") return;
      chunks.push(encoder.encode("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + fields[name] + "\r\n"));
    });
    chunks.push(encoder.encode("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"" + app.utils.fileSafeName(file.name) + "\"\r\nContent-Type: " + (file.type || "application/octet-stream") + "\r\n\r\n"));
    chunks.push(file.bytes);
    chunks.push(encoder.encode("\r\n--" + boundary + "--\r\n"));
    var length = chunks.reduce(function (total, chunk) { return total + chunk.length; }, 0);
    var output = new Uint8Array(length);
    var offset = 0;
    chunks.forEach(function (chunk) { output.set(chunk, offset); offset += chunk.length; });
    return { bytes: output, contentType: "multipart/form-data; boundary=" + boundary };
  }

  async function transcribeFile(file, profile) {
    if (!file) throw new Error("请选择或录制一段音频");
    if (file.size > 650 * 1024) throw new Error("当前 Hermit 网络接口要求音频不超过 650 KiB，请缩短录音");
    var bytes = new Uint8Array(await file.arrayBuffer());
    var body = multipart({ model: profile.model, language: profile.language, response_format: "json" }, { name: file.name || "recording.m4a", type: file.type, bytes: bytes });
    if (body.bytes.length > 900 * 1024) throw new Error("音频请求超过 900 KiB");
    var headers = {};
    if (profile.apiKey) headers.Authorization = "Bearer " + profile.apiKey;
    var extra = app.utils.safeJsonParse(profile.customHeaders || "{}", {});
    Object.keys(extra || {}).forEach(function (key) { headers[key] = String(extra[key]); });
    var result = await app.platform.network.request({
      url: profile.endpoint,
      method: "POST",
      headers: headers,
      bodyBytes: body.bytes,
      contentType: body.contentType,
      timeoutMs: 120000
    });
    var bodyText = await app.platform.network.readText(result);
    var data = app.utils.safeJsonParse(bodyText, null);
    if (result.status < 200 || result.status >= 300) throw new Error("语音识别请求失败（" + result.status + "）");
    var text = data && (data.text || data.transcript || (data.result && data.result.text));
    if (!text) throw new Error("语音识别服务没有返回文本");
    return String(text);
  }

  app.services.asr = { startSystem: startSystem, stopSystem: stopSystem, cancelSystem: cancelSystem, multipart: multipart, transcribeFile: transcribeFile };
})(window.ChatTaxi);
