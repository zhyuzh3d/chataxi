(function (app) {
  "use strict";
  var activeAudio = null;
  var activePlaybackId = null;

  async function stop() {
    if (activeAudio) {
      activeAudio.pause();
      if (activeAudio.src && activeAudio.src.indexOf("blob:") === 0) URL.revokeObjectURL(activeAudio.src);
      activeAudio = null;
    }
    if (activePlaybackId && app.platform.hermit.available()) {
      try { await app.platform.hermit.api().audio.stopPlayback({ playbackId: activePlaybackId }); } catch (_) {}
      activePlaybackId = null;
    }
    if (app.platform.hermit.available()) {
      try { await app.platform.hermit.api().tts.stop(); } catch (_) {}
    }
    app.events.emit("tts:state", { speaking: false });
  }

  function ttsHeaders(profile) {
    var result = { "Content-Type": "application/json" };
    if (profile.apiKey) {
      if (profile.type === "elevenlabs") result["xi-api-key"] = profile.apiKey;
      else result.Authorization = "Bearer " + profile.apiKey;
    }
    var extra = app.utils.safeJsonParse(profile.customHeaders || "{}", {});
    Object.keys(extra || {}).forEach(function (key) { result[key] = String(extra[key]); });
    return result;
  }

  async function playNetworkResult(result, format) {
    if (result.file && result.file.logicalFileId && app.platform.hermit.available()) {
      var playback = await app.platform.hermit.api().audio.play({ logicalFileId: result.file.logicalFileId });
      activePlaybackId = playback.playbackId;
      return;
    }
    if (!result.bodyBase64) throw new Error("语音服务没有返回可播放音频");
    var mime = (result.headers && (result.headers["content-type"] || result.headers["Content-Type"])) || (format === "wav" ? "audio/wav" : "audio/mpeg");
    var blob = app.utils.base64ToBlob(result.bodyBase64, mime);
    activeAudio = new Audio(URL.createObjectURL(blob));
    activeAudio.onended = function () { stop(); };
    await activeAudio.play();
  }

  async function speak(text, role) {
    var clean = String(text || "").trim().slice(0, 10000);
    if (!clean) return;
    await stop();
    var settings = await app.data.store.get("meta", "settings");
    var profileId = role && role.ttsProfileId ? role.ttsProfileId : settings.defaultTtsProfileId;
    var profile = await app.data.store.get("tts-profiles", profileId || "system-tts");
    if (!profile || !profile.enabled) throw new Error("朗读配置不存在或已停用");
    app.events.emit("tts:state", { speaking: true });
    try {
      if (profile.type === "system") {
        if (!(await app.platform.hermit.awaitReady(1000))) throw new Error("系统朗读只在 HermitApp 中可用");
        await app.platform.hermit.api().tts.speak({
          text: clean,
          language: profile.language || settings.language || "zh-CN",
          rate: Number(profile.rate || 1),
          pitch: Number(profile.pitch || 1)
        });
        return;
      }
      var endpoint = String(profile.endpoint || "").replace(/\{voice\}/g, encodeURIComponent(profile.voice || ""));
      var body;
      if (profile.type === "elevenlabs") {
        body = { text: clean, model_id: profile.model || "eleven_multilingual_v2" };
      } else {
        body = { model: profile.model, input: clean, voice: profile.voice, response_format: profile.format || "mp3" };
        if (profile.instructions) body.instructions = profile.instructions;
      }
      var result = await app.platform.network.request({
        url: endpoint,
        method: "POST",
        headers: ttsHeaders(profile),
        bodyText: JSON.stringify(body),
        contentType: "application/json",
        timeoutMs: 90000
      });
      if (result.status < 200 || result.status >= 300) throw new Error("朗读服务请求失败（" + result.status + "）");
      await playNetworkResult(result, profile.format);
    } catch (error) {
      app.events.emit("tts:state", { speaking: false });
      throw error;
    }
  }

  app.services.tts = { speak: speak, stop: stop, headers: ttsHeaders };
})(window.ChatTaxi);
