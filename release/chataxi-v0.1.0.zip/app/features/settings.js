(function (app) {
  "use strict";
  var utils = app.utils;
  var ui = app.components;

  function option(value, label, selected) {
    return '<option value="' + utils.escapeHtml(value) + '"' + (value === selected ? " selected" : "") + '>' + utils.escapeHtml(label) + '</option>';
  }

  function secretField(existing) {
    return '<label class="field"><span>API Key / Token</span><div class="secret-wrap"><input name="apiKey" type="password" autocomplete="off" placeholder="' + (existing ? "已保存；留空保持不变" : "未填写") + '"><button class="icon-button" type="button" data-toggle-secret aria-label="显示或隐藏密钥">' + ui.icon("eye") + '</button></div><small>建议在手机只保存权限受限的网关 Token。</small></label>';
  }

  function bindSecretToggle(form) {
    var button = form.querySelector("[data-toggle-secret]");
    if (!button) return;
    button.addEventListener("click", function () {
      var input = form.elements.namedItem("apiKey");
      input.type = input.type === "password" ? "text" : "password";
      button.innerHTML = ui.icon(input.type === "password" ? "eye" : "eye-slash");
    });
  }

  async function render() {
    var tab = app.state.settingsTab || "llm";
    var main = document.getElementById("mainContent");
    main.className = "main";
    document.getElementById("pageTitle").textContent = "设置";
    document.getElementById("pageSubtitle").textContent = "模型、声音与偏好";
    document.getElementById("topbarActions").innerHTML = "";
    main.innerHTML = '<section class="page"><div class="settings-tabs"><div class="chip-row" role="tablist">' +
      [{ id: "llm", name: "LLM" }, { id: "tts", name: "朗读" }, { id: "asr", name: "语音输入" }, { id: "general", name: "通用" }]
        .map(function (item) { return '<button class="chip" type="button" role="tab" data-settings-tab="' + item.id + '" aria-selected="' + (tab === item.id) + '">' + item.name + '</button>'; }).join("") +
      '</div></div><div id="settingsContent"></div></section>';
    main.querySelectorAll("[data-settings-tab]").forEach(function (button) {
      button.addEventListener("click", function () { app.state.settingsTab = button.dataset.settingsTab; render(); });
    });
    if (tab === "llm") await renderLlm();
    else if (tab === "tts") await renderTts();
    else if (tab === "asr") await renderAsr();
    else await renderGeneral();
  }

  async function renderLlm() {
    var profiles = (await app.data.store.list("llm-profiles")).sort(function (a, b) { return a.name.localeCompare(b.name, "zh-CN"); });
    var content = document.getElementById("settingsContent");
    content.innerHTML = '<div class="row-between page-intro"><span>角色通过这里连接模型服务。</span><button class="button primary" type="button" data-add-llm>' + ui.icon("plus") + '添加</button></div>' +
      (profiles.length ? '<div class="list">' + profiles.map(function (profile) {
        return '<article class="card card-body"><div class="row-between"><div class="list-copy"><strong>' + utils.escapeHtml(profile.name) + '</strong><span>' + utils.escapeHtml(profile.model || "未填写模型") + '</span></div><span class="badge">' + utils.escapeHtml(profile.enabled ? "启用" : "停用") + '</span></div><p class="muted">' + utils.escapeHtml(profile.apiStyle) + ' · ' + utils.escapeHtml(profile.endpoint) + '</p><div class="row"><button class="button secondary grow" type="button" data-test-llm="' + profile.id + '">' + ui.icon("plug") + '测试</button><button class="icon-button" type="button" data-edit-llm="' + profile.id + '" aria-label="编辑">' + ui.icon("pen") + '</button><button class="icon-button danger-text" type="button" data-delete-llm="' + profile.id + '" aria-label="删除">' + ui.icon("trash") + '</button></div></article>';
      }).join("") + '</div>' : ui.empty("server", "还没有模型连接", "先添加 llmserver 或你的模型供应商。", '<button class="button primary" type="button" data-add-llm>' + ui.icon("plus") + '添加 LLM</button>'));
    content.querySelectorAll("[data-add-llm]").forEach(function (button) { button.addEventListener("click", function () { openLlm(null); }); });
    content.querySelectorAll("[data-edit-llm]").forEach(function (button) { button.addEventListener("click", async function () { openLlm(await app.data.store.get("llm-profiles", button.dataset.editLlm)); }); });
    content.querySelectorAll("[data-test-llm]").forEach(function (button) { button.addEventListener("click", async function () {
      button.disabled = true; button.innerHTML = '<span class="spinner"></span> 测试中';
      try { var profile = await app.data.store.get("llm-profiles", button.dataset.testLlm); var result = await app.services.llm.test(profile); ui.toast("连接成功：" + (result.text || "收到图片")); }
      catch (error) { ui.toast(utils.cleanError(error), 5000); }
      finally { renderLlm(); }
    }); });
    content.querySelectorAll("[data-delete-llm]").forEach(function (button) { button.addEventListener("click", function () { deleteLlm(button.dataset.deleteLlm); }); });
  }

  function openLlm(profile) {
    var editing = Boolean(profile);
    profile = profile || { id: utils.id("llm"), name: "", family: "custom", apiStyle: "openai-responses", endpoint: "", model: "", maxOutputTokens: 1024, temperature: "", reasoningEffort: "", customHeaders: "", allowImageGeneration: false, enabled: true };
    var presets = app.services.catalog.llmPresets;
    var form = ui.openModal({
      title: editing ? "编辑 LLM" : "添加 LLM",
      html: '<div class="form-grid"><label class="field"><span>供应商预设</span><select name="preset">' + option("", "不套用预设", "") + presets.map(function (item) { return option(item.id, item.name, ""); }).join("") + '</select><small>预设只填充表单，地址和协议仍可编辑。</small></label>' +
        '<label class="field"><span>连接名称</span><input name="name" maxlength="80" required value="' + utils.escapeHtml(profile.name) + '" placeholder="例如：家里 llmserver"></label>' +
        '<label class="field"><span>接口协议</span><select name="apiStyle">' + app.services.catalog.apiStyles.map(function (item) { return option(item.id, item.name, profile.apiStyle); }).join("") + '</select></label>' +
        '<label class="field"><span>完整请求地址</span><input name="endpoint" type="url" required value="' + utils.escapeHtml(profile.endpoint) + '" placeholder="http://192.168.1.2:4815/v1/responses"></label>' +
        '<label class="field"><span>模型名称</span><input name="model" required value="' + utils.escapeHtml(profile.model) + '" placeholder="使用服务实际公布的模型 ID"></label>' + secretField(Boolean(profile.apiKey)) +
        '<div class="row"><label class="field grow"><span>最大输出 Token</span><input name="maxOutputTokens" type="number" min="32" max="32768" value="' + Number(profile.maxOutputTokens || 1024) + '"></label><label class="field grow"><span>温度（可空）</span><input name="temperature" type="number" min="0" max="2" step="0.1" value="' + utils.escapeHtml(profile.temperature == null ? "" : profile.temperature) + '"></label></div>' +
        '<label class="field"><span>推理强度（Responses，可空）</span><select name="reasoningEffort">' + ["", "none", "low", "medium", "high", "xhigh", "max", "ultra"].map(function (value) { return option(value, value || "使用服务默认", profile.reasoningEffort || ""); }).join("") + '</select></label>' +
        '<label class="field"><span>自定义 Header（JSON）</span><textarea name="customHeaders" spellcheck="false" placeholder="{&quot;X-Client&quot;:&quot;ChatTaxi&quot;}">' + utils.escapeHtml(profile.customHeaders || "") + '</textarea></label>' +
        '<label class="switch-row"><span>允许 Responses 图片生成工具</span><input name="allowImageGeneration" type="checkbox"' + (profile.allowImageGeneration ? " checked" : "") + '></label>' +
        '<label class="switch-row"><span>启用此连接</span><input name="enabled" type="checkbox"' + (profile.enabled !== false ? " checked" : "") + '></label></div>',
      onSubmit: async function (target) {
        var next = {
          id: profile.id,
          name: utils.formValue(target, "name"),
          family: target.dataset.family || profile.family || "custom",
          apiStyle: utils.formValue(target, "apiStyle"),
          endpoint: utils.formValue(target, "endpoint"),
          model: utils.formValue(target, "model"),
          apiKey: utils.formValue(target, "apiKey") || profile.apiKey || "",
          maxOutputTokens: Number(utils.formValue(target, "maxOutputTokens") || 1024),
          temperature: utils.formValue(target, "temperature"),
          reasoningEffort: utils.formValue(target, "reasoningEffort"),
          customHeaders: utils.formValue(target, "customHeaders"),
          allowImageGeneration: utils.checked(target, "allowImageGeneration"),
          enabled: utils.checked(target, "enabled"),
          updatedAt: Date.now()
        };
        app.services.providers.build(next, { systemPrompt: "" }, [{ role: "user", text: "test", images: [] }]);
        await app.data.store.put("llm-profiles", next.id, next);
        ui.toast("LLM 配置已保存");
        await renderLlm();
      }
    });
    bindSecretToggle(form);
    form.elements.namedItem("preset").addEventListener("change", function (event) {
      var preset = presets.find(function (item) { return item.id === event.target.value; });
      if (!preset) return;
      form.dataset.family = preset.family;
      form.elements.namedItem("name").value = preset.name;
      form.elements.namedItem("apiStyle").value = preset.apiStyle;
      form.elements.namedItem("endpoint").value = preset.endpoint;
      form.elements.namedItem("model").value = preset.model;
    });
  }

  async function deleteLlm(id) {
    var roles = await app.data.store.list("roles");
    var refs = roles.filter(function (role) { return role.llmProfileId === id; });
    if (refs.length) { ui.toast("仍被角色“" + refs[0].name + "”使用，不能删除", 4200); return; }
    if (await ui.confirm({ title: "删除模型连接", message: "此操作只删除本机配置，不影响供应商账户。", confirmText: "删除", danger: true })) {
      await app.data.store.remove("llm-profiles", id); await renderLlm();
    }
  }

  async function renderTts() {
    var profiles = await app.data.store.list("tts-profiles");
    var content = document.getElementById("settingsContent");
    content.innerHTML = '<div class="row-between page-intro"><span>默认使用 Android 系统朗读。</span><button class="button primary" type="button" data-add-tts>' + ui.icon("plus") + '添加</button></div><div class="list">' + profiles.map(function (profile) {
      return '<article class="card card-body"><div class="row-between"><div class="list-copy"><strong>' + utils.escapeHtml(profile.name) + '</strong><span>' + utils.escapeHtml(profile.type === "system" ? "设备系统能力" : (profile.model || profile.endpoint)) + '</span></div><span class="badge">' + (profile.enabled ? "启用" : "停用") + '</span></div><div class="row"><button class="button secondary grow" type="button" data-test-tts="' + profile.id + '">' + ui.icon("volume-high") + '试听</button><button class="icon-button" type="button" data-edit-tts="' + profile.id + '" aria-label="编辑">' + ui.icon("pen") + '</button>' + (profile.type === "system" ? "" : '<button class="icon-button danger-text" type="button" data-delete-tts="' + profile.id + '" aria-label="删除">' + ui.icon("trash") + '</button>') + '</div></article>';
    }).join("") + '</div>';
    content.querySelector("[data-add-tts]").addEventListener("click", function () { openTts(null); });
    content.querySelectorAll("[data-edit-tts]").forEach(function (button) { button.addEventListener("click", async function () { openTts(await app.data.store.get("tts-profiles", button.dataset.editTts)); }); });
    content.querySelectorAll("[data-test-tts]").forEach(function (button) { button.addEventListener("click", async function () { try { await app.services.tts.speak("你好，我是 ChatTaxi 的语音助手。", { ttsProfileId: button.dataset.testTts }); } catch (error) { ui.toast(utils.cleanError(error), 4800); } }); });
    content.querySelectorAll("[data-delete-tts]").forEach(function (button) { button.addEventListener("click", async function () { if (await ui.confirm({ title: "删除朗读配置", message: "使用它的角色将改用系统默认朗读。", confirmText: "删除", danger: true })) { await app.data.store.remove("tts-profiles", button.dataset.deleteTts); await renderTts(); } }); });
  }

  function openTts(profile) {
    var editing = Boolean(profile);
    profile = profile || { id: utils.id("tts"), name: "", type: "openai", endpoint: "", model: "", voice: "", format: "mp3", rate: 1, pitch: 1, customHeaders: "", enabled: true };
    var system = profile.type === "system";
    var presets = app.services.catalog.ttsPresets;
    var form = ui.openModal({ title: editing ? "编辑朗读配置" : "添加朗读配置", html: '<div class="form-grid">' +
      (system ? "" : '<label class="field"><span>预设</span><select name="preset">' + option("", "不套用预设", "") + presets.map(function (item) { return option(item.id, item.name, ""); }).join("") + '</select></label>') +
      '<label class="field"><span>名称</span><input name="name" required maxlength="80" value="' + utils.escapeHtml(profile.name) + '"></label>' +
      (system ? '<div class="row"><label class="field grow"><span>语速</span><input name="rate" type="number" min="0.25" max="2" step="0.05" value="' + Number(profile.rate || 1) + '"></label><label class="field grow"><span>音调</span><input name="pitch" type="number" min="0.5" max="2" step="0.05" value="' + Number(profile.pitch || 1) + '"></label></div>' :
      '<label class="field"><span>类型</span><select name="type">' + ["openai", "elevenlabs", "custom"].map(function (value) { return option(value, value, profile.type); }).join("") + '</select></label><label class="field"><span>完整请求地址</span><input name="endpoint" type="url" required value="' + utils.escapeHtml(profile.endpoint) + '"></label><div class="row"><label class="field grow"><span>模型</span><input name="model" value="' + utils.escapeHtml(profile.model) + '"></label><label class="field grow"><span>声音 / Voice ID</span><input name="voice" value="' + utils.escapeHtml(profile.voice) + '"></label></div>' + secretField(Boolean(profile.apiKey)) + '<label class="field"><span>自定义 Header（JSON）</span><textarea name="customHeaders">' + utils.escapeHtml(profile.customHeaders || "") + '</textarea></label>') +
      '<label class="switch-row"><span>启用</span><input name="enabled" type="checkbox"' + (profile.enabled !== false ? " checked" : "") + '></label></div>', onSubmit: async function (target) {
        var next = Object.assign({}, profile, { name: utils.formValue(target, "name"), enabled: utils.checked(target, "enabled"), updatedAt: Date.now() });
        if (system) { next.rate = Number(utils.formValue(target, "rate") || 1); next.pitch = Number(utils.formValue(target, "pitch") || 1); }
        else { next.type = utils.formValue(target, "type"); next.endpoint = utils.formValue(target, "endpoint"); next.model = utils.formValue(target, "model"); next.voice = utils.formValue(target, "voice"); next.apiKey = utils.formValue(target, "apiKey") || profile.apiKey || ""; next.customHeaders = utils.formValue(target, "customHeaders"); next.format = profile.format || "mp3"; }
        await app.data.store.put("tts-profiles", next.id, next); ui.toast("朗读配置已保存"); await renderTts();
      } });
    bindSecretToggle(form);
    if (!system) form.elements.namedItem("preset").addEventListener("change", function (event) { var preset = presets.find(function (item) { return item.id === event.target.value; }); if (!preset) return; ["name", "type", "endpoint", "model", "voice"].forEach(function (name) { form.elements.namedItem(name).value = preset[name] || ""; }); });
  }

  async function renderAsr() {
    var profiles = await app.data.store.list("asr-profiles");
    var content = document.getElementById("settingsContent");
    content.innerHTML = '<div class="row-between page-intro"><span>识别结果只填入编辑器，不自动发送。</span><button class="button primary" type="button" data-add-asr>' + ui.icon("plus") + '添加</button></div><div class="list">' + profiles.map(function (profile) {
      return '<article class="card card-body"><div class="row-between"><div class="list-copy"><strong>' + utils.escapeHtml(profile.name) + '</strong><span>' + utils.escapeHtml(profile.type === "system" ? "设备系统能力" : (profile.model || profile.endpoint)) + '</span></div><span class="badge">' + (profile.enabled ? "启用" : "停用") + '</span></div><div class="row"><button class="icon-button" type="button" data-edit-asr="' + profile.id + '" aria-label="编辑">' + ui.icon("pen") + '</button>' + (profile.type === "system" ? "" : '<button class="icon-button danger-text" type="button" data-delete-asr="' + profile.id + '" aria-label="删除">' + ui.icon("trash") + '</button>') + '</div></article>';
    }).join("") + '</div>';
    content.querySelector("[data-add-asr]").addEventListener("click", function () { openAsr(null); });
    content.querySelectorAll("[data-edit-asr]").forEach(function (button) { button.addEventListener("click", async function () { openAsr(await app.data.store.get("asr-profiles", button.dataset.editAsr)); }); });
    content.querySelectorAll("[data-delete-asr]").forEach(function (button) { button.addEventListener("click", async function () { if (await ui.confirm({ title: "删除语音识别配置", message: "删除后可继续使用 Android 系统语音识别。", confirmText: "删除", danger: true })) { await app.data.store.remove("asr-profiles", button.dataset.deleteAsr); await renderAsr(); } }); });
  }

  function openAsr(profile) {
    var editing = Boolean(profile);
    profile = profile || { id: utils.id("asr"), name: "", type: "openai", endpoint: "", model: "", language: "zh", onDevice: false, customHeaders: "", enabled: true };
    var system = profile.type === "system";
    var presets = app.services.catalog.asrPresets;
    var form = ui.openModal({ title: editing ? "编辑语音输入" : "添加语音输入", html: '<div class="form-grid">' +
      (system ? "" : '<label class="field"><span>预设</span><select name="preset">' + option("", "不套用预设", "") + presets.map(function (item) { return option(item.id, item.name, ""); }).join("") + '</select></label>') + '<label class="field"><span>名称</span><input name="name" required value="' + utils.escapeHtml(profile.name) + '"></label><label class="field"><span>语言</span><input name="language" value="' + utils.escapeHtml(profile.language || "zh-CN") + '"></label>' +
      (system ? '<label class="switch-row"><span>强制设备离线识别（设备不支持时失败）</span><input name="onDevice" type="checkbox"' + (profile.onDevice ? " checked" : "") + '></label>' : '<label class="field"><span>类型</span><select name="type">' + ["openai", "custom"].map(function (value) { return option(value, value, profile.type); }).join("") + '</select></label><label class="field"><span>完整请求地址</span><input name="endpoint" type="url" required value="' + utils.escapeHtml(profile.endpoint) + '"></label><label class="field"><span>模型</span><input name="model" required value="' + utils.escapeHtml(profile.model) + '"></label>' + secretField(Boolean(profile.apiKey)) + '<label class="field"><span>自定义 Header（JSON）</span><textarea name="customHeaders">' + utils.escapeHtml(profile.customHeaders || "") + '</textarea></label><div class="inline-status">' + ui.icon("circle-info") + '<span>第三方识别通过 Android 录音/文件选择器取得音频，当前限制 650 KiB。</span></div>') +
      '<label class="switch-row"><span>启用</span><input name="enabled" type="checkbox"' + (profile.enabled !== false ? " checked" : "") + '></label></div>', onSubmit: async function (target) {
        var next = Object.assign({}, profile, { name: utils.formValue(target, "name"), language: utils.formValue(target, "language"), enabled: utils.checked(target, "enabled"), updatedAt: Date.now() });
        if (system) next.onDevice = utils.checked(target, "onDevice");
        else { next.type = utils.formValue(target, "type"); next.endpoint = utils.formValue(target, "endpoint"); next.model = utils.formValue(target, "model"); next.apiKey = utils.formValue(target, "apiKey") || profile.apiKey || ""; next.customHeaders = utils.formValue(target, "customHeaders"); }
        await app.data.store.put("asr-profiles", next.id, next); ui.toast("语音输入配置已保存"); await renderAsr();
      } });
    bindSecretToggle(form);
    if (!system) form.elements.namedItem("preset").addEventListener("change", function (event) { var preset = presets.find(function (item) { return item.id === event.target.value; }); if (!preset) return; ["name", "type", "endpoint", "model", "language"].forEach(function (name) { form.elements.namedItem(name).value = preset[name] || ""; }); });
  }

  async function renderGeneral() {
    var settings = await app.data.store.get("meta", "settings");
    var ttsProfiles = await app.data.store.list("tts-profiles");
    var asrProfiles = await app.data.store.list("asr-profiles");
    var info = await app.platform.hermit.info();
    var content = document.getElementById("settingsContent");
    content.innerHTML = '<form class="card card-body form-grid" id="generalForm"><label class="switch-row"><span><strong>自动朗读新回复</strong><small class="muted">只朗读本轮新生成的文字</small></span><input name="autoSpeak" type="checkbox"' + (settings.autoSpeak ? " checked" : "") + '></label><label class="field"><span>默认朗读</span><select name="defaultTtsProfileId">' + ttsProfiles.filter(function (item) { return item.enabled; }).map(function (item) { return option(item.id, item.name, settings.defaultTtsProfileId); }).join("") + '</select></label><label class="field"><span>默认语音输入</span><select name="defaultAsrProfileId">' + asrProfiles.filter(function (item) { return item.enabled; }).map(function (item) { return option(item.id, item.name, settings.defaultAsrProfileId); }).join("") + '</select></label><label class="field"><span>默认语言</span><input name="language" value="' + utils.escapeHtml(settings.language || "zh-CN") + '"></label><label class="field"><span>发送给模型的历史消息数</span><input name="historyLimit" type="number" min="4" max="100" value="' + Number(settings.historyLimit || 40) + '"></label><button class="button primary" type="submit">保存通用设置</button></form><div class="section-heading"><h2>运行环境</h2></div><div class="card card-body stack"><div class="row-between"><span>数据后端</span><strong>' + utils.escapeHtml(app.data.store.backend() === "hermit" ? "Hermit 应用数据" : "浏览器 localStorage") + '</strong></div><div class="row-between"><span>运行方式</span><strong>' + utils.escapeHtml(info.runtimeMode || "unknown") + '</strong></div><div class="row-between"><span>Bridge</span><strong>' + utils.escapeHtml(info.bridgeMode || "none") + '</strong></div><p class="muted">线上实时模式只应加载你信任的 ChatTaxi 代码；当前页面代码在发起请求时能够读取已保存密钥。</p></div>';
    document.getElementById("generalForm").addEventListener("submit", async function (event) { event.preventDefault(); var form = event.currentTarget; settings.autoSpeak = utils.checked(form, "autoSpeak"); settings.defaultTtsProfileId = utils.formValue(form, "defaultTtsProfileId"); settings.defaultAsrProfileId = utils.formValue(form, "defaultAsrProfileId"); settings.language = utils.formValue(form, "language"); settings.historyLimit = Number(utils.formValue(form, "historyLimit") || 40); await app.data.store.put("meta", "settings", settings); ui.toast("通用设置已保存"); });
  }

  app.features = app.features || {};
  app.features.settings = { render: render };
})(window.ChatTaxi);
