(function (app) {
  "use strict";
  var utils = app.utils;
  var ui = app.components;
  var messageObjectUrls = [];
  var draftObjectUrls = [];

  function revokeObjectUrls(list) {
    list.splice(0).forEach(function (url) { try { URL.revokeObjectURL(url); } catch (_) {} });
  }

  async function render(conversationId) {
    var conversation = await app.data.store.get("conversations", conversationId);
    if (!conversation) { ui.toast("对话不存在"); app.navigate("conversations"); return; }
    var roles = await app.data.store.list("roles");
    var roleMap = {};
    roles.forEach(function (role) { roleMap[role.id] = role; });
    var participants = (conversation.roleIds || []).map(function (id) { return roleMap[id]; }).filter(Boolean);
    app.state.activeConversationId = conversationId;
    if (!app.state.selectedRoleIds.length || app.state.selectedRoleIds.some(function (id) { return conversation.roleIds.indexOf(id) < 0; })) {
      app.state.selectedRoleIds = (conversation.activeRoleIds && conversation.activeRoleIds.length ? conversation.activeRoleIds : conversation.roleIds).slice();
    }
    document.getElementById("appShell").classList.add("chat-open");
    document.getElementById("bottomNav").classList.add("is-hidden");
    document.getElementById("backButton").classList.remove("is-hidden");
    document.getElementById("brandBlock").querySelector(".brand-mark").classList.add("is-hidden");
    document.getElementById("pageTitle").textContent = conversation.title;
    document.getElementById("pageSubtitle").textContent = participants.map(function (role) { return role.name; }).join("、");
    document.getElementById("topbarActions").innerHTML = '<button class="icon-button" type="button" data-stop-tts aria-label="停止朗读">' + ui.icon("volume-xmark") + '</button><button class="icon-button danger-text" type="button" data-delete-conversation aria-label="删除对话">' + ui.icon("trash") + '</button>';
    var main = document.getElementById("mainContent");
    main.className = "main chat-main";
    main.innerHTML = '<section class="chat-layout">' +
      (conversation.kind === "group" ? '<div class="chat-role-strip"><div class="chip-row" aria-label="本轮回复角色">' + participants.map(function (role) { var selected = app.state.selectedRoleIds.indexOf(role.id) >= 0; return '<button type="button" class="chip" data-role-toggle="' + role.id + '" aria-pressed="' + selected + '">' + ui.avatar(role.name, role.avatarColor, "message-avatar") + utils.escapeHtml(role.name) + '</button>'; }).join("") + '</div></div>' : '<div></div>') +
      '<div class="message-list" id="messageList"><div class="message-list-inner" id="messageListInner"><div class="boot-state"><span class="spinner"></span></div></div></div>' +
      '<div class="composer"><div class="composer-inner"><div class="attachment-tray is-hidden" id="attachmentTray"></div><div class="composer-row"><button class="icon-button attachment-button" id="imageButton" type="button" aria-label="选择图片">' + ui.icon("image") + '</button><textarea id="messageInput" rows="1" maxlength="20000" placeholder="输入消息…" aria-label="消息内容"></textarea><button class="icon-button" id="micButton" type="button" aria-label="语音输入">' + ui.icon("microphone") + '</button><button class="icon-button send-button" id="sendButton" type="button" aria-label="发送">' + ui.icon("arrow-up") + '</button></div><div class="context-note" id="composerStatus" role="status">识别文字后不会自动发送</div></div></div>' +
      '</section>';
    main.querySelectorAll("[data-role-toggle]").forEach(function (button) { button.addEventListener("click", function () { toggleRole(conversation, button.dataset.roleToggle); }); });
    document.querySelector("[data-stop-tts]").addEventListener("click", function () { app.services.tts.stop(); });
    document.querySelector("[data-delete-conversation]").addEventListener("click", async function () {
      if (await ui.confirm({ title: "删除对话", message: "对话和消息将从本机删除，此操作无法撤销。", confirmText: "删除", danger: true })) {
        var messages = await app.data.store.messages(conversation.id);
        for (var index = 0; index < messages.length; index += 1) {
          var media = messages[index].media || [];
          for (var mediaIndex = 0; mediaIndex < media.length; mediaIndex += 1) if (media[mediaIndex].mediaId) await app.data.media.remove(media[mediaIndex].mediaId);
        }
        await app.data.store.deleteConversation(conversation.id);
        ui.toast("对话已删除"); app.closeChat();
      }
    });
    if (!app.state.sending) await recoverInterruptedMessages(conversation.id);
    bindComposer(conversation, roleMap);
    await renderMessages(conversation, roleMap, true);
  }

  async function recoverInterruptedMessages(conversationId) {
    var messages = await app.data.store.messages(conversationId);
    for (var index = 0; index < messages.length; index += 1) {
      if (messages[index].status !== "pending") continue;
      messages[index].status = "error";
      messages[index].error = "生成已中断，请重试";
      await app.data.store.putMessage(messages[index]);
    }
  }

  async function toggleRole(conversation, roleId) {
    var selected = app.state.selectedRoleIds.slice();
    var index = selected.indexOf(roleId);
    if (index >= 0) {
      if (selected.length === 1) { ui.toast("至少保留一位回复角色"); return; }
      selected.splice(index, 1);
    } else selected.push(roleId);
    app.state.selectedRoleIds = conversation.roleIds.filter(function (id) { return selected.indexOf(id) >= 0; });
    conversation.activeRoleIds = app.state.selectedRoleIds.slice();
    conversation.updatedAt = Date.now();
    await app.data.store.put("conversations", conversation.id, conversation);
    document.querySelectorAll("[data-role-toggle]").forEach(function (button) { button.setAttribute("aria-pressed", String(app.state.selectedRoleIds.indexOf(button.dataset.roleToggle) >= 0)); });
  }

  async function renderMessages(conversation, roleMap, forceBottom) {
    var list = document.getElementById("messageList");
    var inner = document.getElementById("messageListInner");
    if (!inner) return;
    var nearBottom = forceBottom || list.scrollHeight - list.scrollTop - list.clientHeight < 130;
    var messages = await app.data.store.messages(conversation.id);
    revokeObjectUrls(messageObjectUrls);
    inner.innerHTML = "";
    if (!messages.length) {
      inner.innerHTML = ui.empty("comment-dots", "开始对话", conversation.kind === "group" ? "发送一条消息，选中的角色会依次回答。" : "说点什么，或者选择一张图片。", "");
    } else {
      for (var index = 0; index < messages.length; index += 1) inner.appendChild(await messageElement(messages[index], roleMap));
    }
    if (nearBottom) requestAnimationFrame(function () { list.scrollTop = list.scrollHeight; });
    return messages;
  }

  async function messageElement(message, roleMap) {
    var user = message.kind === "user";
    var role = message.roleId ? roleMap[message.roleId] : null;
    var row = document.createElement("article");
    row.className = "message-row " + (user ? "user" : "assistant");
    row.dataset.messageId = message.id;
    if (!user) {
      var avatarWrap = document.createElement("span");
      avatarWrap.className = "avatar message-avatar";
      avatarWrap.style.background = role ? role.avatarColor : "#67645d";
      avatarWrap.textContent = String(role ? role.name : "AI").slice(0, 2);
      row.appendChild(avatarWrap);
    }
    var block = document.createElement("div");
    block.className = "message-block";
    if (!user) {
      var name = document.createElement("p");
      name.className = "message-name";
      name.textContent = role ? role.name : (message.roleName || "AI");
      block.appendChild(name);
    }
    var bubble = document.createElement("div");
    bubble.className = "message-bubble";
    var media = message.media || [];
    if (media.length) {
      var gallery = document.createElement("div");
      gallery.className = "message-images";
      for (var mediaIndex = 0; mediaIndex < media.length; mediaIndex += 1) {
        var image = document.createElement("img");
        image.alt = media[mediaIndex].alt || (user ? "用户图片" : "AI 图片");
        if (media[mediaIndex].mediaId) {
          var record = await app.data.media.get(media[mediaIndex].mediaId);
          if (record) { var url = URL.createObjectURL(record.blob); messageObjectUrls.push(url); image.src = url; }
        } else if (utils.isAllowedImageUrl(media[mediaIndex].url)) image.src = media[mediaIndex].url;
        gallery.appendChild(image);
      }
      bubble.appendChild(gallery);
    }
    if (message.status === "pending") {
      var typing = document.createElement("div");
      typing.className = "typing-bubble";
      typing.setAttribute("aria-label", "正在生成");
      typing.innerHTML = "<span></span><span></span><span></span>";
      bubble.appendChild(typing);
    } else if (message.text) {
      var text = document.createElement("div");
      text.className = "message-text";
      text.textContent = message.text;
      bubble.appendChild(text);
    }
    if (message.status === "error") {
      var error = document.createElement("div");
      error.className = "message-error";
      error.textContent = message.error || "生成失败";
      bubble.appendChild(error);
      var retry = document.createElement("button");
      retry.className = "button ghost";
      retry.type = "button";
      retry.textContent = "重试此角色";
      retry.addEventListener("click", function () { retryRole(message.roleId); });
      bubble.appendChild(retry);
    }
    var meta = document.createElement("div");
    meta.className = "message-meta";
    meta.textContent = utils.formatTime(message.createdAt);
    if (!user && message.status === "done") {
      var speak = document.createElement("button");
      speak.type = "button";
      speak.className = "icon-button";
      speak.setAttribute("aria-label", "朗读这条回复");
      speak.innerHTML = ui.icon("volume-high");
      speak.addEventListener("click", function () { app.services.tts.speak(message.text, role).catch(function (error) { ui.toast(utils.cleanError(error), 4500); }); });
      meta.prepend(speak);
    }
    bubble.appendChild(meta);
    block.appendChild(bubble);
    row.appendChild(block);
    return row;
  }

  function bindComposer(conversation, roleMap) {
    var input = document.getElementById("messageInput");
    var imagePicker = document.getElementById("imagePicker");
    var audioPicker = document.getElementById("audioPicker");
    input.addEventListener("input", function () { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 132) + "px"; });
    input.addEventListener("keydown", function (event) { if (event.key === "Enter" && !event.shiftKey && !event.isComposing) { event.preventDefault(); send(conversation, roleMap); } });
    document.getElementById("sendButton").addEventListener("click", function () { send(conversation, roleMap); });
    document.getElementById("imageButton").addEventListener("click", function () { chooseImage(imagePicker); });
    document.getElementById("micButton").addEventListener("click", function () { handleSpeech(conversation); });
    imagePicker.onchange = async function () {
      try {
        var files = Array.prototype.slice.call(imagePicker.files || []);
        if (app.state.draftMedia.length + files.length > 4) throw new Error("每条消息最多选择 4 张图片");
        for (var index = 0; index < files.length; index += 1) app.state.draftMedia.push(await compressAndStore(files[index]));
        renderDraftMedia();
      } catch (error) { ui.toast(utils.cleanError(error), 4500); }
      finally { imagePicker.value = ""; }
    };
    audioPicker.onchange = async function () {
      var file = audioPicker.files && audioPicker.files[0];
      if (!file) return;
      var status = document.getElementById("composerStatus");
      try {
        status.textContent = "正在识别音频…";
        var settings = await app.data.store.get("meta", "settings");
        var profile = await app.data.store.get("asr-profiles", settings.defaultAsrProfileId);
        var text = await app.services.asr.transcribeFile(file, profile);
        input.value = (input.value ? input.value + " " : "") + text;
        input.dispatchEvent(new Event("input"));
        status.textContent = "识别完成，请确认后发送";
      } catch (error) { status.textContent = "识别失败"; ui.toast(utils.cleanError(error), 4800); }
      finally { audioPicker.value = ""; }
    };
    renderDraftMedia();
  }

  async function chooseImage(browserPicker) {
    if (app.state.sending) return;
    if (app.state.draftMedia.length >= 4) { ui.toast("每条消息最多选择 4 张图片"); return; }
    try {
      if (app.platform.hermit.available()) {
        var selected = await app.platform.hermit.api().files.pickImage({ maxDimension: 1280, maxBytes: 420 * 1024 });
        if (!selected || selected.cancelled) return;
        var parts = utils.dataUrlToParts(selected.dataUrl);
        if (!parts || !/^image\//i.test(parts.mime)) throw new Error("宿主没有返回有效图片");
        var blob = utils.base64ToBlob(parts.data, parts.mime);
        var record = await app.data.media.put(blob, { name: selected.name || "image.jpg", mime: parts.mime });
        app.state.draftMedia.push({ mediaId: record.id, mime: record.mime, name: record.name, size: blob.size, alt: "用户选择的图片" });
        await renderDraftMedia();
        return;
      }
      browserPicker.click();
    } catch (error) { ui.toast(utils.cleanError(error), 4800); }
  }

  async function compressAndStore(file) {
    if (!/^image\/(jpeg|png|webp|gif)$/i.test(file.type)) throw new Error("只支持 JPEG、PNG、WebP 或 GIF 图片");
    var sourceUrl = URL.createObjectURL(file);
    try {
      var image = await new Promise(function (resolve, reject) {
        var element = new Image();
        element.onload = function () { resolve(element); };
        element.onerror = function () { reject(new Error("图片无法读取")); };
        element.src = sourceUrl;
      });
      var longest = Math.max(image.naturalWidth, image.naturalHeight);
      var scale = Math.min(1, 1280 / Math.max(1, longest));
      var width = Math.max(1, Math.round(image.naturalWidth * scale));
      var height = Math.max(1, Math.round(image.naturalHeight * scale));
      var output = null;
      for (var attempt = 0; attempt < 5; attempt += 1) {
        var canvas = document.createElement("canvas");
        canvas.width = width; canvas.height = height;
        var context = canvas.getContext("2d");
        context.fillStyle = "#ffffff"; context.fillRect(0, 0, width, height); context.drawImage(image, 0, 0, width, height);
        output = await new Promise(function (resolve) { canvas.toBlob(resolve, "image/jpeg", Math.max(0.56, 0.84 - attempt * 0.07)); });
        if (output && output.size <= 420 * 1024) break;
        width = Math.max(320, Math.round(width * 0.82)); height = Math.max(320, Math.round(height * 0.82));
      }
      if (!output || output.size > 520 * 1024) throw new Error("图片压缩后仍过大，请选择尺寸更小的图片");
      var record = await app.data.media.put(output, { name: file.name.replace(/\.[^.]+$/, "") + ".jpg", mime: "image/jpeg" });
      return { mediaId: record.id, mime: record.mime, name: record.name, size: output.size, alt: "用户选择的图片" };
    } finally { URL.revokeObjectURL(sourceUrl); }
  }

  async function renderDraftMedia() {
    var tray = document.getElementById("attachmentTray");
    if (!tray) return;
    revokeObjectUrls(draftObjectUrls);
    tray.innerHTML = "";
    tray.classList.toggle("is-hidden", !app.state.draftMedia.length);
    for (var index = 0; index < app.state.draftMedia.length; index += 1) {
      var media = app.state.draftMedia[index];
      var record = await app.data.media.get(media.mediaId);
      if (!record) continue;
      var url = URL.createObjectURL(record.blob); draftObjectUrls.push(url);
      var item = document.createElement("div"); item.className = "attachment";
      var image = document.createElement("img"); image.src = url; image.alt = "待发送图片"; item.appendChild(image);
      var remove = document.createElement("button"); remove.type = "button"; remove.dataset.removeDraft = String(index); remove.setAttribute("aria-label", "移除图片"); remove.innerHTML = ui.icon("xmark");
      remove.addEventListener("click", async function (event) { var selected = app.state.draftMedia.splice(Number(event.currentTarget.dataset.removeDraft), 1)[0]; if (selected) await app.data.media.remove(selected.mediaId); renderDraftMedia(); });
      item.appendChild(remove); tray.appendChild(item);
    }
  }

  async function send(conversation, roleMap) {
    if (app.state.sending) return;
    var input = document.getElementById("messageInput");
    var text = input.value.trim();
    if (!text && !app.state.draftMedia.length) { ui.toast("请输入文字或选择图片"); return; }
    var roleIds = conversation.kind === "single" ? conversation.roleIds.slice(0, 1) : app.state.selectedRoleIds.slice();
    roleIds = roleIds.filter(function (id) { return roleMap[id] && roleMap[id].enabled !== false; });
    if (!roleIds.length) { ui.toast("没有可用的回复角色"); return; }
    app.state.sending = true;
    setComposerBusy(true, "本轮将调用 " + roleIds.length + " 位角色");
    var userMessage = { id: utils.id("message"), conversationId: conversation.id, kind: "user", text: text, media: app.state.draftMedia.slice(), status: "done", createdAt: Date.now() };
    app.state.draftMedia = [];
    input.value = ""; input.style.height = "auto"; renderDraftMedia();
    await app.data.store.putMessage(userMessage);
    conversation.lastMessage = text || "[图片]"; conversation.updatedAt = Date.now();
    await app.data.store.put("conversations", conversation.id, conversation);
    await renderMessages(conversation, roleMap, true);
    var lastSuccessful = null;
    try {
      for (var index = 0; index < roleIds.length; index += 1) {
        var role = roleMap[roleIds[index]];
        var assistant = { id: utils.id("message"), conversationId: conversation.id, kind: "assistant", roleId: role.id, roleName: role.name, text: "", media: [], status: "pending", createdAt: Date.now() + index };
        await app.data.store.putMessage(assistant);
        await renderMessages(conversation, roleMap, true);
        var allMessages = await app.data.store.messages(conversation.id);
        var history = allMessages.filter(function (message) { return message.id !== assistant.id && message.status === "done"; });
        try {
          var result = await app.services.llm.complete(role, history);
          assistant.text = result.text;
          assistant.status = "done";
          assistant.usage = result.usage;
          assistant.contextTrimmed = result.contextTrimmed;
          assistant.media = await storeOutputImages(result.images);
          lastSuccessful = { message: assistant, role: role };
          conversation.lastMessage = assistant.text || "[图片回复]";
        } catch (error) {
          assistant.status = "error"; assistant.error = utils.cleanError(error);
        }
        await app.data.store.putMessage(assistant);
        conversation.updatedAt = Date.now(); await app.data.store.put("conversations", conversation.id, conversation);
        await renderMessages(conversation, roleMap, true);
      }
      var settings = await app.data.store.get("meta", "settings");
      if (settings.autoSpeak && lastSuccessful && lastSuccessful.message.text) app.services.tts.speak(lastSuccessful.message.text, lastSuccessful.role).catch(function (error) { ui.toast("自动朗读失败：" + utils.cleanError(error), 4600); });
    } finally {
      app.state.sending = false;
      setComposerBusy(false, "识别文字后不会自动发送");
    }
  }

  async function storeOutputImages(images) {
    var media = [];
    for (var imageIndex = 0; imageIndex < (images || []).length; imageIndex += 1) {
      var outputImage = images[imageIndex];
      if (/^data:image\//i.test(outputImage.dataUrl)) {
        var parts = utils.dataUrlToParts(outputImage.dataUrl);
        if (!parts) continue;
        var record = await app.data.media.put(utils.base64ToBlob(parts.data, parts.mime), { name: "ai-image.png", mime: parts.mime });
        media.push({ mediaId: record.id, mime: parts.mime, name: record.name, alt: outputImage.alt });
      } else if (utils.isAllowedImageUrl(outputImage.dataUrl)) {
        media.push({ url: outputImage.dataUrl, alt: outputImage.alt });
      }
    }
    return media;
  }

  function setComposerBusy(busy, statusText) {
    var sendButton = document.getElementById("sendButton");
    var imageButton = document.getElementById("imageButton");
    if (sendButton) { sendButton.disabled = busy; sendButton.innerHTML = busy ? '<span class="spinner"></span>' : ui.icon("arrow-up"); }
    if (imageButton) imageButton.disabled = busy;
    var status = document.getElementById("composerStatus"); if (status) status.textContent = statusText;
  }

  async function retryRole(roleId) {
    if (app.state.sending) return;
    var conversation = await app.data.store.get("conversations", app.state.activeConversationId);
    var role = await app.data.store.get("roles", roleId);
    if (!conversation || !role) return;
    var roleMap = {}; (await app.data.store.list("roles")).forEach(function (item) { roleMap[item.id] = item; });
    app.state.sending = true; setComposerBusy(true, "正在重试 " + role.name);
    var assistant = { id: utils.id("message"), conversationId: conversation.id, kind: "assistant", roleId: role.id, roleName: role.name, text: "", media: [], status: "pending", createdAt: Date.now() };
    await app.data.store.putMessage(assistant); await renderMessages(conversation, roleMap, true);
    try {
      var messages = (await app.data.store.messages(conversation.id)).filter(function (message) { return message.id !== assistant.id && message.status === "done"; });
      var result = await app.services.llm.complete(role, messages);
      assistant.text = result.text;
      assistant.media = await storeOutputImages(result.images);
      assistant.usage = result.usage;
      assistant.contextTrimmed = result.contextTrimmed;
      assistant.status = "done";
    } catch (error) { assistant.status = "error"; assistant.error = utils.cleanError(error); }
    await app.data.store.putMessage(assistant); await renderMessages(conversation, roleMap, true);
    app.state.sending = false; setComposerBusy(false, "识别文字后不会自动发送");
  }

  async function handleSpeech() {
    var button = document.getElementById("micButton");
    var status = document.getElementById("composerStatus");
    if (app.state.speechSubscriptionId) {
      await app.services.asr.stopSystem(app.state.speechSubscriptionId);
      status.textContent = "正在结束识别…";
      return;
    }
    try {
      var settings = await app.data.store.get("meta", "settings");
      var profile = await app.data.store.get("asr-profiles", settings.defaultAsrProfileId || "system-asr");
      if (!profile || !profile.enabled) throw new Error("默认语音输入配置不存在或已停用");
      if (profile.type !== "system") {
        if (app.platform.hermit.available()) {
          status.textContent = "请选择一段短音频…";
          var selectedAudio = await app.platform.hermit.api().files.pickInline({ accept: "audio/*", maxBytes: 650 * 1024 });
          if (!selectedAudio || selectedAudio.cancelled) { status.textContent = "已取消语音输入"; return; }
          var audioParts = utils.dataUrlToParts(selectedAudio.dataUrl);
          if (!audioParts || !/^audio\//i.test(audioParts.mime)) throw new Error("宿主没有返回有效音频");
          var audioBlob = utils.base64ToBlob(audioParts.data, audioParts.mime);
          audioBlob.name = selectedAudio.name || "recording.m4a";
          status.textContent = "正在识别音频…";
          var transcript = await app.services.asr.transcribeFile(audioBlob, profile);
          var messageInput = document.getElementById("messageInput");
          messageInput.value = (messageInput.value ? messageInput.value + " " : "") + transcript;
          messageInput.dispatchEvent(new Event("input"));
          status.textContent = "识别完成，请确认后发送";
          return;
        }
        document.getElementById("audioPicker").click(); return;
      }
      button.classList.add("recording"); button.innerHTML = ui.icon("stop");
      status.textContent = "正在准备语音识别…";
      var subscription = await app.services.asr.startSystem(profile, {
        ready: function () { status.textContent = "请开始说话"; },
        begin: function () { status.textContent = "正在聆听…"; },
        partial: function (data) { var first = data.alternatives && data.alternatives[0]; if (first) status.textContent = first.text; },
        final: function (data) {
          var first = data.alternatives && data.alternatives[0];
          if (first) { var input = document.getElementById("messageInput"); input.value = (input.value ? input.value + " " : "") + first.text; input.dispatchEvent(new Event("input")); }
          finishSpeech("识别完成，请确认后发送");
        },
        error: function (data) { finishSpeech("识别失败：" + (data.code || "未知错误")); },
        end: function () { status.textContent = "正在整理识别结果…"; }
      });
      app.state.speechSubscriptionId = subscription;
    } catch (error) { finishSpeech("语音识别不可用"); ui.toast(utils.cleanError(error), 4800); }
  }

  function finishSpeech(text) {
    app.state.speechSubscriptionId = null;
    var button = document.getElementById("micButton"); if (button) { button.classList.remove("recording"); button.innerHTML = ui.icon("microphone"); }
    var status = document.getElementById("composerStatus"); if (status) status.textContent = text;
  }

  async function close() {
    if (app.state.speechSubscriptionId) { try { await app.services.asr.cancelSystem(); } catch (_) {} }
    app.state.speechSubscriptionId = null;
    app.state.activeConversationId = null;
    app.state.selectedRoleIds = [];
    app.state.draftMedia = [];
    revokeObjectUrls(messageObjectUrls);
    revokeObjectUrls(draftObjectUrls);
  }

  app.features = app.features || {};
  app.features.chat = { render: render, close: close, renderMessages: renderMessages };
})(window.ChatTaxi);
