(function (app) {
  "use strict";
  var utils = app.utils;
  var modalRoot = function () { return document.getElementById("modalRoot"); };
  var toastTimer = null;

  function icon(name) { return '<i class="fa-solid fa-' + utils.escapeHtml(name) + '" aria-hidden="true"></i>'; }

  function avatar(name, color, className) {
    var label = String(name || "AI").trim().slice(0, 2).toUpperCase() || "AI";
    return '<span class="avatar ' + (className || "") + '" style="background:' + utils.escapeHtml(color || "#67645d") + '">' + utils.escapeHtml(label) + '</span>';
  }

  function toast(message, duration) {
    var root = document.getElementById("toastRoot");
    clearTimeout(toastTimer);
    root.innerHTML = '<div class="toast" role="status">' + utils.escapeHtml(message) + '</div>';
    toastTimer = setTimeout(function () { root.innerHTML = ""; }, duration || 2600);
  }

  function closeModal() {
    var root = modalRoot();
    var previous = root.querySelector("[data-previous-focus]");
    root.innerHTML = "";
    document.body.style.overflow = "";
    if (previous && previous.focus) previous.focus();
  }

  function openModal(options) {
    var root = modalRoot();
    var active = document.activeElement;
    if (active) active.setAttribute("data-previous-focus", "true");
    root.innerHTML =
      '<div class="modal-backdrop" data-modal-backdrop>' +
        '<section class="modal-sheet" role="dialog" aria-modal="true" aria-labelledby="modalTitle">' +
          '<div class="modal-handle" aria-hidden="true"></div>' +
          '<header class="modal-head"><h2 id="modalTitle">' + utils.escapeHtml(options.title) + '</h2>' +
            '<button class="icon-button" type="button" data-close-modal aria-label="关闭">' + icon("xmark") + '</button></header>' +
          '<form id="modalForm"><div class="modal-body">' + options.html + '</div>' +
            '<div class="modal-actions">' +
              (options.cancelText === null ? "" : '<button class="button secondary" id="modalCancel" type="button" data-close-modal>' + utils.escapeHtml(options.cancelText || "取消") + '</button>') +
              '<button class="button ' + (options.danger ? "danger" : "primary") + '" id="modalSubmit" type="submit">' + utils.escapeHtml(options.submitText || "保存") + '</button>' +
            '</div></form>' +
        '</section></div>';
    document.body.style.overflow = "hidden";
    var form = document.getElementById("modalForm");
    form.querySelectorAll("[name]").forEach(function (field) {
      if (!field.id) field.id = "field-" + field.name.replace(/[^a-zA-Z0-9_-]/g, "-");
    });
    root.querySelectorAll("[data-close-modal]").forEach(function (button) { button.addEventListener("click", closeModal); });
    root.querySelector("[data-modal-backdrop]").addEventListener("click", function (event) {
      if (event.target === event.currentTarget) closeModal();
    });
    form.addEventListener("submit", async function (event) {
      event.preventDefault();
      var submit = form.querySelector('[type="submit"]');
      submit.disabled = true;
      try {
        var shouldClose = await options.onSubmit(form);
        if (shouldClose !== false) closeModal();
      } catch (error) {
        var existing = form.querySelector(".form-error");
        if (!existing) {
          existing = document.createElement("div");
          existing.className = "error-box form-error";
          existing.setAttribute("role", "alert");
          form.querySelector(".modal-body").prepend(existing);
        }
        existing.textContent = utils.cleanError(error);
      } finally { submit.disabled = false; }
    });
    var first = form.querySelector("input:not([type=hidden]), textarea, select, button");
    setTimeout(function () { if (first) first.focus(); }, 30);
    return form;
  }

  function confirm(options) {
    return new Promise(function (resolve) {
      var settled = false;
      openModal({
        title: options.title || "请确认",
        html: '<p>' + utils.escapeHtml(options.message || "确定继续吗？") + '</p>',
        submitText: options.confirmText || "确定",
        danger: Boolean(options.danger),
        onSubmit: function () { settled = true; resolve(true); return true; }
      });
      var closeButtons = modalRoot().querySelectorAll("[data-close-modal]");
      closeButtons.forEach(function (button) {
        button.addEventListener("click", function () { if (!settled) { settled = true; resolve(false); } });
      });
    });
  }

  function empty(iconName, title, text, actionHtml) {
    return '<div class="empty-state"><div class="empty-state-inner"><div class="empty-icon">' + icon(iconName) + '</div><h2>' + utils.escapeHtml(title) + '</h2><p>' + utils.escapeHtml(text) + '</p>' + (actionHtml || "") + '</div></div>';
  }

  app.components = { icon: icon, avatar: avatar, toast: toast, openModal: openModal, closeModal: closeModal, confirm: confirm, empty: empty };
})(window.ChatTaxi);
