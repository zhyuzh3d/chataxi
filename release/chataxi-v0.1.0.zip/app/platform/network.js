(function (app) {
  "use strict";
  var utils = app.utils;

  function buildHeaders(options) {
    var headers = {};
    Object.keys(options.headers || {}).forEach(function (name) {
      if (options.headers[name] != null && String(options.headers[name]).trim()) headers[name] = String(options.headers[name]);
    });
    return headers;
  }

  async function request(options) {
    if (!options || !/^https?:\/\//i.test(options.url || "")) throw new Error("请求地址必须是完整的 HTTP(S) URL");
    var method = String(options.method || "GET").toUpperCase();
    var headers = buildHeaders(options);
    if (app.platform.hermit.available() || await app.platform.hermit.awaitReady(800)) {
      var params = { url: options.url, method: method, headers: headers, timeoutMs: options.timeoutMs || 60000 };
      if (options.bodyBytes) {
        params.bodyBase64 = utils.bytesToBase64(options.bodyBytes);
        params.contentType = options.contentType || "application/octet-stream";
      } else if (typeof options.bodyText === "string") {
        params.bodyText = options.bodyText;
        params.contentType = options.contentType || headers["Content-Type"] || headers["content-type"] || "application/json";
      }
      return app.platform.hermit.api().network.request(params);
    }

    var controller = typeof AbortController === "function" ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, options.timeoutMs || 60000) : null;
    try {
      var response = await fetch(options.url, {
        method: method,
        headers: headers,
        body: options.bodyBytes || options.bodyText,
        signal: controller ? controller.signal : undefined
      });
      var type = response.headers.get("content-type") || "application/octet-stream";
      var responseHeaders = {};
      response.headers.forEach(function (value, name) { responseHeaders[name] = value; });
      if (/json|text|xml|javascript/i.test(type)) {
        return { status: response.status, headers: responseHeaders, url: response.url, bodyText: await response.text() };
      }
      var bytes = new Uint8Array(await response.arrayBuffer());
      return { status: response.status, headers: responseHeaders, url: response.url, bodyBase64: utils.bytesToBase64(bytes) };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  async function requestJson(options) {
    var result = await request(options);
    var bodyText = await readText(result);
    var payload = utils.safeJsonParse(bodyText, null);
    if (result.status < 200 || result.status >= 300) {
      var message = payload && payload.error
        ? (payload.error.message || payload.error.code || JSON.stringify(payload.error))
        : (bodyText || ("HTTP " + result.status));
      var error = new Error("请求失败（" + result.status + "）：" + String(message).slice(0, 300));
      error.status = result.status;
      error.payload = payload;
      throw error;
    }
    if (!payload) throw new Error("服务返回的不是有效 JSON");
    return { data: payload, response: result };
  }

  async function readText(result) {
    var bodyText = result && result.bodyText || "";
    var logicalFileId = result.file && result.file.logicalFileId;
    if (!bodyText && logicalFileId && app.platform.hermit.available()) {
      try {
        var stored = await app.platform.hermit.api().files.readText({ logicalFileId: logicalFileId, maxBytes: 8 * 1024 * 1024 });
        bodyText = stored.text || "";
      } finally {
        try { await app.platform.hermit.api().files.delete({ logicalFileId: logicalFileId }); } catch (_) {}
      }
    }
    return bodyText;
  }

  app.platform.network = { request: request, readText: readText, requestJson: requestJson };
})(window.ChatTaxi);
