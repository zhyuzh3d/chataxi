(function (app) {
  "use strict";
  var utils = app.utils;

  function customHeaders(profile) {
    return utils.parseHeaders(profile.customHeaders);
  }

  function headers(profile) {
    var result = { "Content-Type": "application/json" };
    var key = profile.apiKey || "";
    if (profile.apiStyle === "anthropic-messages") {
      if (key) result["x-api-key"] = key;
      result["anthropic-version"] = profile.apiVersion || "2023-06-01";
      result["anthropic-dangerous-direct-browser-access"] = "true";
    } else if (profile.apiStyle === "gemini-generate-content") {
      if (key) result["x-goog-api-key"] = key;
    } else if (key) {
      result.Authorization = "Bearer " + key;
    }
    var extras = customHeaders(profile);
    Object.keys(extras).forEach(function (name) { result[name] = String(extras[name]); });
    return result;
  }

  function endpoint(profile, streaming) {
    var value = String(profile.endpoint || "").replace(/\{model\}/g, encodeURIComponent(profile.model || ""));
    if (!/^https?:\/\//i.test(value)) throw new Error("模型请求地址必须是完整的 HTTP(S) URL");
    if (value.indexOf("{model}") >= 0 || /\/models\/:generateContent/.test(value)) throw new Error("Gemini 地址需要填写模型名");
    if (streaming && profile.apiStyle === "gemini-generate-content") {
      value = value.replace(/:generateContent(?=\?|$)/, ":streamGenerateContent");
      value += (value.indexOf("?") >= 0 ? "&" : "?") + "alt=sse";
    }
    return utils.validateEndpoint(value);
  }

  function transcriptText(message) {
    var prefix = message.role === "assistant" && message.roleName ? "[" + message.roleName + "] " : "";
    var text = prefix + (message.text || "");
    if (message.images && message.images.length && message.role !== "user") text += "\n[图片回复]";
    return text.trim() || " ";
  }

  function responseInput(messages) {
    return messages.map(function (message) {
      if (message.role !== "user" || !message.images || !message.images.length) {
        return { role: message.role === "assistant" ? "assistant" : "user", content: transcriptText(message) };
      }
      var content = [{ type: "input_text", text: transcriptText(message) }];
      message.images.forEach(function (image) {
        if (image.dataUrl) content.push({ type: "input_image", image_url: image.dataUrl, detail: image.detail || "auto" });
      });
      return { role: "user", content: content };
    });
  }

  function chatMessages(role, messages) {
    var result = [];
    if (role.systemPrompt) result.push({ role: "system", content: role.systemPrompt });
    messages.forEach(function (message) {
      var mappedRole = message.role === "assistant" ? "assistant" : "user";
      if (mappedRole === "user" && message.images && message.images.length) {
        var content = [{ type: "text", text: transcriptText(message) }];
        message.images.forEach(function (image) {
          if (image.dataUrl) content.push({ type: "image_url", image_url: { url: image.dataUrl, detail: image.detail || "auto" } });
        });
        result.push({ role: mappedRole, content: content });
      } else {
        result.push({ role: mappedRole, content: transcriptText(message) });
      }
    });
    return result;
  }

  function anthropicMessages(messages) {
    return messages.map(function (message) {
      var mappedRole = message.role === "assistant" ? "assistant" : "user";
      if (mappedRole === "user" && message.images && message.images.length) {
        var content = [];
        message.images.forEach(function (image) {
          var parsed = utils.dataUrlToParts(image.dataUrl);
          if (parsed) content.push({ type: "image", source: { type: "base64", media_type: parsed.mime, data: parsed.data } });
        });
        content.push({ type: "text", text: transcriptText(message) });
        return { role: mappedRole, content: content };
      }
      return { role: mappedRole, content: transcriptText(message) };
    });
  }

  function geminiContents(messages) {
    return messages.map(function (message) {
      var parts = [];
      if (message.role === "user" && message.images) {
        message.images.forEach(function (image) {
          var parsed = utils.dataUrlToParts(image.dataUrl);
          if (parsed) parts.push({ inline_data: { mime_type: parsed.mime, data: parsed.data } });
        });
      }
      parts.push({ text: transcriptText(message) });
      return { role: message.role === "assistant" ? "model" : "user", parts: parts };
    });
  }

  function build(profile, role, messages, options) {
    var body, streaming = Boolean(options && options.stream);
    if (profile.apiStyle === "openai-responses") {
      body = {
        model: profile.model,
        input: responseInput(messages),
        stream: streaming,
        store: false,
        max_output_tokens: Number(profile.maxOutputTokens || 1024)
      };
      if (role.systemPrompt) body.instructions = role.systemPrompt;
      if (profile.allowImageGeneration) body.tools = [{ type: "image_generation" }];
      if (profile.reasoningEffort) body.reasoning = { effort: profile.reasoningEffort };
      if (profile.temperature !== "" && profile.temperature != null) body.temperature = Number(profile.temperature);
    } else if (profile.apiStyle === "openai-chat") {
      body = {
        model: profile.model,
        messages: chatMessages(role, messages),
        stream: streaming,
        max_tokens: Number(profile.maxOutputTokens || 1024)
      };
      if (profile.temperature !== "" && profile.temperature != null) body.temperature = Number(profile.temperature);
    } else if (profile.apiStyle === "anthropic-messages") {
      body = {
        model: profile.model,
        messages: anthropicMessages(messages),
        max_tokens: Number(profile.maxOutputTokens || 1024),
        stream: streaming
      };
      if (role.systemPrompt) body.system = role.systemPrompt;
      if (profile.temperature !== "" && profile.temperature != null) body.temperature = Number(profile.temperature);
    } else if (profile.apiStyle === "gemini-generate-content") {
      body = {
        contents: geminiContents(messages),
        generationConfig: { maxOutputTokens: Number(profile.maxOutputTokens || 1024) }
      };
      if (role.systemPrompt) body.systemInstruction = { parts: [{ text: role.systemPrompt }] };
      if (profile.temperature !== "" && profile.temperature != null) body.generationConfig.temperature = Number(profile.temperature);
      if (profile.reasoningEffort) body.generationConfig.thinkingConfig = { thinkingLevel: String(profile.reasoningEffort).toUpperCase() };
    } else {
      throw new Error("不支持的模型协议：" + profile.apiStyle);
    }
    return { url: endpoint(profile, streaming), headers: headers(profile), body: body, streaming: streaming };
  }

  function collectImages(value, output, imageContext) {
    if (!value) return;
    if (Array.isArray(value)) { value.forEach(function (item) { collectImages(item, output, imageContext); }); return; }
    if (typeof value !== "object") return;
    function add(url, alt) {
      if (utils.isAllowedImageUrl(url) && !output.some(function (item) { return item.dataUrl === url; })) output.push({ dataUrl: url, alt: alt || "AI 图片" });
    }
    if (value.type === "image_generation_call" && typeof value.result === "string") {
      var format = ["jpeg", "webp", "png"].indexOf(value.output_format) >= 0 ? value.output_format : "png";
      add("data:image/" + format + ";base64," + value.result, "AI 生成图片");
    }
    if (value.image_url) add(typeof value.image_url === "string" ? value.image_url : value.image_url.url);
    if (imageContext && typeof value.url === "string") add(value.url);
    var inline = value.inlineData || value.inline_data;
    if (inline && inline.data) add("data:" + (inline.mimeType || inline.mime_type) + ";base64," + inline.data);
    Object.keys(value).forEach(function (key) {
      if (["result", "image_url", "url", "inlineData", "inline_data", "usage", "usageMetadata"].indexOf(key) < 0) collectImages(value[key], output, key === "images" || value.type === "image");
    });
  }

  function parse(profile, data) {
    if (!data || typeof data !== "object") throw new Error("模型返回的内容不是有效对象");
    if (data.error) throw new Error(utils.cleanError(data.error.message || data.error.code || "模型服务返回错误"));
    var text = "";
    if (profile.apiStyle === "openai-responses") {
      text = data.output_text || "";
      if (!text && Array.isArray(data.output)) {
        data.output.forEach(function (item) {
          if (item.type === "message" && Array.isArray(item.content)) {
            item.content.forEach(function (part) { if (part.type === "output_text" && part.text) text += (text ? "\n" : "") + part.text; });
          }
        });
      }
    } else if (profile.apiStyle === "openai-chat") {
      var choice = data.choices && data.choices[0];
      var content = choice && choice.message ? choice.message.content : "";
      if (typeof content === "string") text = content;
      else if (Array.isArray(content)) content.forEach(function (part) { if (part.text) text += (text ? "\n" : "") + part.text; });
    } else if (profile.apiStyle === "anthropic-messages") {
      (data.content || []).forEach(function (part) { if (part.type === "text" && part.text) text += (text ? "\n" : "") + part.text; });
    } else if (profile.apiStyle === "gemini-generate-content") {
      var parts = data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
      (parts || []).forEach(function (part) { if (part.text) text += (text ? "\n" : "") + part.text; });
    }
    var images = [];
    collectImages(data, images);
    if (!text.trim() && !images.length) throw new Error("模型响应中没有可显示的文本或图片");
    return { text: text.trim(), images: images, usage: data.usage || data.usageMetadata || null, rawId: data.id || null };
  }

  function parseStreamEvent(profile, event) {
    var raw = event && event.data;
    if (!raw || raw === "[DONE]") return { done: raw === "[DONE]" };
    var data = utils.safeJsonParse(raw, null);
    if (!data) return {};
    if (data.error || data.type === "error") {
      var source = data.error || data;
      throw new Error(utils.cleanError(source.message || source.code || source.type || "模型流返回错误"));
    }
    var delta = "", done = false, usage = null, images = [];
    if (profile.apiStyle === "openai-responses") {
      if (data.type === "response.output_text.delta" || data.type === "response.refusal.delta") delta = data.delta || "";
      done = data.type === "response.completed" || data.type === "response.failed" || data.type === "response.incomplete";
      var response = data.response || null;
      usage = response && response.usage || null;
      if (response) collectImages(response, images);
      if (data.type === "response.failed") throw new Error(utils.cleanError(response && response.error && response.error.message || "模型生成失败"));
    } else if (profile.apiStyle === "openai-chat") {
      var choice = data.choices && data.choices[0], content = choice && choice.delta && choice.delta.content;
      if (typeof content === "string") delta = content;
      else if (Array.isArray(content)) content.forEach(function (part) { if (part && part.text) delta += part.text; });
      done = Boolean(choice && choice.finish_reason);
      usage = data.usage || null;
      collectImages(data, images);
    } else if (profile.apiStyle === "anthropic-messages") {
      if (data.type === "content_block_delta" && data.delta && data.delta.type === "text_delta") delta = data.delta.text || "";
      done = data.type === "message_stop";
      usage = data.usage || data.message && data.message.usage || null;
    } else if (profile.apiStyle === "gemini-generate-content") {
      var parts = data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
      (parts || []).forEach(function (part) { if (part.text) delta += part.text; });
      done = Boolean(data.candidates && data.candidates[0] && data.candidates[0].finishReason);
      usage = data.usageMetadata || null;
      collectImages(data, images);
    }
    return { delta: delta, done: done, usage: usage, images: images };
  }

  app.services.providers = { build: build, parse: parse, parseStreamEvent: parseStreamEvent, headers: headers, endpoint: endpoint };
})(window.chataxi);
