(function (app) {
  "use strict";
  var u = app.utils, ui = app.components, store = app.data.store;

  function items(values) { return values.map(function (item) { return { id: item.id, name: item.name }; }); }
  function toggle(name, label, text, checked) {
    return '<label class="switch-row"><span><strong>' + label + '</strong><small>' + text + '</small></span><input name="' + name + '" type="checkbox"' + (checked ? ' checked' : '') + '></label>';
  }
  function range(name, label, value, min, max, step, suffix) {
    return '<label class="field range-field"><span>' + label + '<output data-output="' + name + '">' + u.escapeHtml(value) + suffix + '</output></span><input name="' + name + '" type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + u.escapeHtml(value) + '"></label>';
  }

  async function render() {
    var settings = await store.get("meta", "settings");
    var tts = (await store.list("tts-profiles")).filter(function (item) { return item.enabled !== false; });
    var asr = (await store.list("asr-profiles")).filter(function (item) { return item.enabled !== false; });
    var info = await app.platform.hermit.info();
    if (app.state.route !== "settings") return;
    ui.pageHeader("设置", "通用偏好与上下文");
    var main = document.getElementById("mainContent"); main.className = "main";
    main.innerHTML = '<section class="page settings-page"><form id="generalForm" class="settings-stack">' +
      '<section class="card card-body form-grid"><h2 class="section-title">对话</h2>' +
      toggle("autoSpeak", "自动朗读新回复", "群聊完成后朗读最后一位角色的回复", settings.autoSpeak) +
      toggle("enterToSend", "按 Enter 发送", "关闭时 Enter 换行；Ctrl / ⌘ + Enter 始终发送", Boolean(settings.enterToSend)) +
      ui.picker("defaultTtsProfileId", "默认朗读服务", "", "角色选择“跟随通用设置”时使用") +
      ui.picker("defaultAsrProfileId", "默认语音输入", "", "新对话默认使用；可在对话管理中覆盖") + '</section>' +
      '<section class="card card-body form-grid"><div><h2 class="section-title">上下文自动压缩</h2><p class="helper section-helper">每位角色用自己的模型压缩更早历史。实际请求由角色提示词、最近压缩内容和最近 N 条完整消息组成。</p></div>' +
      toggle("autoCompress", "自动压缩历史", "超过阈值后，在下一次生成回复前执行", settings.autoCompress) +
      range("compressionThresholdChars", "触发字数", Number(settings.compressionThresholdChars || 32000), 4000, 100000, 2000, " 字") +
      range("compressionTargetChars", "压缩目标", Number(settings.compressionTargetChars || 2400), 400, 8000, 200, " 字") +
      range("recentFullMessages", "保留完整消息", Number(settings.recentFullMessages || 10), 5, 50, 1, " 条") +
      '<label class="field"><span>压缩提示词</span><textarea class="prompt-editor" name="compressionPrompt" required maxlength="8000">' + u.escapeHtml(settings.compressionPrompt || "") + '</textarea><small>压缩内容可以在具体对话中手工修订；已经压缩的原消息不再允许编辑。</small></label></section>' +
      '<section class="card card-body form-grid"><h2 class="section-title">界面</h2>' +
      ui.picker("theme", "界面主题", "") +
      ui.picker("imageDetail", "发送图片细节", "") +
      '<label class="field"><span>默认语言</span><input name="language" maxlength="30" value="' + u.escapeHtml(settings.language || "zh-CN") + '"></label></section>' +
      '<button class="button primary full" type="submit">保存设置</button><p class="save-status" id="settingsSaveStatus" role="status"></p></form>' +
      '<section class="card card-body environment-card"><h2 class="section-title">关于 chataxi <span class="badge">' + u.escapeHtml(app.version) + '</span></h2><dl class="facts"><div><dt>数据保存</dt><dd>' + (store.backend() === "hermit" ? "Hermit 应用数据" : "当前浏览器") + '</dd></div><div><dt>运行方式</dt><dd>' + u.escapeHtml(({ live: "线上实时运行", local: "本地运行", browser: "浏览器预览" })[info.runtimeMode] || info.runtimeMode || "未知") + '</dd></div><div><dt>Hermit Bridge</dt><dd>' + (app.platform.hermit.available() ? "已就绪" : "未连接") + '</dd></div></dl><p class="helper">清除应用数据会删除本机记录。页面代码在请求模型服务时可以读取保存在当前 happ 数据空间中的密钥。</p></section></section>';

    var form = document.getElementById("generalForm");
    ui.bindPicker(form, "defaultTtsProfileId", items(tts), settings.defaultTtsProfileId);
    ui.bindPicker(form, "defaultAsrProfileId", items(asr), settings.defaultAsrProfileId);
    ui.bindPicker(form, "theme", [{ id: "system", name: "跟随系统" }, { id: "light", name: "浅色" }, { id: "dark", name: "深色" }], settings.theme || "system");
    ui.bindPicker(form, "imageDetail", [{ id: "auto", name: "自动" }, { id: "low", name: "低细节" }, { id: "high", name: "高细节" }], settings.imageDetail || "auto");
    form.querySelectorAll('input[type="range"]').forEach(function (slider) {
      slider.addEventListener("input", function () { var output = form.querySelector('[data-output="' + slider.name + '"]'); output.textContent = slider.value + (slider.name === "recentFullMessages" ? " 条" : " 字"); markDirty(); });
    });
    function markDirty() { document.getElementById("settingsSaveStatus").textContent = "有未保存的更改"; }
    form.addEventListener("input", markDirty);
    form.addEventListener("submit", ui.action(async function (event) {
      event.preventDefault();
      var button = form.querySelector('[type="submit"]'); if (button.disabled) return; button.disabled = true;
      try {
        var next = await store.get("meta", "settings");
        ["autoSpeak", "enterToSend", "autoCompress"].forEach(function (key) { next[key] = u.checked(form, key); });
        ["defaultTtsProfileId", "defaultAsrProfileId", "theme", "imageDetail", "language", "compressionPrompt"].forEach(function (key) { next[key] = u.formValue(form, key); });
        ["compressionThresholdChars", "compressionTargetChars", "recentFullMessages"].forEach(function (key) { next[key] = Number(u.formValue(form, key)); });
        if (!next.compressionPrompt) throw new Error("请填写压缩提示词");
        if (next.recentFullMessages < 5 || next.recentFullMessages > 50) throw new Error("保留完整消息数量需在 5 到 50 之间");
        await store.put("meta", "settings", next); app.applyTheme(next.theme);
        document.getElementById("settingsSaveStatus").textContent = "设置已保存"; ui.toast("设置已保存");
      } finally { button.disabled = false; }
    }));
  }

  app.features = app.features || {};
  app.features.settings = { render: render };
})(window.chataxi);
