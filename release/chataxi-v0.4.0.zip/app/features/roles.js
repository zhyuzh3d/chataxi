(function (app) {
  "use strict";
  var u = app.utils, ui = app.components, store = app.data.store;

  function named(items) { return (items || []).map(function (item) { return { id: item.id, name: item.name || item.id }; }); }
  function serviceItems(items) { return (items || []).map(function (item) { return { id: item.id, name: item.name }; }); }

  async function render() {
    var roles = (await store.list("roles")).sort(function (a, b) { return a.name.localeCompare(b.name, "zh-CN"); });
    var profiles = await store.list("llm-profiles");
    if (app.state.route !== "roles") return;
    ui.pageHeader("角色", roles.length + " 位角色", '<button class="button primary compact" type="button" data-add-role>' + ui.icon("plus") + '<span>新角色</span></button>');
    var main = document.getElementById("mainContent"); main.className = "main";
    main.innerHTML = '<section class="page">' + (roles.length ? ui.search("搜索角色名称或模型") + '<div class="role-grid" id="roleList"></div>' : '<div class="compact-empty"><div class="empty-icon">' + ui.icon("user-group") + '</div><h2>创建第一位角色</h2><p>设定角色提示词、模型和声音后即可开始对话。</p><button class="button primary" type="button" data-add-role>' + ui.icon("plus") + '新角色</button></div>') + '</section>';
    if (roles.length) {
      var paint = function (query) {
        var items = roles.filter(function (role) { var profile = profiles.find(function (item) { return item.id === role.llmProfileId; }); return (role.name + " " + role.model + " " + (profile ? profile.name : "")).toLowerCase().indexOf(query.toLowerCase()) >= 0; });
        document.getElementById("roleList").innerHTML = items.length ? items.map(function (role) {
          var status = app.services.profiles.roleStatus(role, profiles), profile = profiles.find(function (item) { return item.id === role.llmProfileId; });
          return '<article class="card role-card"><div class="role-card-head">' + ui.roleAvatar(role, "role-list-avatar") + '<div class="list-copy"><strong>' + u.escapeHtml(role.name) + '</strong><span>' + u.escapeHtml(profile ? profile.name + " · " + (role.model || "待选模型") : "未绑定模型服务") + '</span></div><span class="badge ' + (status ? "warning" : "success") + '">' + (status ? u.escapeHtml(status) : "可对话") + '</span></div><div class="role-actions"><button class="button ghost" type="button" data-edit-role="' + u.escapeHtml(role.id) + '">' + ui.icon("pen") + '编辑角色</button><button class="button ' + (status ? "secondary" : "primary") + '" type="button" ' + (status ? 'data-edit-role' : 'data-chat-role') + '="' + u.escapeHtml(role.id) + '">' + ui.icon(status ? "wrench" : "comment-dots") + (status ? "修复配置" : "开始对话") + '</button></div></article>';
        }).join("") : ui.empty("magnifying-glass", "没有找到角色", "换个关键词试试。", "");
        main.querySelectorAll("[data-edit-role]").forEach(function (button) { button.addEventListener("click", ui.action(async function () { await openEditor(await store.get("roles", button.dataset.editRole)); })); });
        main.querySelectorAll("[data-chat-role]").forEach(function (button) { button.addEventListener("click", ui.action(function () { return app.features.conversations.openEditor(null, button.dataset.chatRole); })); });
        ui.hydrateAvatars(main);
      };
      main.querySelector("#listSearch").addEventListener("input", function (event) { paint(event.target.value); }); paint("");
    }
    document.querySelectorAll("[data-add-role]").forEach(function (button) { button.addEventListener("click", ui.action(function () { return openEditor(null); })); });
  }

  async function pickLocalImage() {
    if (app.platform.hermit.available()) {
      var picked = await app.platform.hermit.api().files.pickImage({ maxDimension: 2000, maxBytes: 700 * 1024 });
      if (!picked || picked.cancelled) return null;
      var parts = u.dataUrlToParts(picked.dataUrl); if (!parts) throw new Error("没有取得可用头像图片");
      var blob = u.base64ToBlob(parts.data, parts.mime); blob.name = picked.name || "avatar.jpg"; return blob;
    }
    return new Promise(function (resolve) { var input = document.createElement("input"); input.type = "file"; input.accept = "image/jpeg,image/png,image/webp"; input.addEventListener("change", function () { resolve(input.files && input.files[0] || null); }, { once: true }); input.click(); });
  }

  async function cropAvatar(blob, onCropped) {
    if (!blob || !/^image\/(jpeg|png|webp)$/i.test(blob.type || "")) throw new Error("头像只支持 JPEG、PNG 或 WebP 图片");
    if (blob.size > 20 * 1024 * 1024) throw new Error("头像原图不能超过 20 MiB");
    var sourceUrl = URL.createObjectURL(blob), image = await new Promise(function (resolve, reject) { var value = new Image(); value.onload = function () { resolve(value); }; value.onerror = function () { reject(new Error("头像图片无法读取")); }; value.src = sourceUrl; });
    var released = false; function release() { if (!released) { released = true; URL.revokeObjectURL(sourceUrl); } }
    var state = { zoom: 1, x: 0, y: 0 }, drag = null;
    var form = ui.openSubsheet({ title: "裁切头像", submitText: "使用头像", html: '<p class="helper crop-help">拖动图片调整位置，使用下方按钮缩放裁切范围。</p><div class="crop-stage" data-crop-stage><img id="cropImage" alt="头像裁切预览"><span class="crop-frame" aria-hidden="true"></span></div><div class="crop-toolbar"><button class="icon-button" type="button" data-crop-zoom="-0.1" aria-label="缩小">' + ui.icon("minus") + '</button><output data-crop-output>100%</output><button class="icon-button" type="button" data-crop-zoom="0.1" aria-label="放大">' + ui.icon("plus") + '</button></div>', onDismiss: release, onSubmit: async function () {
      var stageSize = stage.getBoundingClientRect().width || 320, baseScale = stageSize / Math.min(image.naturalWidth, image.naturalHeight), scale = baseScale * state.zoom;
      var side = stageSize / scale, centerX = image.naturalWidth / 2 - state.x / scale, centerY = image.naturalHeight / 2 - state.y / scale;
      var canvas = document.createElement("canvas"); canvas.width = 320; canvas.height = 320;
      canvas.getContext("2d").drawImage(image, centerX - side / 2, centerY - side / 2, side, side, 0, 0, 320, 320);
      var output = await new Promise(function (resolve) { canvas.toBlob(resolve, "image/jpeg", 0.88); }); if (!output) throw new Error("头像裁切失败，请换一张图片"); return output;
    }, onSuccess: async function (output) { release(); await onCropped(output); } });
    var stage = form.querySelector("[data-crop-stage]"), preview = form.querySelector("#cropImage"); preview.src = sourceUrl;
    function clamp() { var size = stage.getBoundingClientRect().width || 320, ratio = image.naturalWidth / image.naturalHeight, baseWidth = ratio >= 1 ? size * ratio : size, baseHeight = ratio >= 1 ? size : size / ratio; state.x = Math.max(-(baseWidth * state.zoom - size) / 2, Math.min((baseWidth * state.zoom - size) / 2, state.x)); state.y = Math.max(-(baseHeight * state.zoom - size) / 2, Math.min((baseHeight * state.zoom - size) / 2, state.y)); }
    function paint() { var ratio = image.naturalWidth / image.naturalHeight; preview.style.width = ratio >= 1 ? ratio * 100 + "%" : "100%"; preview.style.height = ratio >= 1 ? "100%" : 100 / ratio + "%"; clamp(); preview.style.transform = "translate(calc(-50% + " + state.x + "px), calc(-50% + " + state.y + "px)) scale(" + state.zoom + ")"; form.querySelector("[data-crop-output]").textContent = Math.round(state.zoom * 100) + "%"; }
    stage.addEventListener("pointerdown", function (event) { drag = { id: event.pointerId, x: event.clientX, y: event.clientY, originX: state.x, originY: state.y }; stage.setPointerCapture(event.pointerId); });
    stage.addEventListener("pointermove", function (event) { if (!drag || drag.id !== event.pointerId) return; state.x = drag.originX + event.clientX - drag.x; state.y = drag.originY + event.clientY - drag.y; paint(); });
    function endDrag(event) { if (drag && drag.id === event.pointerId) drag = null; }
    stage.addEventListener("pointerup", endDrag); stage.addEventListener("pointercancel", endDrag);
    form.querySelectorAll("[data-crop-zoom]").forEach(function (button) { button.addEventListener("click", function () { state.zoom = Math.max(1, Math.min(3, state.zoom + Number(button.dataset.cropZoom))); paint(); }); }); paint();
  }

  async function openEditor(existing, onSaved) {
    var llms = (await store.list("llm-profiles")).filter(function (item) { return item.enabled !== false || existing && item.id === existing.llmProfileId; });
    if (!llms.length && !existing) { await app.navigate("models", { modelsTab: "llm" }); app.features.models.openService("llm", null, function () { return app.navigate("roles").then(function () { return openEditor(null, onSaved); }); }); return; }
    var settings = await store.get("meta", "settings"), ttsServices = (await store.list("tts-profiles")).filter(function (item) { return item.enabled !== false || existing && item.id === existing.ttsProfileId; });
    var editing = Boolean(existing), firstService = llms[0] || {};
    var role = existing || { id: u.id("role"), name: "", systemPrompt: "", llmProfileId: firstService.id || "", model: (app.services.modelServices.models("llm", firstService)[0] || {}).id || "", temperature: 0.7, maxOutputTokens: 4096, reasoningEffort: "", allowImageGeneration: false, ttsProfileId: "", ttsModel: "", ttsVoice: "", voicePrompt: "", avatarMediaId: "", enabled: true };
    var inheritedTts = ttsServices.find(function (item) { return item.id === settings.defaultTtsProfileId; });
    var html = '<div class="form-grid role-editor"><section class="editor-section"><h3>角色</h3><div class="avatar-editor"><button class="avatar-picker" type="button" data-choose-avatar aria-label="从图库选择角色头像"><span id="avatarPreview">' + ui.roleAvatar(role, "large") + '</span><span class="avatar-edit-badge" aria-hidden="true">' + ui.icon("camera") + '</span></button><div class="avatar-copy"><strong>角色头像</strong><small>点击头像从图库选择并裁切</small><div class="avatar-actions">' + (role.avatarMediaId ? '<button class="button ghost" type="button" data-remove-avatar>移除头像</button>' : '') + '</div></div></div><label class="field"><span>角色名称</span><input name="name" required maxlength="40" value="' + u.escapeHtml(role.name) + '" placeholder="怎么称呼这位角色？"></label><label class="field"><span>角色提示词</span><textarea class="prompt-editor" name="systemPrompt" required maxlength="12000" placeholder="描述身份、目标、边界与回答方式。">' + u.escapeHtml(role.systemPrompt) + '</textarea></label></section>' +
      '<section class="editor-section"><h3>语言模型</h3>' + ui.picker("llmProfileId", "模型服务", "") + ui.picker("model", "具体模型", "", "从模型服务提供或获取的可用列表中选择") + '<details class="advanced" open><summary>模型进阶设置</summary><div class="form-grid"><label class="field range-field" id="temperatureField"><span>温度 <output data-output="temperature">' + Number(role.temperature == null ? 0.7 : role.temperature).toFixed(1) + '</output></span><input name="temperature" type="range" min="0" max="2" step="0.1" value="' + Number(role.temperature == null ? 0.7 : role.temperature) + '"></label><label class="field range-field"><span>最大输出 <output data-output="maxOutputTokens">' + Number(role.maxOutputTokens || 4096) + ' tokens</output></span><input name="maxOutputTokens" type="range" min="256" max="32768" step="256" value="' + Number(role.maxOutputTokens || 4096) + '"></label><label class="field range-field" id="reasoningField"><span>推理强度 <output data-output="reasoningEffort">自动</output></span><input name="reasoningLevel" type="range" min="0" max="0" step="1" value="0"></label><label class="switch-row" id="imageGenerationField"><span><strong>允许图片生成</strong><small>仅在所选模型与协议支持时调用</small></span><input name="allowImageGeneration" type="checkbox"' + (role.allowImageGeneration ? ' checked' : '') + '></label></div></details></section>' +
      '<section class="editor-section"><h3>朗读声音</h3>' + ui.picker("ttsProfileId", "朗读模型家族", "") + '<div id="ttsModelField">' + ui.picker("ttsModel", "TTS 模型", "") + '</div><div id="ttsVoiceField">' + ui.picker("ttsVoice", "音色", "") + '</div><label class="field" id="voicePromptField"><span>音色提示词</span><textarea name="voicePrompt" maxlength="2000" placeholder="例如：温暖、沉稳，语速自然，停顿清晰。">' + u.escapeHtml(role.voicePrompt || "") + '</textarea></label><p class="helper" id="voiceHelp"></p><button class="button secondary full" type="button" data-preview-tts>' + ui.icon("volume-high") + '试听</button></section>' +
      '<label class="switch-row"><span><strong>启用角色</strong><small>停用后保留历史，不接收新消息</small></span><input name="enabled" type="checkbox"' + (role.enabled !== false ? ' checked' : '') + '></label>' + (editing ? '<button class="button danger full" type="button" data-delete-role>' + ui.icon("trash") + '删除角色</button>' : '') + '</div>';
    var stagedAvatarId = "", stagedAvatarUrl = "", removeAvatar = false, submitted = false;
    var form = ui.openModal({ title: editing ? "编辑角色" : "创建角色", submitText: editing ? "保存更改" : "创建角色", html: html, onDismiss: function () { if (!submitted && stagedAvatarId) app.data.media.remove(stagedAvatarId).catch(function () {}); }, onSubmit: async function (target) {
      var llm = selectedLlm(), modelId = u.formValue(target, "model"), definition = app.services.modelServices.modelDefinition("llm", llm, modelId), levels = definition.reasoning || [];
      var ttsProfileId = u.formValue(target, "ttsProfileId"), ttsService = selectedTts(), ttsModels = app.services.modelServices.models("tts", ttsService);
      var ttsModel = ttsProfileId ? (u.formValue(target, "ttsModel") || (ttsModels[0] || {}).id || "") : "", ttsDefinition = app.services.modelServices.modelDefinition("tts", ttsService, ttsModel);
      var voices = app.services.modelServices.voices(ttsService, ttsModel);
      var next = Object.assign({}, role, { name: u.formValue(target, "name"), systemPrompt: u.formValue(target, "systemPrompt"), avatarMediaId: removeAvatar ? "" : stagedAvatarId || role.avatarMediaId || "", llmProfileId: llm && llm.id || "", model: modelId, temperature: definition.temperature === false ? null : Number(u.formValue(target, "temperature")), maxOutputTokens: Number(u.formValue(target, "maxOutputTokens")), reasoningEffort: levels[Number(u.formValue(target, "reasoningLevel"))] || "", allowImageGeneration: definition.imageGeneration ? u.checked(target, "allowImageGeneration") : false, ttsProfileId: ttsProfileId, ttsModel: ttsModel, ttsVoice: ttsProfileId && (ttsService.family || ttsService.type) !== "system" ? (u.formValue(target, "ttsVoice") || (voices[0] || {}).id || "") : "", voicePrompt: ttsProfileId && ttsDefinition.voicePrompt ? u.formValue(target, "voicePrompt") : "", enabled: u.checked(target, "enabled"), updatedAt: Date.now(), createdAt: role.createdAt || Date.now() });
      delete next.description; delete next.avatarIcon; delete next.avatarColor;
      if (!next.name || !next.systemPrompt) throw new Error("请填写角色名称与提示词"); if (!next.llmProfileId || !next.model) throw new Error("请选择模型服务与具体模型"); if ((ttsService.family || ttsService.type) === "elevenlabs" && ttsProfileId && !next.ttsVoice) throw new Error("请先在模型页更新 ElevenLabs 音色列表并选择音色"); if (next.enabled && app.services.profiles.roleStatus(next, await store.list("llm-profiles"))) throw new Error("请为启用的角色配置可用模型");
      await store.put("roles", next.id, next); submitted = true; return next;
    }, onSuccess: async function (next) { if (existing && existing.avatarMediaId && existing.avatarMediaId !== next.avatarMediaId) await app.data.media.remove(existing.avatarMediaId).catch(function () {}); ui.toast(editing ? "角色已更新" : "角色已创建"); if (onSaved) return onSaved(next); if (app.state.route === "roles") await render(); } });

    function selectedLlm() { return llms.find(function (item) { return item.id === form.elements.namedItem("llmProfileId").value; }) || {}; }
    function selectedTts() { var id = form.elements.namedItem("ttsProfileId").value || settings.defaultTtsProfileId; return ttsServices.find(function (item) { return item.id === id; }) || {}; }
    ui.bindPicker(form, "llmProfileId", serviceItems(llms), role.llmProfileId || firstService.id);
    var modelPicker = ui.bindPicker(form, "model", named(app.services.modelServices.models("llm", selectedLlm())), role.model);
    ui.bindPicker(form, "ttsProfileId", [{ id: "", name: "跟随通用设置 · " + (inheritedTts ? inheritedTts.name : "未设置") }].concat(serviceItems(ttsServices)), role.ttsProfileId || "", { allowEmpty: true });
    var ttsModelPicker = ui.bindPicker(form, "ttsModel", named(app.services.modelServices.models("tts", selectedTts())), role.ttsModel || "", { allowEmpty: true });
    var voicePicker = ui.bindPicker(form, "ttsVoice", named(app.services.modelServices.voices(selectedTts(), role.ttsModel || "")), role.ttsVoice || "", { allowEmpty: true });

    function syncModel(reset) {
      var service = selectedLlm(), models = named(app.services.modelServices.models("llm", service)); modelPicker.setItems(models, reset ? (models[0] || {}).id || "" : undefined);
      var definition = app.services.modelServices.modelDefinition("llm", service, form.elements.namedItem("model").value), temp = form.elements.namedItem("temperature"); temp.disabled = definition.temperature === false; form.querySelector("#temperatureField").classList.toggle("is-hidden", temp.disabled);
      var output = form.elements.namedItem("maxOutputTokens"); output.max = Number(definition.maxOutputTokens || 32768); if (Number(output.value) > Number(output.max)) output.value = output.max;
      var levels = definition.reasoning || [], reasoning = form.elements.namedItem("reasoningLevel"); reasoning.max = Math.max(0, levels.length - 1); reasoning.disabled = !levels.length; var current = levels.indexOf(role.reasoningEffort); reasoning.value = String(current >= 0 ? current : 0); form.querySelector("#reasoningField").classList.toggle("is-hidden", reasoning.disabled);
      var image = form.elements.namedItem("allowImageGeneration"); image.disabled = !definition.imageGeneration; if (image.disabled) image.checked = false; form.querySelector("#imageGenerationField").classList.toggle("is-hidden", image.disabled); modelPicker.setDisabled(!models.length); syncRanges();
    }
    function syncTts(reset) {
      var service = selectedTts(), inherited = !form.elements.namedItem("ttsProfileId").value, system = (service.family || service.type) === "system", models = named(app.services.modelServices.models("tts", service));
      ttsModelPicker.setItems(models, reset ? (models[0] || {}).id || "" : undefined); var selectedModel = form.elements.namedItem("ttsModel").value || (models[0] || {}).id || "", voices = named(app.services.modelServices.voices(service, selectedModel)); voicePicker.setItems(voices, reset ? (voices[0] || {}).id || "" : undefined);
      form.querySelector("#ttsModelField").classList.toggle("is-hidden", inherited || system || models.length < 2); form.querySelector("#ttsVoiceField").classList.toggle("is-hidden", inherited || system || voices.length < 2);
      var modelId = form.elements.namedItem("ttsModel").value || (models[0] || {}).id || "", definition = app.services.modelServices.modelDefinition("tts", service, modelId); form.querySelector("#voicePromptField").classList.toggle("is-hidden", inherited || system || !definition.voicePrompt);
      form.querySelector("#voiceHelp").textContent = system ? "系统朗读直接使用 Android 当前语音引擎与系统音色。" : inherited ? "具体模型和音色跟随通用默认服务。" : (service.family || service.type) === "elevenlabs" && !voices.length ? "请先在模型页更新 ElevenLabs 音色列表。" : "只显示当前服务实际提供的可选层级。";
      var preview = form.querySelector("[data-preview-tts]"); preview.disabled = !service.id || service.enabled === false || (!system && !models.length) || ((service.family || service.type) === "elevenlabs" && !voices.length);
    }
    function syncRanges() { form.querySelector('[data-output="temperature"]').textContent = Number(form.elements.namedItem("temperature").value).toFixed(1); form.querySelector('[data-output="maxOutputTokens"]').textContent = form.elements.namedItem("maxOutputTokens").value + " tokens"; var levels = app.services.modelServices.modelDefinition("llm", selectedLlm(), form.elements.namedItem("model").value).reasoning || []; form.querySelector('[data-output="reasoningEffort"]').textContent = levels[Number(form.elements.namedItem("reasoningLevel").value)] || "不支持"; }
    function syncAvatar() { var preview = form.querySelector("#avatarPreview"); if (stagedAvatarUrl) preview.innerHTML = '<span class="avatar large" aria-hidden="true"><img src="' + u.escapeHtml(stagedAvatarUrl) + '" alt=""></span>'; else { preview.innerHTML = ui.avatar(form.elements.namedItem("name").value, "", "large", "", removeAvatar ? "" : role.avatarMediaId); ui.hydrateAvatars(preview); } }
    form.elements.namedItem("llmProfileId").addEventListener("change", function () { syncModel(true); }); form.elements.namedItem("model").addEventListener("change", function () { syncModel(false); }); form.elements.namedItem("ttsProfileId").addEventListener("change", function () { syncTts(true); }); form.elements.namedItem("ttsModel").addEventListener("change", function () { syncTts(false); }); form.elements.namedItem("name").addEventListener("input", syncAvatar); form.querySelectorAll('input[type="range"]').forEach(function (input) { input.addEventListener("input", syncRanges); });
    form.querySelector("[data-choose-avatar]").addEventListener("click", ui.action(async function () { var picked = await pickLocalImage(); if (!picked) return; await cropAvatar(picked, async function (output) { if (stagedAvatarId) await app.data.media.remove(stagedAvatarId).catch(function () {}); var record = await app.data.media.put(output, { name: "role-avatar.jpg", mime: "image/jpeg" }); stagedAvatarId = record.id; stagedAvatarUrl = await u.blobToDataUrl(output); removeAvatar = false; syncAvatar(); if (!form.querySelector("[data-remove-avatar]")) { var button = document.createElement("button"); button.type = "button"; button.className = "button ghost"; button.dataset.removeAvatar = ""; button.textContent = "移除头像"; form.querySelector(".avatar-actions").appendChild(button); bindRemoveAvatar(button); } }); }));
    form.querySelector("[data-preview-tts]").addEventListener("click", ui.action(async function () { var service = selectedTts(), models = app.services.modelServices.models("tts", service), modelId = u.formValue(form, "ttsModel") || (models[0] || {}).id || "", voices = app.services.modelServices.voices(service, modelId), model = app.services.modelServices.modelDefinition("tts", service, modelId); if (!service.id || service.enabled === false) throw new Error("请选择可用的朗读服务"); await app.services.tts.speak("你好！欢迎使用朗读功能。", { ttsProfileId: service.id, ttsModel: modelId, ttsVoice: u.formValue(form, "ttsVoice") || (voices[0] || {}).id || "", voicePrompt: model.voicePrompt ? u.formValue(form, "voicePrompt") : "" }); }));
    function bindRemoveAvatar(button) { button.addEventListener("click", ui.action(async function () { if (stagedAvatarId) await app.data.media.remove(stagedAvatarId).catch(function () {}); stagedAvatarId = ""; stagedAvatarUrl = ""; removeAvatar = true; button.remove(); syncAvatar(); })); }
    var avatarRemove = form.querySelector("[data-remove-avatar]"); if (avatarRemove) bindRemoveAvatar(avatarRemove);
    var remove = form.querySelector("[data-delete-role]"); if (remove) remove.addEventListener("click", ui.action(async function () { var refs = (await store.list("conversations")).filter(function (conversation) { return conversation.roleIds.indexOf(role.id) >= 0; }); if (refs.length) { ui.toast("角色仍参与“" + refs[0].title + "”，请先编辑该对话"); return; } if (await ui.confirm({ title: "删除“" + role.name + "”？", message: "角色提示词、模型设置与本地头像将从当前设备删除。", danger: true, confirmText: "删除角色" })) { await store.remove("roles", role.id); if (role.avatarMediaId) await app.data.media.remove(role.avatarMediaId).catch(function () {}); if (app.state.route === "roles") await render(); } }));
    syncModel(false); syncTts(false); syncAvatar(); return form;
  }

  app.features = app.features || {};
  app.features.roles = { render: render, openEditor: openEditor };
})(window.chataxi);
