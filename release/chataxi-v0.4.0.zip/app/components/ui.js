(function (app) {
  "use strict";
  var utils = app.utils;
  var toastTimer = null;
  var modal = null;
  var subsheet = null;

  function icon(name) { return '<i class="fa-solid fa-' + utils.escapeHtml(name) + '" aria-hidden="true"></i>'; }
  function avatar(name, color, className, iconName, mediaId) {
    var cleanName = String(name || "").trim();
    var label = cleanName ? Array.from(cleanName)[0].toUpperCase() : icon("user");
    color = /^#[0-9a-f]{6}$/i.test(color || "") ? color : "#656c58";
    var media = String(mediaId || "");
    return '<span class="avatar ' + utils.escapeHtml(className || "") + '" style="background:' + color + '"' + (media ? ' data-avatar-media="' + utils.escapeHtml(media) + '"' : '') + ' aria-hidden="true">' + (cleanName ? utils.escapeHtml(label) : label) + '</span>';
  }
  function roleAvatar(role, className) { return avatar(role && role.name, "", className, "", role && role.avatarMediaId); }
  async function hydrateAvatars(root) {
    var nodes = (root || document).querySelectorAll("[data-avatar-media]:not([data-avatar-loaded])");
    await Promise.all(Array.prototype.map.call(nodes, async function (node) {
      node.setAttribute("data-avatar-loaded", "loading");
      try {
        var dataUrl = await app.data.media.toDataUrl(node.dataset.avatarMedia);
        if (dataUrl && node.isConnected) { var image = document.createElement("img"); image.src = dataUrl; image.alt = ""; node.textContent = ""; node.appendChild(image); node.setAttribute("data-avatar-loaded", "true"); }
        else node.removeAttribute("data-avatar-loaded");
      } catch (_) { node.removeAttribute("data-avatar-loaded"); }
    }));
  }
  function toast(message, duration) {
    var root = document.getElementById("toastRoot");
    clearTimeout(toastTimer);
    root.innerHTML = '<div class="toast" role="status">' + utils.escapeHtml(message) + '</div>';
    toastTimer = setTimeout(function () { root.innerHTML = ""; }, duration || 3200);
  }
  function action(fn) {
    return function () {
      var result;
      try { result = fn.apply(this, arguments); }
      catch (error) { toast(utils.cleanError(error), 5000); return; }
      return Promise.resolve(result).catch(function (error) { toast(utils.cleanError(error), 5000); });
    };
  }
  function closeSubsheet(force, submitted) {
    if (!subsheet || (subsheet.busy && force !== true)) return;
    var previous = subsheet; subsheet = null;
    document.removeEventListener("keydown", previous.keydown, true);
    previous.layer.remove();
    if (previous.focus && previous.focus.isConnected) previous.focus.focus();
    if (!modal) { document.getElementById("appShell").removeAttribute("aria-hidden"); document.body.classList.remove("modal-open"); }
    if (!submitted && previous.options.onDismiss) previous.options.onDismiss();
  }
  function closeModal(force, submitted) {
    if (subsheet) closeSubsheet(true);
    if (!modal || (modal.busy && force !== true)) return;
    var previous = modal;
    modal = null;
    document.getElementById("modalRoot").innerHTML = "";
    document.getElementById("appShell").removeAttribute("aria-hidden");
    document.body.classList.remove("modal-open");
    document.removeEventListener("keydown", previous.keydown, true);
    if (previous.focus && previous.focus.isConnected) previous.focus.focus();
    if (!submitted && previous.options.onDismiss) previous.options.onDismiss();
  }
  function openModal(options) {
    closeModal(true);
    var root = document.getElementById("modalRoot");
    var current = { options: options, focus: document.activeElement, busy: false };
    modal = current;
    root.innerHTML = '<div class="modal-backdrop"><section class="modal-sheet" role="dialog" aria-modal="true" aria-labelledby="modalTitle" tabindex="-1">' +
      '<div class="modal-handle" aria-hidden="true"></div><header class="modal-head"><h2 id="modalTitle">' + utils.escapeHtml(options.title) + '</h2><button class="icon-button" type="button" data-close-modal aria-label="关闭">' + icon("xmark") + '</button></header>' +
      '<form id="modalForm"><div class="modal-body">' + options.html + '</div><div class="modal-actions">' +
      (options.cancelText === null ? '' : '<button class="button secondary" type="button" data-close-modal>' + utils.escapeHtml(options.cancelText || "取消") + '</button>') +
      '<button class="button ' + (options.danger ? 'danger' : 'primary') + '" id="modalSubmit" type="submit">' + utils.escapeHtml(options.submitText || "保存") + '</button></div></form></section></div>';
    document.body.classList.add("modal-open");
    document.getElementById("appShell").setAttribute("aria-hidden", "true");
    var form = document.getElementById("modalForm");
    form.querySelectorAll("[name]").forEach(function (field) { if (!field.id) field.id = "field-" + field.name.replace(/[^a-zA-Z0-9_-]/g, "-"); });
    root.querySelectorAll("[data-close-modal]").forEach(function (button) { button.addEventListener("click", function () { closeModal(); }); });
    root.querySelector(".modal-backdrop").addEventListener("click", function (event) { if (event.target === event.currentTarget) closeModal(); });
    current.keydown = function (event) {
      if (subsheet) return;
      if (event.key === "Escape") { event.preventDefault(); closeModal(); }
      if (event.key !== "Tab") return;
      var focusable = Array.prototype.filter.call(root.querySelectorAll('button, input, select, textarea, summary, [tabindex="0"]'), function (item) { return !item.disabled && item.getClientRects().length; });
      if (!focusable.length) { event.preventDefault(); return; }
      var first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || focusable.indexOf(document.activeElement) < 0)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || focusable.indexOf(document.activeElement) < 0)) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", current.keydown, true);
    form.addEventListener("submit", async function (event) {
      event.preventDefault();
      if (current.busy) return;
      current.busy = true;
      var buttons = root.querySelectorAll(".modal-actions button, [data-close-modal]");
      buttons.forEach(function (button) { button.disabled = true; });
      var submit = form.querySelector('[type="submit"]');
      var label = submit.textContent; submit.textContent = "正在保存…";
      try {
        var value = await options.onSubmit(form);
        if (value !== false && modal === current) {
          closeModal(true, true);
          if (options.onSuccess) await options.onSuccess(value);
        }
      } catch (error) {
        if (modal !== current) { toast(utils.cleanError(error), 5000); return; }
        var existing = form.querySelector(".form-error");
        if (!existing) { existing = document.createElement("div"); existing.className = "error-box form-error"; existing.setAttribute("role", "alert"); existing.tabIndex = -1; form.querySelector(".modal-body").prepend(existing); }
        existing.textContent = utils.cleanError(error); existing.focus();
      } finally {
        current.busy = false; submit.textContent = label;
        buttons.forEach(function (button) { button.disabled = false; });
      }
    });
    // Focus the dialog heading without raising the mobile keyboard before the user chooses a field.
    root.querySelector(".modal-sheet").focus();
    return form;
  }
  function openSubsheet(options) {
    closeSubsheet(true);
    var root = document.getElementById("modalRoot"), layer = document.createElement("div");
    var current = { options: options, focus: document.activeElement, busy: false, layer: layer };
    subsheet = current;
    layer.className = "modal-backdrop subsheet-backdrop";
    layer.innerHTML = '<section class="modal-sheet subsheet" role="dialog" aria-modal="true" tabindex="-1"><div class="modal-handle" aria-hidden="true"></div><header class="modal-head"><h2>' + utils.escapeHtml(options.title) + '</h2><button class="icon-button" type="button" data-close-subsheet aria-label="关闭">' + icon("xmark") + '</button></header><form class="subsheet-form"><div class="modal-body">' + options.html + '</div><div class="modal-actions">' + (options.cancelText === null ? '' : '<button class="button secondary" type="button" data-close-subsheet>' + utils.escapeHtml(options.cancelText || "取消") + '</button>') + (options.submitText === null ? '' : '<button class="button ' + (options.danger ? 'danger' : 'primary') + '" type="submit">' + utils.escapeHtml(options.submitText || "完成") + '</button>') + '</div></form></section>';
    root.appendChild(layer); document.body.classList.add("modal-open"); document.getElementById("appShell").setAttribute("aria-hidden", "true");
    var form = layer.querySelector("form");
    form.querySelectorAll("[name]").forEach(function (field) { if (!field.id) field.id = "subfield-" + field.name.replace(/[^a-zA-Z0-9_-]/g, "-"); });
    layer.querySelectorAll("[data-close-subsheet]").forEach(function (button) { button.addEventListener("click", function () { closeSubsheet(); }); });
    layer.addEventListener("click", function (event) { if (event.target === layer) closeSubsheet(); });
    current.keydown = function (event) { if (event.key === "Escape") { event.preventDefault(); event.stopImmediatePropagation(); closeSubsheet(); } };
    document.addEventListener("keydown", current.keydown, true);
    form.addEventListener("submit", async function (event) {
      event.preventDefault(); if (current.busy) return; current.busy = true;
      var buttons = layer.querySelectorAll("button"); buttons.forEach(function (button) { button.disabled = true; });
      try { var value = options.onSubmit ? await options.onSubmit(form) : true; if (value !== false && subsheet === current) { closeSubsheet(true, true); if (options.onSuccess) await options.onSuccess(value); } }
      catch (error) { if (subsheet !== current) { toast(utils.cleanError(error), 5000); return; } var box = form.querySelector(".form-error"); if (!box) { box = document.createElement("div"); box.className = "error-box form-error"; box.setAttribute("role", "alert"); form.querySelector(".modal-body").prepend(box); } box.textContent = utils.cleanError(error); }
      finally { current.busy = false; buttons.forEach(function (button) { button.disabled = false; }); }
    });
    layer.querySelector(".modal-sheet").focus(); return form;
  }
  function choose(options) {
    return new Promise(function (resolve) {
      var settled = false;
      function finish(value) { if (settled) return; settled = true; resolve(value); }
      var items = options.items || [];
      var html = '<div class="menu-list choice-sheet-list"></div>' + (options.refresh ? '<button class="button ghost full choice-refresh" type="button">' + icon("arrows-rotate") + utils.escapeHtml(options.refreshText || "刷新列表") + '</button>' : '');
      var form = openSubsheet({ title: options.title || "请选择", html: html, submitText: null, onDismiss: function () { finish(null); } });
      function paint() {
        var list = form.querySelector(".choice-sheet-list");
        list.innerHTML = items.length ? items.map(function (item) { return '<button class="menu-item" type="button" data-choice="' + utils.escapeHtml(item.id) + '"><span>' + utils.escapeHtml(item.name || item.id) + '</span>' + (item.id === options.selected ? icon("check") : '') + '</button>'; }).join("") : '<p class="helper choice-empty">暂无可选项</p>';
        list.querySelectorAll("[data-choice]").forEach(function (button) { button.addEventListener("click", function () { var value = button.dataset.choice; closeSubsheet(true, true); finish(value); }); });
      }
      paint();
      var refresh = form.querySelector(".choice-refresh");
      if (refresh) refresh.addEventListener("click", action(async function () { refresh.disabled = true; try { items = await options.refresh(); paint(); } finally { if (refresh.isConnected) refresh.disabled = false; } }));
    });
  }
  function picker(name, label, selectedLabel, help) {
    return '<label class="field picker-field"><span>' + utils.escapeHtml(label) + '</span><input type="hidden" name="' + utils.escapeHtml(name) + '"><button class="picker-button" type="button" data-picker="' + utils.escapeHtml(name) + '" data-picker-title="' + utils.escapeHtml(label) + '"><span data-picker-label>' + utils.escapeHtml(selectedLabel || "请选择") + '</span>' + icon("chevron-down") + '</button>' + (help ? '<small>' + utils.escapeHtml(help) + '</small>' : '') + '</label>';
  }
  function bindPicker(form, name, items, selected, options) {
    var input = form.elements.namedItem(name), button = form.querySelector('[data-picker="' + name + '"]'), currentItems = items || [];
    input.value = selected || "";
    function paint() { var item = currentItems.find(function (entry) { return entry.id === input.value; }); button.querySelector("[data-picker-label]").textContent = item ? item.name || item.id : options && options.emptyLabel || "请选择"; button.disabled = Boolean(options && options.disabled); }
    button.addEventListener("click", action(async function () {
      var refreshItems = options && options.refresh ? async function () { currentItems = await options.refresh(); return currentItems; } : null;
      var value = await choose({ title: button.dataset.pickerTitle, items: currentItems, selected: input.value, refresh: refreshItems, refreshText: options && options.refreshText });
      if (value == null) return; input.value = value; paint(); input.dispatchEvent(new Event("change", { bubbles: true }));
    }));
    paint();
    return { setItems: function (next, nextValue) { currentItems = next || []; if (nextValue !== undefined) input.value = nextValue; if (!currentItems.some(function (item) { return item.id === input.value; })) input.value = options && options.allowEmpty ? "" : (currentItems[0] || {}).id || ""; paint(); }, setDisabled: function (value) { options = Object.assign({}, options, { disabled: value }); paint(); }, setRefresh: function (refresh, label) { options = Object.assign({}, options, { refresh: refresh || null, refreshText: label || "刷新列表" }); }, value: function () { return input.value; } };
  }
  function confirm(options) {
    return new Promise(function (resolve) {
      var open = modal ? openSubsheet : openModal;
      open({ title: options.title || "请确认", html: '<p class="dialog-copy">' + utils.escapeHtml(options.message || "确定继续吗？") + '</p>', submitText: options.confirmText || "确定", danger: Boolean(options.danger), onDismiss: function () { resolve(false); }, onSubmit: function () { return true; }, onSuccess: function () { resolve(true); } });
    });
  }
  function empty(iconName, title, text, actionHtml) {
    return '<div class="empty-state"><div class="empty-state-inner"><div class="empty-icon">' + icon(iconName) + '</div><h2>' + utils.escapeHtml(title) + '</h2><p>' + utils.escapeHtml(text) + '</p>' + (actionHtml || "") + '</div></div>';
  }
  function pageHeader(title, subtitle, actions) {
    document.getElementById("pageTitle").textContent = title;
    document.getElementById("pageSubtitle").textContent = subtitle;
    document.getElementById("topbarActions").innerHTML = actions || "";
  }
  function search(placeholder) {
    return '<label class="search-field">' + icon("magnifying-glass") + '<input type="search" id="listSearch" aria-label="' + utils.escapeHtml(placeholder) + '" placeholder="' + utils.escapeHtml(placeholder) + '"></label>';
  }
  app.components = { icon: icon, avatar: avatar, roleAvatar: roleAvatar, hydrateAvatars: hydrateAvatars, toast: toast, action: action, openModal: openModal, closeModal: closeModal, openSubsheet: openSubsheet, closeSubsheet: closeSubsheet, choose: choose, picker: picker, bindPicker: bindPicker, confirm: confirm, empty: empty, pageHeader: pageHeader, search: search };
})(window.chataxi);
