(function (global) {
  "use strict";
  global.chataxi = global.chataxi || {};
  global.chataxi.version = "0.4.13";
  global.chataxi.state = { route: "conversations", activeConversationId: null, modelsTab: "llm" };
})(window);
