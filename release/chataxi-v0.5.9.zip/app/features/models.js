(function (app) {
  "use strict";
  var u = app.utils, ui = app.components, store = app.data.store;
  var names = { llm: "对话模型", tts: "朗读模型", asr: "语音输入" };
  var icons = { llm: "brain", tts: "volume-high", asr: "microphone" }, testing = {};
  var systemRuntimeCache = {};

  function field(name, label, value, attrs) { return '<label class="field"><span>' + label + '</span><input name="' + name + '" value="' + u.escapeHtml(value || '') + '" ' + (attrs || '') + '></label>'; }
  function familyOf(kind, service) { return app.services.modelServices.family(kind, service.family || service.type); }
  function collection(kind) { return kind + "-profiles"; }
  function familyItems(kind) { return app.services.modelServices.families(kind).filter(function (item) { return item.id !== "system"; }).map(function (item) { return { id: item.id, name: item.name + " · " + item.description }; }); }
  function apiStyleItems() { return app.services.catalog.apiStyles.map(function (item) { return { id: item.id, name: item.name }; }); }
  function parseIds(value) { return String(value || "").split(/[\n,，]/).map(function (item) { return item.trim(); }).filter(Boolean); }
  function secretField(name, label, service, optional) {
    var value = service[name] || "";
    return '<div class="field" data-credential-field="' + name + '"><span data-credential-label="' + name + '">' + label + ' <em>' + (optional ? '选填；' : '') + (value ? '已保存在当前设备，可直接编辑' : '保存在当前设备') + '</em></span><div class="secret-editor"><input name="' + name + '" type="password" autocomplete="new-password" spellcheck="false" placeholder="粘贴' + label + '"><span class="secret-mask" aria-hidden="true">' + u.escapeHtml(value ? u.maskSecret(value) : '') + '</span><button class="button secondary compact secret-copy" type="button" data-copy-secret="' + name + '" aria-label="复制' + label + '">' + ui.icon("copy") + '<span>复制</span></button></div></div>';
  }
  function customHeadersField(service) {
    var entries = u.maskedHeaderEntries(service.customHeaders), hasSaved = Boolean(service.customHeaders), preview = '';
    if (hasSaved) preview = '<div class="saved-headers" data-saved-headers>' + (entries.length ? entries.map(function (entry, index) { return '<div class="saved-header-row"><span><strong>' + u.escapeHtml(entry.name) + '</strong><code>' + u.escapeHtml(entry.maskedValue) + '</code></span><button class="button secondary compact secret-copy" type="button" data-copy-header="' + index + '">' + ui.icon("copy") + '复制</button></div>'; }).join("") : '<p class="helper">已有 Header 无法解析；重新填写后会替换旧值。</p>') + '</div>';
    return '<div class="field"><span>自定义 Header <em>JSON，选填</em></span>' + preview + '<textarea name="customHeaders" spellcheck="false" placeholder="' + (hasSaved ? '留空保留现有 Header；填写 JSON 将整体替换' : '{&quot;X-Client&quot;:&quot;chataxi&quot;}') + '"></textarea></div>' + (hasSaved ? '<label class="switch-row" data-clear-custom-headers><span><strong>清除自定义 Header</strong><small>保存时删除已有 Header</small></span><input name="clearCustomHeaders" type="checkbox"></label>' : '');
  }
  function modelText(service) { return app.services.modelServices.models("llm", service).map(function (item) { return item.name || item.id; }).slice(0, 3).join("、") || "没有启用模型"; }
  function capabilityText(service, model) {
    var value = app.services.modelServices.modelDefinition("llm", service, model.id), parts = [];
    if (value.maxOutputTokens) parts.push("最大输出 " + value.maxOutputTokens + " tokens");
    if (value.temperature === true) parts.push("温度"); if ((value.reasoning || []).length) parts.push("推理 " + value.reasoning.join(" / "));
    if (value.imageInput === true) parts.push("图片输入"); if (value.videoInput === true) parts.push("视频输入"); if (value.imageGeneration === true) parts.push("图片生成"); if (value.streaming !== false) parts.push("流式输出");
    return parts.join(" · ") || "仅确认基础文字调用";
  }
  function capabilitySourceText(model) {
    var source = model && model.capabilitySource || "unknown";
    if (source === "service-directory") return "能力来自当前服务目录";
    if (source === "service-directory+reviewed-registry") return "能力来自当前服务目录与官方规则";
    if (source === "reviewed-registry") return "能力来自应用内官方规则";
    if (source === "account-directory") return "能力来自当前账户目录";
    if (source === "runtime-directory") return "能力来自当前本地运行实例";
    return "未取得参数能力说明";
  }
  function parameterLabel(name) { return ({ temperature: "温度", max_output_tokens: "最大输出", reasoning_effort: "推理强度", image_input: "图片输入", video_input: "视频输入", image_generation: "图片生成" })[name] || name; }
  async function systemRuntime(kind, refresh) {
    if (kind === "asr") return app.services.asr.systemCapability(refresh);
    if (kind !== "tts") return null;
    if (!refresh && systemRuntimeCache.tts && Date.now() - systemRuntimeCache.tts.at < 30000) return systemRuntimeCache.tts.value;
    var value;
    if (!(await app.platform.hermit.awaitReady(1200))) value = { available: false, operational: false, voices: [], languages: [], message: "Android 系统朗读只在 HermitApp 中可用" };
    else {
      var api = app.platform.hermit.api(), availability = await api.tts.availability(), catalog = { voices: [], languages: [] };
      if (availability.operational) { try { catalog = await api.tts.voices(); } catch (_) {} }
      value = Object.assign({}, availability, catalog, { voices: Array.isArray(catalog.voices) ? catalog.voices : [], languages: Array.isArray(catalog.languages) ? catalog.languages : [] });
    }
    systemRuntimeCache.tts = { at: Date.now(), value: value }; return value;
  }

  async function render() {
    var kind = app.state.modelsTab || "llm"; if (!names[kind]) kind = app.state.modelsTab = "llm";
    ui.pageHeader("模型", "服务与模型能力"); var main = document.getElementById("mainContent"); main.className = "main";
    main.innerHTML = '<section class="page models-page"><div class="section-tabs" role="tablist" aria-label="模型服务分类">' + Object.keys(names).map(function (key) { return '<button type="button" role="tab" id="models-tab-' + key + '" aria-controls="modelsContent" data-model-tab="' + key + '" aria-selected="' + (key === kind) + '"><span>' + names[key] + '</span></button>'; }).join("") + '</div><div id="modelsContent" role="tabpanel" aria-labelledby="models-tab-' + kind + '"></div></section>';
    main.querySelectorAll("[data-model-tab]").forEach(function (button) { button.addEventListener("click", ui.action(async function () { app.state.modelsTab = button.dataset.modelTab; await render(); })); }); await renderServices(kind);
  }

  async function renderServices(kind) {
    var services = await store.list(collection(kind)); if (app.state.route !== "models" || app.state.modelsTab !== kind) return;
    var runtime = (kind === "tts" || kind === "asr") && services.some(function (service) { return familyOf(kind, service).id === "system"; }) ? await systemRuntime(kind, true) : null;
    if (app.state.route !== "models" || app.state.modelsTab !== kind) return;
    var content = document.getElementById("modelsContent"), note = kind === "llm" ? "连接后获取可用模型与能力；默认模型用于连接测试和新角色。" : kind === "tts" ? "默认模型与音色用于试听，并作为新角色的初始选择。" : "只为当前真正可用的语音输入服务提供录音测试和设置。";
    content.innerHTML = '<div class="section-toolbar"><p>' + note + '</p><button class="button primary compact" type="button" data-add-service>' + ui.icon("plus") + '添加服务</button></div><div class="list model-service-list">' + services.map(function (service) {
      var definition = familyOf(kind, service), system = definition.id === "system", enabled = app.services.modelServices.models(kind, service), all = app.services.modelServices.allModels(kind, service), missing = app.services.modelServices.serviceStatus(kind, service);
      var systemUsable = !system || (kind === "tts" ? Boolean(runtime && runtime.operational) : Boolean(runtime && runtime.available));
      var status = service.enabled === false ? "已停用" : system ? (systemUsable ? "系统可用" : "不可用") : missing || (service.validationState === "verified" ? "已验证" : service.catalogState === "fetched" ? "已获取目录" : "已配置");
      var defaultModel = enabled.find(function (item) { return item.id === service.defaultModelId; }) || enabled[0], defaultVoice = kind === "tts" ? app.services.modelServices.voices(service, defaultModel && defaultModel.id).find(function (item) { return item.id === service.defaultVoiceId; }) : null;
      var detail = kind === "llm" ? enabled.length + "/" + all.length + " 个模型 · 默认 " + (defaultModel ? defaultModel.name || defaultModel.id : "未选择") : kind === "tts" ? (system ? (systemUsable ? (runtime.voices.length ? runtime.voices.length + " 个系统音色" : "跟随系统默认音色") : runtime && runtime.message || "系统朗读不可用") : enabled.length + " 个模型 · " + app.services.modelServices.voices(service).length + " 个音色 · 默认 " + (defaultModel ? defaultModel.name || defaultModel.id : "未选择") + (defaultVoice ? " / " + (defaultVoice.name || defaultVoice.id) : "")) : system ? (systemUsable ? (runtime.streamingAvailable ? "连续识别可用" : "一次性识别可用") + (runtime.languages.length ? " · " + runtime.languages.length + " 种系统语言" : " · 跟随系统语言") : runtime && runtime.message || "系统语音识别不可用") : enabled.length + " 个识别模型";
      var actions = system && !systemUsable ? '<p class="service-unavailable">' + u.escapeHtml(runtime && runtime.message || (kind === "tts" ? "当前系统没有可用的朗读引擎" : "当前系统没有可用的语音识别服务")) + '</p>' : '<button class="button secondary" type="button" data-test-service="' + u.escapeHtml(service.id) + '"' + (testing[service.id] || service.enabled === false ? ' disabled' : '') + '>' + ui.icon(kind === "llm" ? "plug" : kind === "tts" ? "play" : "microphone") + (testing[service.id] ? "测试中…" : kind === "llm" ? "连接测试" : kind === "tts" ? "试听" : "录音测试") + '</button><span class="grow"></span><button class="button ghost" type="button" data-edit-service="' + u.escapeHtml(service.id) + '">' + ui.icon("gear") + '编辑</button>' + (!system ? '<button class="icon-button danger-text" type="button" data-remove-service="' + u.escapeHtml(service.id) + '" aria-label="删除服务">' + ui.icon("trash") + '</button>' : '');
      return '<article class="card model-service-card"><div class="service-summary"><span class="service-icon">' + ui.icon(icons[kind]) + '</span><div class="list-copy"><strong>' + u.escapeHtml(service.name || definition.name) + '</strong><span>' + u.escapeHtml(definition.name + " · " + detail) + '</span></div><span class="badge ' + (missing || service.enabled === false || system && !systemUsable ? "warning" : "success") + '">' + u.escapeHtml(status) + '</span></div>' + (!system && app.services.modelServices.computedEndpoint(kind, service) ? '<div class="service-endpoint">' + u.escapeHtml(app.services.modelServices.computedEndpoint(kind, service)) + '</div>' : '') + '<div class="profile-actions">' + actions + '</div></article>';
    }).join("") + '</div>';
    content.querySelector("[data-add-service]").addEventListener("click", function () { openService(kind); });
    content.querySelectorAll("[data-edit-service]").forEach(function (button) { button.addEventListener("click", ui.action(async function () { var service = await store.get(collection(kind), button.dataset.editService); if (kind === "tts" && familyOf(kind, service).id === "system") return openSystemTts(service); if (kind === "asr" && familyOf(kind, service).id === "system") return openSystemAsr(service); return openService(kind, service); })); });
    content.querySelectorAll("[data-remove-service]").forEach(function (button) { button.addEventListener("click", ui.action(async function () { var service = await store.get(collection(kind), button.dataset.removeService); if (await ui.confirm({ title: "删除“" + service.name + "”？", message: kind === "llm" ? "角色正在使用时不能删除此服务。" : "相关设置会回落到 Android 系统服务。", confirmText: "删除服务", danger: true })) { await app.services.profiles.remove(kind, service.id); ui.toast("服务已删除"); await renderServices(kind); } })); });
    content.querySelectorAll("[data-test-service]").forEach(function (button) { button.addEventListener("click", ui.action(async function () { var id = button.dataset.testService, service = await store.get(collection(kind), id); if (kind === "asr") return openAsrTest(service); testing[id] = true; await renderServices(kind); try { if (kind === "llm") { var available = app.services.modelServices.models(kind, service), selected = available.find(function (item) { return item.id === service.defaultModelId; }) || available[0]; if (!selected) throw new Error("服务没有已启用模型，请先编辑并连接服务"); await app.services.llm.test(service, selected.id); } else await app.services.tts.speak("你好！欢迎使用朗读功能。", { ttsProfileId: id }); ui.toast(kind === "llm" ? "默认模型连接成功" : "已使用默认模型与音色开始试听"); } finally { delete testing[id]; await renderServices(kind); } })); });
  }

  function languageItems(values) {
    var ids = (values || []).filter(Boolean), seen = {};
    return ids.filter(function (id) { if (seen[id]) return false; seen[id] = true; return true; }).map(function (id) { return { id: id, name: id }; });
  }

  async function openSystemTts(service) {
    if (!(await app.platform.hermit.awaitReady(1500))) throw new Error("系统朗读设置只在 HermitApp 中可用");
    var api = app.platform.hermit.api(), availability = await api.tts.availability(), preferences = await api.tts.preferences(), result = await api.tts.voices();
    if (!availability.operational) throw new Error(availability.message || "Android 系统朗读当前不可用");
    var voices = (result.voices || []).map(function (voice) { return { id: voice.id, name: (voice.locale ? voice.locale + " · " : "") + voice.id, locale: voice.locale || "", networkRequired: Boolean(voice.networkRequired), quality: voice.quality, latency: voice.latency, features: voice.features || [] }; });
    var languages = languageItems(result.languages || voices.map(function (voice) { return voice.locale; })), languageIds = languages.map(function (item) { return item.id; });
    var language = [service.language, preferences.language, (result.languages || [])[0]].find(function (value) { return languageIds.indexOf(value) >= 0; }) || "";
    var voiceIds = voices.map(function (voice) { return voice.id; }), defaultVoice = [service.defaultVoiceId, service.voice, result.selectedVoice, result.currentVoice].find(function (value) { return voiceIds.indexOf(value) >= 0; }) || "";
    var directoryNote = languages.length || voices.length ? "语言和音色来自当前系统 TTS 引擎；只显示引擎实际提供的选项。" : "当前引擎可以朗读，但没有公开可选语言或音色，将跟随系统默认设置。";
    var html = '<div class="form-grid system-service-editor"><div class="capability-note"><strong>Android 系统朗读可用</strong><small>' + u.escapeHtml(directoryNote) + '</small></div>' + (languages.length ? '<div data-system-tts-language>' + ui.picker("language", "默认语言", "") + '</div>' : '<input type="hidden" name="language" value="">') + (voices.length ? '<div data-system-tts-voice>' + ui.picker("defaultVoiceId", "默认音色", "", "用于服务试听和跟随通用设置的角色") + '</div>' : '<input type="hidden" name="defaultVoiceId" value="">') + '<label class="field range-field"><span>语速 <output data-output="rate">' + Number(service.rate || preferences.rate || 1).toFixed(1) + '</output></span><input name="rate" type="range" min="0.5" max="2" step="0.1" value="' + Number(service.rate || preferences.rate || 1) + '"></label><label class="field range-field"><span>音调 <output data-output="pitch">' + Number(service.pitch || preferences.pitch || 1).toFixed(1) + '</output></span><input name="pitch" type="range" min="0.5" max="2" step="0.1" value="' + Number(service.pitch || preferences.pitch || 1) + '"></label><button class="button secondary full" type="button" data-preview-system-tts>' + ui.icon("play") + '试听默认组合</button></div>';
    var form = ui.openModal({ title: "编辑 Android 系统朗读", submitText: "保存设置", html: html, onSubmit: async function (target) {
      var next = Object.assign({}, service, { family: "system", type: "system", enabled: true, models: ["system"], defaultModelId: "system", voices: voices, language: u.formValue(target, "language"), defaultVoiceId: u.formValue(target, "defaultVoiceId"), voice: u.formValue(target, "defaultVoiceId"), rate: Number(u.formValue(target, "rate")), pitch: Number(u.formValue(target, "pitch")), updatedAt: Date.now() });
      await store.put("tts-profiles", next.id, next); await app.services.tts.invalidateAll(); return next;
    }, onSuccess: async function () { ui.toast("系统朗读默认设置已保存"); if (app.state.route === "models") await renderServices("tts"); } });
    var languagePicker = languages.length ? ui.bindPicker(form, "language", languages, language) : null;
    var voicePicker = voices.length ? ui.bindPicker(form, "defaultVoiceId", [], defaultVoice, { allowEmpty: true }) : null;
    function syncVoices(reset) {
      if (!voicePicker) return;
      var selectedLanguage = u.formValue(form, "language"), filtered = voices.filter(function (voice) { return !selectedLanguage || !voice.locale || voice.locale.toLowerCase() === selectedLanguage.toLowerCase() || voice.locale.toLowerCase().indexOf(selectedLanguage.slice(0, 2).toLowerCase()) === 0; });
      if (!filtered.length) filtered = voices.slice();
      var requested = reset ? defaultVoice : u.formValue(form, "defaultVoiceId");
      voicePicker.setItems(filtered, requested);
    }
    if (languagePicker) form.elements.namedItem("language").addEventListener("change", function () { defaultVoice = ""; syncVoices(false); });
    form.querySelectorAll('input[type="range"]').forEach(function (input) { input.addEventListener("input", function () { form.querySelector('[data-output="' + input.name + '"]').textContent = Number(input.value).toFixed(1); }); });
    form.querySelector("[data-preview-system-tts]").disabled = !availability.operational;
    form.querySelector("[data-preview-system-tts]").addEventListener("click", ui.action(async function () { await api.tts.stop().catch(function () {}); await api.tts.speak({ text: "你好！欢迎使用朗读功能。", language: u.formValue(form, "language") || undefined, voiceId: u.formValue(form, "defaultVoiceId") || undefined, rate: Number(u.formValue(form, "rate")), pitch: Number(u.formValue(form, "pitch")) }); ui.toast("已开始试听"); }));
    syncVoices(true); return form;
  }

  async function openSystemAsr(service) {
    if (!(await app.platform.hermit.awaitReady(1500))) throw new Error("系统语音输入设置只在 HermitApp 中可用");
    var availability = await systemRuntime("asr", true); if (!availability.available) throw new Error(availability.message || "Android 系统语音识别当前不可用");
    var api = app.platform.hermit.api(), preferences = await api.speech.preferences(), languages = languageItems(availability.languages), languageIds = languages.map(function (item) { return item.id; });
    var language = [service.language, preferences.language, availability.preferredLanguage].find(function (value) { return languageIds.indexOf(value) >= 0; }) || "";
    var languageControl = languages.length ? ui.picker("language", "默认识别语言", "", "由当前系统识别服务提供") : '<input type="hidden" name="language" value=""><p class="helper">当前识别服务没有公开语言目录，将跟随系统默认识别语言。</p>';
    var html = '<div class="form-grid system-service-editor"><div class="capability-note"><strong>Android 系统语音识别可用</strong><small>' + u.escapeHtml(availability.streamingAvailable ? "支持实时识别、部分结果和录音电平。" : "设备只提供系统单次识别界面。") + '</small></div>' + languageControl + (availability.onDeviceAvailable ? '<label class="switch-row"><span><strong>优先设备端识别</strong><small>当前设备确认提供设备端识别</small></span><input name="onDevice" type="checkbox"' + (service.onDevice ? ' checked' : '') + '></label>' : '') + '<button class="button secondary full" type="button" data-preview-asr>' + ui.icon("microphone") + '录音测试</button></div>';
    var form = ui.openModal({ title: "编辑 Android 系统语音输入", submitText: "保存设置", html: html, onSubmit: async function (target) { var next = Object.assign({}, service, { family: "system", type: "system", enabled: true, models: ["system"], defaultModelId: "system", language: u.formValue(target, "language"), onDevice: availability.onDeviceAvailable && u.checked(target, "onDevice"), updatedAt: Date.now() }); await store.put("asr-profiles", next.id, next); return next; }, onSuccess: async function () { ui.toast("系统语音输入设置已保存"); if (app.state.route === "models") await renderServices("asr"); } });
    if (languages.length) ui.bindPicker(form, "language", languages, language);
    form.querySelector("[data-preview-asr]").addEventListener("click", function () { var draft = Object.assign({}, service, { family: "system", type: "system", language: u.formValue(form, "language"), onDevice: availability.onDeviceAvailable && u.checked(form, "onDevice") }); openAsrTest(draft); });
    return form;
  }

  async function openAsrTest(service) {
    var settings = await store.get("meta", "settings"), profile = app.services.modelServices.resolveAsr(service, {}, settings), system = (service.family || service.type) === "system", availability = null;
    if (system) { if (!(await app.platform.hermit.awaitReady(1500))) throw new Error("系统语音识别只在 HermitApp 中可用"); availability = await app.platform.hermit.api().speech.availability(); if (!availability.available) throw new Error(availability.message || "系统没有可用的语音识别服务"); }
    var bars = Array.apply(null, { length: 30 }).map(function (_, index) { return '<i style="--wave-index:' + index + '"></i>'; }).join("");
    var recording = false, subscriptionId = "", recordingId = "", logicalFileId = "", offs = [], closed = false;
    var form = ui.openSubsheet({ title: (service.name || "语音输入") + " · 录音测试", submitText: null, cancelText: "完成", html: '<div class="asr-test"><div class="asr-waveform" data-asr-waveform aria-label="实时录音波形">' + bars + '</div><p class="asr-test-status" data-asr-status>' + (system ? "点击开始，说完后再点停止。" : "点击开始录音；停止后会把录音提交给当前识别服务。") + '</p><div class="asr-transcript" data-asr-transcript aria-live="polite"><span>识别文字会显示在这里</span></div><button class="button primary full" type="button" data-asr-record>' + ui.icon("microphone") + '<span>开始录音</span></button></div>', onDismiss: function () { closed = true; cleanup(); } });
    var button = form.querySelector("[data-asr-record]"), status = form.querySelector("[data-asr-status]"), transcript = form.querySelector("[data-asr-transcript]"), wave = form.querySelector("[data-asr-waveform]"), waveBars = wave.querySelectorAll("i");
    function setLevel(value) { var level = Math.max(0, Math.min(1, Number(value || 0))); wave.classList.toggle("is-active", recording); waveBars.forEach(function (bar, index) { var distance = Math.abs(index - (waveBars.length - 1) / 2) / waveBars.length, shaped = recording ? Math.max(.06, Math.min(1, level * 1.75 + Math.sin(index * 1.9 + Date.now() / 140) * .07 - distance * .25)) : .05; bar.style.transform = "scaleY(" + shaped.toFixed(3) + ")"; }); }
    function setRecording(value) { recording = value; button.classList.toggle("recording", value); button.querySelector("span").textContent = value ? "停止并识别" : "开始录音"; setLevel(0); }
    function showText(value, partial) { transcript.innerHTML = '<p' + (partial ? ' class="is-partial"' : '') + '>' + u.escapeHtml(value || "没有识别到文字") + '</p>'; }
    function cleanup() { offs.splice(0).forEach(function (off) { off(); }); if (system && recording) app.services.asr.cancelSystem().catch(function () {}); if (!system && recordingId && app.platform.hermit.available()) app.platform.hermit.api().audio.cancelRecording({ recordingId: recordingId }).catch(function () {}); if (logicalFileId && app.platform.hermit.available()) app.platform.hermit.api().files.delete({ logicalFileId: logicalFileId }).catch(function () {}); recording = false; }
    async function finishThirdParty() {
      var api = app.platform.hermit.api(), file = await api.audio.stopRecording({ recordingId: recordingId, name: "chataxi-asr-test.m4a" }); recordingId = ""; logicalFileId = file.logicalFileId; setRecording(false); button.disabled = true; status.textContent = "正在提交录音并识别…";
      try { var text = await app.services.asr.transcribeFile(file, profile); if (closed) return; showText(text, false); status.textContent = "识别完成，可以再次测试。"; }
      catch (error) { if (!closed) status.textContent = u.cleanError(error); throw error; }
      finally { if (logicalFileId) await api.files.delete({ logicalFileId: logicalFileId }).catch(function () {}); logicalFileId = ""; if (!closed) button.disabled = false; }
    }
    async function startThirdParty() {
      if (!(await app.platform.hermit.awaitReady(1500))) throw new Error("第三方录音测试需要在 HermitApp 中使用");
      var api = app.platform.hermit.api();
      offs.push(app.platform.hermit.on("audio.recording.level", function (data) { if (!recordingId || data.recordingId !== recordingId) return; setLevel(data.level); }));
      offs.push(app.platform.hermit.on("audio.recording.limit", function (data) { if (!recordingId || data.recordingId !== recordingId) return; finishThirdParty().catch(function (error) { status.textContent = u.cleanError(error); button.disabled = false; }); }));
      var started = await api.audio.startRecording({ maxDurationMs: 30000 }); recordingId = started.recordingId; setRecording(true); status.textContent = "正在录音，最长 30 秒。";
    }
    async function startSystem() {
      if (!availability.streamingAvailable && availability.oneShotAvailable) {
        button.disabled = true; status.textContent = "请在系统语音输入界面完成录音。";
        try { var once = await app.platform.hermit.api().speech.recognizeOnce({ language: profile.language, maxResults: 3, preferOffline: Boolean(profile.onDevice) }); if (!once.cancelled) showText(((once.alternatives || [])[0] || {}).text || "", false); status.textContent = once.cancelled ? "已取消识别。" : "识别完成，可以再次测试。"; } finally { button.disabled = false; }
        return;
      }
      setRecording(true); status.textContent = "正在听，请开始说话。";
      try { subscriptionId = await app.services.asr.startSystem(profile, {
        ready: function () { status.textContent = "麦克风已就绪，请开始说话。"; },
        begin: function () { status.textContent = "正在识别…"; },
        rms: function (data) { setLevel(Math.max(0, Math.min(1, (Number(data.rmsDb || -20) + 20) / 24))); },
        partial: function (data) { showText(((data.alternatives || [])[0] || {}).text || data.text || "", true); },
        final: function (data) { setRecording(false); subscriptionId = ""; showText(((data.alternatives || [])[0] || {}).text || data.text || "", false); status.textContent = "识别完成，可以再次测试。"; },
        error: function (data) { setRecording(false); subscriptionId = ""; status.textContent = data.message || "识别失败，请重试。"; }
      }); } catch (error) { setRecording(false); status.textContent = u.cleanError(error); throw error; }
    }
    button.addEventListener("click", ui.action(async function () { if (recording) { if (system) { await app.services.asr.stopSystem(subscriptionId); status.textContent = "正在整理识别结果…"; } else await finishThirdParty(); return; } if (system) await startSystem(); else await startThirdParty(); }));
    setLevel(0); return form;
  }

  function openService(kind, existing, onSaved) {
    var editing = Boolean(existing), initialFamily = existing ? existing.family || existing.type || "custom" : "openai", definition = app.services.modelServices.family(kind, initialFamily);
    var service = existing || { id: u.id(kind), family: initialFamily, name: definition.name, enabled: true, models: [], voices: [] };
    var html = '<div class="form-grid service-editor">' + ui.picker("family", "模型家族", "") + '<p class="helper" id="familyDescription"></p>' + secretField("apiKey", definition.auth === "aws-sigv4" ? "Secret Access Key" : definition.auth === "azure" ? "Speech Key" : "API Key", service, definition.keyOptional) + '<div data-family-field="accessKeyId">' + secretField("accessKeyId", "Access Key ID", service, false) + '</div><div data-family-field="sessionToken">' + secretField("sessionToken", "Session Token", service, true) + '</div><div data-family-field="region">' + field("region", "区域", service.region || "", 'maxlength="80" placeholder="例如 cn-north-1 / eastus"') + '</div><div data-family-field="workspaceId">' + field("workspaceId", "业务空间 ID", service.workspaceId || "", 'maxlength="160" placeholder="使用专属域名时填写"') + '</div><div data-family-field="resourceEndpoint">' + field("resourceEndpoint", "资源 Endpoint", service.resourceEndpoint || "", 'type="url" placeholder="控制台提供的完整资源地址"') + '</div>' + (kind === "llm" || kind === "tts" ? '<button class="button secondary full" type="button" data-connect-service>' + ui.icon("plug") + (editing ? "重新连接并更新目录" : "连接服务并获取目录") + '</button><p class="connection-status" id="connectionStatus" role="status"></p><section id="availableModels"></section><div data-default-model-field>' + ui.picker("defaultModelId", "默认模型", "", "用于连接测试、试听和新角色的初始配置") + '</div>' + (kind === "tts" ? '<div data-default-voice-field>' + ui.picker("defaultVoiceId", "默认音色", "", "用于服务试听和新角色的初始配置") + '</div>' : '') : '') + '<div class="automation-note">' + ui.icon("wand-magic-sparkles") + '<span>应用会按模型家族填写协议与官方地址，并只显示已经确认的能力。连接测试会发送一次很短的请求，可能产生少量费用。</span></div><details class="advanced"><summary>更多设置</summary><div class="form-grid">' + field("name", "服务名称", service.name || definition.name, 'maxlength="80"') + field("endpoint", "完整请求地址", service.endpoint || definition.endpoint, 'type="url"') + (kind === "llm" ? '<div data-family-field="apiStyle">' + ui.picker("apiStyle", "接口协议", "") + '</div>' : '') + '<label class="field" data-family-field="manualModels"><span>' + (kind === "tts" ? "TTS 模型 ID" : kind === "asr" ? "识别模型 ID" : "模型 ID") + '</span><textarea name="modelsText" spellcheck="false" placeholder="每行一个模型 ID">' + u.escapeHtml((service.models || []).map(function (item) { return typeof item === "string" ? item : item.id; }).join("\n") || service.model || "") + '</textarea></label>' + (kind === "tts" ? '<label class="field" data-family-field="manualVoices"><span>音色 ID</span><textarea name="voicesText" spellcheck="false" placeholder="每行一个 Voice ID">' + u.escapeHtml((service.voices || []).map(function (item) { return typeof item === "string" ? item : item.id; }).join("\n") || service.voice || "") + '</textarea></label>' : '') + customHeadersField(service) + '</div></details><label class="switch-row"><span><strong>启用服务</strong><small>停用后保留配置，但不会被角色调用</small></span><input name="enabled" type="checkbox"' + (service.enabled !== false ? ' checked' : '') + '></label></div>';
    var working = Object.assign({}, service), selectedIds = Array.isArray(service.enabledModelIds) ? service.enabledModelIds.slice() : app.services.modelServices.allModels(kind, service).map(function (item) { return item.id; }), connectedIdentity = "", initialIdentity = "";
    var form = ui.openModal({
      title: (editing ? "编辑" : "添加") + names[kind] + "服务",
      submitText: "保存设置",
      html: html,
      onSubmit: async function () {
        var next = readDraft();
        var identityChanged = identity(next) !== (connectedIdentity || initialIdentity);
        if ((kind === "llm" || kind === "tts") && listSignature(next) === listSignature(working)) Object.assign(next, { models: working.models, modelsDiscovered: working.modelsDiscovered, voices: working.voices, voicesDiscovered: working.voicesDiscovered, catalogState: working.catalogState, discoveredAt: working.discoveredAt, discoveryWarnings: working.discoveryWarnings, validationState: working.validationState, validatedAt: working.validatedAt, connectionRevision: working.connectionRevision, combinationVerifications: working.combinationVerifications });
        if (identityChanged) Object.assign(next, { validationState: "unverified", validatedAt: 0, combinationVerifications: {} });
        var all = app.services.modelServices.allModels(kind, next);
        if ((kind === "llm" || kind === "tts") && !all.length) throw new Error("请先连接获取目录，或在更多设置中填写模型 ID");
        if (kind === "llm" || kind === "tts") {
          next.enabledModelIds = all.filter(function (item) { return selectedIds.indexOf(item.id) >= 0; }).map(function (item) { return item.id; });
          if (!next.enabledModelIds.length) throw new Error("请至少启用一个模型");
          if (next.enabledModelIds.indexOf(next.defaultModelId) < 0) throw new Error("请选择已启用的默认模型");
          if (kind === "tts" && !familyOf(kind, next).voiceOptional && !next.defaultVoiceId) throw new Error("请选择默认音色");
        }
        validate(next, false); await app.services.profiles.validateEnabled(kind, next); await store.put(collection(kind), next.id, next);
        if (kind === "tts") await app.services.tts.invalidateAll(); return next;
      },
      onSuccess: async function (next) { ui.toast("服务设置已保存"); if (onSaved) return onSaved(next); if (app.state.route === "models") await renderServices(kind); }
    });
    ["apiKey", "accessKeyId", "sessionToken"].forEach(function (name) { var input = form.elements.namedItem(name); if (input) input.value = service[name] || ""; });
    ui.bindPicker(form, "family", familyItems(kind), initialFamily);
    var apiStylePicker = kind === "llm" ? ui.bindPicker(form, "apiStyle", apiStyleItems(), service.apiStyle || definition.apiStyle) : null;
    var defaultModelPicker = kind === "llm" || kind === "tts" ? ui.bindPicker(form, "defaultModelId", [], service.defaultModelId || service.model || "") : null;
    var defaultVoicePicker = kind === "tts" ? ui.bindPicker(form, "defaultVoiceId", [], service.defaultVoiceId || service.voice || "", { allowEmpty: true }) : null;
    function entered(name) { var element = form.elements.namedItem(name); return element ? element.value.trim() : ""; }
    function keepSecret(name, same) { return entered(name) || (same ? service[name] || "" : ""); }
    function readDraft() { var familyId = entered("family"), family = app.services.modelServices.family(kind, familyId), same = (service.family || service.type) === familyId; return Object.assign({}, service, { family: familyId, type: family.type || familyId, name: entered("name") || family.name, endpoint: entered("endpoint") || family.endpoint || "", apiStyle: kind === "llm" ? entered("apiStyle") || family.apiStyle : undefined, apiKey: keepSecret("apiKey", same), accessKeyId: keepSecret("accessKeyId", same), sessionToken: keepSecret("sessionToken", same), region: entered("region"), workspaceId: entered("workspaceId"), resourceEndpoint: entered("resourceEndpoint"), customHeaders: u.checked(form, "clearCustomHeaders") ? "" : entered("customHeaders") || (same ? service.customHeaders || "" : ""), models: parseIds(entered("modelsText")), voices: kind === "tts" ? parseIds(entered("voicesText")) : service.voices || [], defaultModelId: entered("defaultModelId"), defaultVoiceId: kind === "tts" ? entered("defaultVoiceId") : "", enabled: u.checked(form, "enabled"), updatedAt: Date.now(), createdAt: service.createdAt || Date.now() }); }
    function identity(next) { return [next.family, next.endpoint, next.apiStyle, next.region, next.workspaceId, next.resourceEndpoint, next.apiKey, next.accessKeyId, next.sessionToken, next.customHeaders].join("\n"); }
    function listSignature(next) { return [(next.models || []).map(function (item) { return typeof item === "string" ? item : item.id; }).join(","), (next.voices || []).map(function (item) { return typeof item === "string" ? item : item.id; }).join(",")].join("\n"); }
    function validate(next, connection) { var family = familyOf(kind, next), endpoint = app.services.modelServices.computedEndpoint(kind, next), missing = app.services.modelServices.requiredCredentialMessage(family, next); if (missing) throw new Error(missing); if (!endpoint) throw new Error("请填写服务地址或区域"); u.validateEndpoint(endpoint); u.parseHeaders(next.customHeaders); if (!next.name) throw new Error("请填写服务名称"); if (!connection && kind === "tts" && family.id === "elevenlabs" && !app.services.modelServices.voices(next).length) throw new Error("请先连接 ElevenLabs 并获取账户音色"); }
    function syncDefaults(target, reset) {
      if (!defaultModelPicker) return;
      var enabled = app.services.modelServices.allModels(kind, target).filter(function (item) { return selectedIds.indexOf(item.id) >= 0; });
      var requested = reset ? target.defaultModelId || target.model || "" : entered("defaultModelId");
      if (!enabled.some(function (item) { return item.id === requested; })) requested = (enabled[0] || {}).id || "";
      defaultModelPicker.setItems(enabled.map(function (item) { return { id: item.id, name: item.name || item.id }; }), requested);
      var modelField = form.querySelector('[data-default-model-field]'); if (modelField) modelField.classList.toggle("is-hidden", !enabled.length);
      if (!defaultVoicePicker) return;
      var availableVoices = app.services.modelServices.voices(target, entered("defaultModelId"));
      var voice = reset ? target.defaultVoiceId || target.voice || "" : entered("defaultVoiceId");
      if (!availableVoices.some(function (item) { return item.id === voice; })) voice = (availableVoices[0] || {}).id || "";
      defaultVoicePicker.setItems(availableVoices.map(function (item) { return { id: item.id, name: item.name || item.id }; }), voice);
      form.querySelector('[data-default-voice-field]').classList.toggle("is-hidden", !availableVoices.length);
    }
    function paintModels(target) {
      if (kind !== "llm" && kind !== "tts") return;
      var family = familyOf(kind, target), models = app.services.modelServices.allModels(kind, target), panel = form.querySelector("#availableModels"), profile = kind === "llm" ? app.services.modelServices.parameterProfile(kind, target) : null, common = profile ? profile.common.map(parameterLabel).join("、") || "无可安全共用的可调参数" : app.services.modelServices.voices(target).length + " 个音色";
      panel.innerHTML = '<div class="model-family-summary"><strong>模型家族可用配置</strong><span>' + u.escapeHtml((target.apiStyle || family.protocol || family.type || "自动协议") + " · " + common) + '</span></div><div class="model-picker-list">' + (models.length ? models.map(function (model) { var special = profile ? (profile.models.find(function (item) { return item.id === model.id; }) || {}).special || [] : [], caps = kind === "tts" ? app.services.modelServices.ttsCapabilities(target, model.id) : null, detail = kind === "llm" ? capabilityText(target, model) + (special.length ? " · 特别参数：" + special.map(parameterLabel).join("、") : "") : (model.description || "文字转语音") + " · " + (caps.audioStreaming ? (caps.textStreaming ? "流式音频与增量文字" : "流式音频") : caps.reason || "完整音频输出"); return '<label class="switch-row model-toggle"><span class="model-toggle-copy"><strong>' + u.escapeHtml(model.name || model.id) + '</strong><small>' + u.escapeHtml(model.id) + '</small><small class="model-capabilities">' + u.escapeHtml(detail) + '</small><small class="model-evidence">' + u.escapeHtml(capabilitySourceText(model)) + '</small></span><input type="checkbox" data-model-enabled="' + u.escapeHtml(model.id) + '"' + (selectedIds.indexOf(model.id) >= 0 ? ' checked' : '') + '></label>'; }).join("") : '<p class="helper choice-empty">尚未取得模型列表</p>') + '</div>';
      panel.querySelectorAll("[data-model-enabled]").forEach(function (input) { input.addEventListener("change", function () { if (input.checked && selectedIds.indexOf(input.dataset.modelEnabled) < 0) selectedIds.push(input.dataset.modelEnabled); if (!input.checked) selectedIds = selectedIds.filter(function (id) { return id !== input.dataset.modelEnabled; }); syncDefaults(target, false); }); });
      syncDefaults(target, true);
    }
    async function connect() {
      var button = form.querySelector("[data-connect-service]"), status = form.querySelector("#connectionStatus"), draft = readDraft(), previous = selectedIds.slice(); validate(draft, true); button.disabled = true;
      status.textContent = kind === "tts" ? "正在验证凭据、获取模型与音色，并合成短试听…" : "正在验证凭据、读取模型目录并测试默认模型…";
      try {
        var result = await app.services.modelServices.discover(kind, draft, { persist: false }); if (!result.models.length) throw new Error("服务已响应，但没有可用模型候选");
        var ids = result.models.map(function (item) { return item.id; }); selectedIds = editing ? previous.filter(function (id) { return ids.indexOf(id) >= 0; }) : ids.slice(); if (!selectedIds.length) selectedIds = [ids[0]];
        draft.defaultModelId = selectedIds.indexOf(draft.defaultModelId) >= 0 ? draft.defaultModelId : selectedIds[0];
        if (kind === "tts") { var voices = app.services.modelServices.voices(draft, draft.defaultModelId); if (!voices.some(function (item) { return item.id === draft.defaultVoiceId; })) draft.defaultVoiceId = (voices[0] || {}).id || ""; }
        draft.connectionRevision = String(Date.now()); var verified = kind === "llm" ? await app.services.llm.test(draft, draft.defaultModelId) : await app.services.tts.testService(draft);
        if (kind === "tts") app.services.modelServices.recordTtsVerification(draft, verified.modelId, verified.voiceId, true);
        draft.validationState = "verified"; draft.validatedAt = Date.now(); working = draft;
        form.elements.namedItem("modelsText").value = result.models.map(function (item) { return item.id; }).join("\n"); if (kind === "tts") form.elements.namedItem("voicesText").value = result.voices.map(function (item) { return item.id; }).join("\n");
        paintModels(working); connectedIdentity = identity(readDraft());
        status.textContent = "默认组合已验证 · " + result.models.length + " 个模型" + (kind === "tts" ? "、" + result.voices.length + " 个音色" : "") + (result.catalogState === "reviewed-registry" ? " · 使用应用内审核目录" : " · 已读取服务目录") + (result.warnings && result.warnings.length ? "；" + result.warnings.join("；") : "");
      } catch (error) { status.textContent = u.cleanError(error); throw error; } finally { button.disabled = false; }
    }
    function visible(selector, show) { var element = form.querySelector(selector); if (element) element.classList.toggle("is-hidden", !show); }
    function syncFamily(reset) { var family = app.services.modelServices.family(kind, entered("family")), manualCatalog = family.id === "custom" || family.manualCatalog === true; form.querySelector("#familyDescription").textContent = family.description; visible('[data-family-field="accessKeyId"]', family.accessKeyField === true); visible('[data-family-field="sessionToken"]', family.sessionTokenField === true); visible('[data-family-field="region"]', family.regionField === true); visible('[data-family-field="workspaceId"]', family.workspaceField === true); visible('[data-family-field="resourceEndpoint"]', family.resourceEndpointField === true); visible('[data-family-field="apiStyle"]', family.editableProtocol === true); visible('[data-family-field="manualModels"]', manualCatalog); visible('[data-family-field="manualVoices"]', manualCatalog); var label = form.querySelector('[data-credential-label="apiKey"]'); if (label && label.firstChild) label.firstChild.textContent = family.auth === "aws-sigv4" ? "Secret Access Key " : family.auth === "azure" ? "Speech Key " : "API Key "; if (reset) { form.elements.namedItem("name").value = family.name; form.elements.namedItem("endpoint").value = family.endpoint || ""; form.elements.namedItem("modelsText").value = ""; if (form.elements.namedItem("voicesText")) form.elements.namedItem("voicesText").value = ""; form.elements.namedItem("customHeaders").value = ""; ["region", "workspaceId", "resourceEndpoint", "apiKey", "accessKeyId", "sessionToken", "defaultModelId", "defaultVoiceId"].forEach(function (name) { if (form.elements.namedItem(name)) form.elements.namedItem(name).value = ""; }); form.querySelectorAll("[data-saved-headers],[data-clear-custom-headers]").forEach(function (element) { element.classList.add("is-hidden"); }); form.querySelectorAll(".secret-mask").forEach(function (element) { element.textContent = ""; }); if (apiStylePicker) apiStylePicker.setItems(apiStyleItems(), family.apiStyle || "openai-responses"); working = Object.assign({}, readDraft(), { models: [], voices: [], modelsDiscovered: false, voicesDiscovered: false, defaultModelId: "", defaultVoiceId: "" }); selectedIds = app.services.modelServices.allModels(kind, working).map(function (item) { return item.id; }); connectedIdentity = ""; paintModels(working); } }
    form.elements.namedItem("family").addEventListener("change", function () { syncFamily(true); }); var connectButton = form.querySelector("[data-connect-service]"); if (connectButton) connectButton.addEventListener("click", ui.action(connect));
    if (defaultModelPicker) form.elements.namedItem("defaultModelId").addEventListener("change", function () { syncDefaults(working, false); });
    form.querySelectorAll(".secret-editor input").forEach(function (input) { input.addEventListener("focus", function () { input.select(); }, { once: true }); input.addEventListener("paste", function (event) { var pasted = event.clipboardData && event.clipboardData.getData("text"); if (!pasted || !input.value) return; event.preventDefault(); input.value = pasted.trim(); input.dispatchEvent(new Event("input", { bubbles: true })); input.select(); }); input.addEventListener("input", function () { var mask = input.parentNode.querySelector(".secret-mask"); if (mask) mask.textContent = input.value ? u.maskSecret(input.value) : ""; }); });
    form.querySelectorAll("[data-copy-secret]").forEach(function (button) { button.addEventListener("click", ui.action(async function () { var input = form.elements.namedItem(button.dataset.copySecret), value = input && input.value || ""; if (!value) throw new Error("没有可复制的值"); await app.platform.hermit.copyText(value); ui.toast("已复制"); })); }); var savedHeaders = u.maskedHeaderEntries(service.customHeaders); form.querySelectorAll("[data-copy-header]").forEach(function (button) { button.addEventListener("click", ui.action(async function () { var entry = savedHeaders[Number(button.dataset.copyHeader)]; if (!entry) throw new Error("找不到这个 Header"); await app.platform.hermit.copyText(entry.value); ui.toast(entry.name + " 已复制"); })); });
    syncFamily(false); initialIdentity = identity(readDraft()); paintModels(working); return form;
  }

  app.features = app.features || {}; app.features.models = { render: render, renderServices: renderServices, openService: openService };
})(window.chataxi);
