(function (app) {
  "use strict";
  var catalog = app.services.catalog;

  function families(kind) {
    return catalog[kind === "llm" ? "llmFamilies" : kind === "tts" ? "ttsFamilies" : "asrFamilies"];
  }

  function family(kind, id) {
    return families(kind).find(function (item) { return item.id === id; }) || families(kind).find(function (item) { return item.id === "custom"; });
  }

  function uniqueModels(items) {
    var seen = {};
    return (items || []).map(function (item) {
      return typeof item === "string" ? { id: item, name: item } : item;
    }).filter(function (item) {
      if (!item || !item.id || seen[item.id]) return false;
      seen[item.id] = true;
      return true;
    });
  }

  function allModels(kind, service) {
    var definition = family(kind, service && (service.family || service.type));
    var stored = service && service.models || [];
    var legacy = service && service.model ? [{ id: service.model, name: service.model }] : [];
    var source = service && service.modelsDiscovered ? stored.concat(legacy) : stored.concat(definition.models || [], legacy);
    return uniqueModels(source).map(function (item) {
      var known = (definition.models || []).find(function (entry) { return entry.id === item.id; });
      return Object.assign({}, known || {}, item);
    });
  }

  function models(kind, service) {
    var result = allModels(kind, service);
    if (!service || !Array.isArray(service.enabledModelIds)) return result;
    return result.filter(function (item) { return service.enabledModelIds.indexOf(item.id) >= 0; });
  }

  function voices(service, modelId) {
    var definition = family("tts", service && (service.family || service.type));
    var stored = service && service.voices || [];
    var legacy = service && service.voice ? [{ id: service.voice, name: service.voice }] : [];
    var result = uniqueModels(stored.concat((definition.voices || []).map(function (name) { return typeof name === "string" ? { id: name, name: name } : name; }), legacy));
    if (!modelId) return result;
    if (definition.id === "elevenlabs" && /^eleven_v3(?:_|$)/.test(modelId)) return result.filter(function (item) { return !/professional/i.test(item.category || ""); });
    return result.filter(function (item) { return !Array.isArray(item.compatibleModelIds) || !item.compatibleModelIds.length || item.compatibleModelIds.indexOf(modelId) >= 0; });
  }

  function serviceStatus(kind, service) {
    if (!service) return "服务不存在";
    if (service.enabled === false) return "已停用";
    var definition = family(kind, service.family || service.type);
    if (definition.type === "system") return "";
    if (!service.endpoint && !definition.endpoint) return "缺少服务地址";
    if (!definition.keyOptional && !service.apiKey) return "缺少 API Key";
    return "";
  }

  function resolveLlm(service, role) {
    var definition = family("llm", service.family || service.type);
    var modelId = role.model || service.model || (models("llm", service)[0] || {}).id || "";
    var modelInfo = modelDefinition("llm", service, modelId);
    return Object.assign({}, service, {
      family: definition.id,
      apiStyle: service.apiStyle || definition.apiStyle,
      endpoint: service.endpoint || definition.endpoint,
      model: modelId,
      temperature: role.temperature == null ? (service.temperature == null ? "" : service.temperature) : role.temperature,
      maxOutputTokens: Number(role.maxOutputTokens || service.maxOutputTokens || 4096),
      reasoningEffort: role.reasoningEffort || service.reasoningEffort || "",
      allowImageGeneration: Boolean(role.allowImageGeneration),
      streaming: modelInfo.streaming !== false
    });
  }

  function resolveTts(service, role, settings) {
    var definition = family("tts", service.family || service.type);
    var modelId = role && role.ttsModel || service.model || (models("tts", service)[0] || {}).id || "system";
    return Object.assign({}, service, {
      family: definition.id,
      type: service.type || definition.type,
      endpoint: service.endpoint || definition.endpoint,
      streamEndpoint: service.streamEndpoint || definition.streamEndpoint || service.endpoint || definition.endpoint,
      protocol: service.protocol || definition.protocol || service.type || definition.type,
      model: modelId,
      voice: role && role.ttsVoice || service.voice || (voices(service, modelId)[0] || {}).id || "",
      instructions: role && role.voicePrompt || "",
      language: role && role.ttsLanguage || service.language || settings.language || "zh-CN",
      rate: role && role.ttsRate || service.rate || 1,
      pitch: role && role.ttsPitch || service.pitch || 1,
      speechRate: role && role.ttsSpeechRate != null ? Number(role.ttsSpeechRate) : Number(service.speechRate || 0),
      pitchRate: role && role.ttsPitchRate != null ? Number(role.ttsPitchRate) : Number(service.pitchRate || 0),
      loudnessRate: role && role.ttsLoudnessRate != null ? Number(role.ttsLoudnessRate) : Number(service.loudnessRate || 0),
      sampleRate: Number(service.sampleRate || 24000),
      format: service.format || "mp3",
      streaming: modelDefinition("tts", service, modelId).streaming === true
    });
  }

  function resolveAsr(service, conversation, settings) {
    var definition = family("asr", service.family || service.type);
    return Object.assign({}, service, {
      family: definition.id,
      type: service.type || definition.type,
      endpoint: service.endpoint || definition.endpoint,
      model: conversation && conversation.asrModel || service.model || (models("asr", service)[0] || {}).id || "system",
      language: conversation && conversation.asrLanguage || service.language || settings.language || "zh-CN"
    });
  }

  function authHeaders(kind, service) {
    var definition = family(kind, service.family || service.type);
    var key = service.apiKey || "";
    if (definition.id === "anthropic") return key ? { "x-api-key": key, "anthropic-version": "2023-06-01" } : { "anthropic-version": "2023-06-01" };
    if (definition.id === "gemini") return key ? { "x-goog-api-key": key } : {};
    if (definition.id === "elevenlabs") return key ? { "xi-api-key": key } : {};
    if (definition.id === "doubao") return key ? { "X-Api-Key": key } : {};
    return key ? { Authorization: "Bearer " + key } : {};
  }

  function discoveryUrls(kind, service) {
    var definition = family(kind, service && (service.family || service.type));
    if (kind === "tts") return { models: service && service.modelsEndpoint || definition.modelsEndpoint || "", voices: service && service.voicesEndpoint || definition.voicesEndpoint || "" };
    if (definition.modelsEndpoint) return { models: definition.modelsEndpoint, voices: "" };
    if (kind !== "llm" || !service || !service.endpoint) return { models: "", voices: "" };
    try {
      var url = new URL(service.endpoint);
      if (!/\/v\d+(?:beta)?\/(?:responses|chat\/completions|messages)\/?$/i.test(url.pathname)) return { models: "", voices: "" };
      url.pathname = url.pathname.replace(/(?:responses|chat\/completions|messages)\/?$/i, "models"); url.search = ""; url.hash = ""; return { models: url.toString(), voices: "" };
    } catch (_) { return { models: "", voices: "" }; }
  }

  function discoveryUrl(kind, service) { var urls = discoveryUrls(kind, service); return urls.models || urls.voices || ""; }

  function discoveredModel(item, definition) {
    var id = String(item.id || item.baseModelId || item.name || "").replace(/^models\//, "");
    var parameters = item.supported_parameters || item.supportedParameters || (item.capabilities && item.capabilities.parameters) || [];
    var next = { id: id, name: item.displayName || item.display_name || id, supportedParameters: Array.isArray(parameters) ? parameters.map(String) : [] };
    if (Array.isArray(parameters) && parameters.length) {
      next.temperature = parameters.indexOf("temperature") >= 0;
      next.imageInput = parameters.some(function (value) { return /image.*input|vision/i.test(value); });
      next.imageGeneration = parameters.some(function (value) { return /image.*generation/i.test(value); });
    }
    var inputModalities = item.input_modalities || item.inputModalities;
    var outputModalities = item.output_modalities || item.outputModalities;
    if (Array.isArray(inputModalities)) next.imageInput = inputModalities.some(function (value) { return String(value).toLowerCase() === "image"; });
    if (Array.isArray(outputModalities)) next.imageGeneration = outputModalities.some(function (value) { return String(value).toLowerCase() === "image"; });
    var contextLength = Number(item.context_length || item.contextLength || 0); if (contextLength > 0) next.contextLength = contextLength;
    var max = Number(item.max_output_tokens || item.maxOutputTokens || 0); if (max > 0) next.maxOutputTokens = max;
    var efforts = item.reasoning_efforts || item.reasoningEfforts; if (Array.isArray(efforts)) next.reasoning = efforts.map(String);
    var known = (definition.models || []).find(function (entry) { return entry.id === id; });
    return Object.assign({ streaming: definition.streaming !== false }, known || {}, next);
  }

  function discoveredTtsModel(item, definition) {
    var id = String(item.model_id || item.id || "");
    var known = (definition.models || []).find(function (entry) { return entry.id === id; });
    return Object.assign({ streaming: definition.streaming === true }, known || {}, {
      id: id,
      name: item.name || id,
      description: item.description || "",
      streaming: item.streaming == null ? definition.streaming === true : Boolean(item.streaming),
      maxCharacters: Number(item.maximum_text_length_per_request || item.max_characters_request_subscribed_user || item.max_characters_request_free_user || 0),
      languages: (item.languages || []).map(function (language) { return language.language_id || language.id || language.name; }).filter(Boolean),
      voiceStyle: Boolean(item.can_use_style),
      speakerBoost: Boolean(item.can_use_speaker_boost)
    });
  }

  async function discoverVoices(url, headers) {
    var output = [], nextUrl = url, page = 0;
    while (nextUrl && page < 20) {
      var result = await app.platform.network.requestJson({ url: nextUrl, method: "GET", headers: headers, timeoutMs: 45000 });
      var data = result.data || {}, items = data.voices || data.data || [];
      output = output.concat(items.map(function (item) {
        var modelIds = (item.high_quality_base_model_ids || []).slice();
        (item.verified_languages || []).forEach(function (entry) { if (entry.model_id && modelIds.indexOf(entry.model_id) < 0) modelIds.push(entry.model_id); });
        return { id: item.voice_id || item.id, name: item.name || item.voice_id || item.id, category: item.category || "", compatibleModelIds: modelIds };
      }));
      if (!data.has_more || !data.next_page_token) break;
      var parsed = new URL(url); parsed.searchParams.set("page_size", "100"); parsed.searchParams.set("next_page_token", data.next_page_token); nextUrl = parsed.toString(); page += 1;
    }
    return uniqueModels(output);
  }

  function settle(promise) {
    return Promise.resolve(promise).then(function (value) { return { status: "fulfilled", value: value }; }, function (reason) { return { status: "rejected", reason: reason }; });
  }

  async function discover(kind, service, options) {
    var definition = family(kind, service.family || service.type);
    var urls = discoveryUrls(kind, service), authorization = authHeaders(kind, service);
    if (!urls.models && !urls.voices) return { models: allModels(kind, service), voices: voices(service), discovered: false };
    if (kind === "tts") {
      var discoveredModels = urls.models ? app.platform.network.requestJson({ url: urls.models, method: "GET", headers: authorization, timeoutMs: 45000 }) : Promise.resolve(null);
      var discoveredVoices = urls.voices ? discoverVoices(urls.voices, authorization) : Promise.resolve(null);
      var results = await Promise.all([settle(discoveredModels), settle(discoveredVoices)]), warnings = [], succeeded = 0;
      if (results[0].status === "fulfilled" && results[0].value) {
        succeeded += 1;
        var rawModels = Array.isArray(results[0].value.data) ? results[0].value.data : results[0].value.data.models || results[0].value.data.data || [];
        service.models = uniqueModels(rawModels.filter(function (item) { return item.can_do_text_to_speech !== false; }).map(function (item) { return discoveredTtsModel(item, definition); }).filter(function (item) { return item.id; }));
        service.modelsDiscovered = true;
      } else if (results[0].status === "rejected") {
        service.models = [];
        service.modelsDiscovered = false;
        if ((definition.models || []).length) warnings.push(definition.id === "elevenlabs" && results[0].reason && results[0].reason.status === 401 ? "密钥未开放模型目录权限，已使用内置 ElevenLabs 模型目录" : "模型目录暂时不可读，已使用内置模型目录");
        else warnings.push("模型目录读取失败");
      }
      if (results[1].status === "fulfilled" && results[1].value) { succeeded += 1; service.voices = results[1].value; service.voicesDiscovered = true; }
      else if (results[1].status === "rejected") warnings.push("账户音色目录读取失败");
      if (!succeeded) throw results[1].status === "rejected" ? results[1].reason : results[0].reason;
      if (urls.voices && results[1].status === "rejected" && !voices(service).length) throw results[1].reason;
      service.discoveryWarnings = warnings;
    } else {
      var result = await app.platform.network.requestJson({ url: urls.models, method: "GET", headers: authorization, timeoutMs: 45000 });
      var raw = Array.isArray(result.data) ? result.data : result.data.data || result.data.models || result.data.items || [];
      var discovered = raw.filter(function (item) {
        if (definition.id === "gemini") return !item.supportedGenerationMethods || item.supportedGenerationMethods.indexOf("generateContent") >= 0;
        return true;
      }).map(function (item) { return discoveredModel(item, definition); }).filter(function (item) { return item.id; });
      service.models = uniqueModels(discovered);
      service.modelsDiscovered = true;
    }
    service.discoveredAt = Date.now();
    if (!options || options.persist !== false) await app.data.store.put(kind + "-profiles", service.id, service);
    return { models: allModels(kind, service), voices: voices(service), discovered: true, warnings: service.discoveryWarnings || [] };
  }

  function modelDefinition(kind, service, modelId) {
    var definition = family(kind, service && (service.family || service.type));
    var listed = allModels(kind, service).find(function (item) { return item.id === modelId; });
    var known = (definition.models || []).find(function (item) { return item.id === modelId; });
    return Object.assign({ id: modelId, name: modelId, maxOutputTokens: 8192, temperature: false, reasoning: [], imageInput: false, imageGeneration: false, voicePrompt: false, speechRate: false, pitchRate: false, loudnessRate: false, supportedParameters: [], streaming: definition.streaming === true }, known || {}, listed || {});
  }

  function ttsCapabilities(service, modelId) {
    if (!service || service.enabled === false) return { streaming: false, reason: "朗读服务不可用" };
    var selected = modelId || service.model || (models("tts", service)[0] || {}).id || "";
    var definition = modelDefinition("tts", service, selected);
    return { streaming: definition.streaming === true, modelId: selected, reason: definition.streaming === true ? "" : "所选朗读模型不支持流式播放" };
  }

  function parameterProfile(kind, service) {
    var list = allModels(kind, service).map(function (item) { return modelDefinition(kind, service, item.id); });
    var names = list.map(function (item) {
      var result = (item.supportedParameters || []).slice();
      if (item.temperature !== false && result.indexOf("temperature") < 0) result.push("temperature");
      if (item.maxOutputTokens && result.indexOf("max_output_tokens") < 0) result.push("max_output_tokens");
      if ((item.reasoning || []).length && result.indexOf("reasoning_effort") < 0) result.push("reasoning_effort");
      if (item.imageInput && result.indexOf("image_input") < 0) result.push("image_input");
      if (item.imageGeneration && result.indexOf("image_generation") < 0) result.push("image_generation");
      return result;
    });
    var common = names.length ? names[0].filter(function (name) { return names.every(function (values) { return values.indexOf(name) >= 0; }); }) : [];
    return { common: common, models: list.map(function (item, index) { return { id: item.id, parameters: names[index], special: names[index].filter(function (name) { return common.indexOf(name) < 0; }) }; }) };
  }

  app.services.modelServices = {
    families: families,
    family: family,
    allModels: allModels,
    models: models,
    voices: voices,
    serviceStatus: serviceStatus,
    resolveLlm: resolveLlm,
    resolveTts: resolveTts,
    resolveAsr: resolveAsr,
    discoveryUrl: discoveryUrl,
    discoveryUrls: discoveryUrls,
    discover: discover,
    modelDefinition: modelDefinition,
    parameterProfile: parameterProfile,
    ttsCapabilities: ttsCapabilities
  };
})(window.chataxi);
