(function (global) {
  "use strict";
  global.chataxi = global.chataxi || {};
  global.chataxi.version = "0.6.0";
  global.chataxi.state = { route: "conversations", activeConversationId: null, modelsTab: "llm" };
})(window);
