(function (app) {
  "use strict";
  var databasePromise = null;
  var memory = {};

  function database() {
    if (!window.indexedDB) return Promise.resolve(null);
    if (databasePromise) return databasePromise;
    databasePromise = new Promise(function (resolve, reject) {
      var request = indexedDB.open("chataxi-media-v1", 1);
      request.onupgradeneeded = function () {
        if (!request.result.objectStoreNames.contains("media")) request.result.createObjectStore("media", { keyPath: "id" });
      };
      request.onsuccess = function () { resolve(request.result); };
      request.onerror = function () { reject(request.error || new Error("媒体数据库不可用")); };
    });
    return databasePromise;
  }

  async function put(blob, metadata) {
    var record = {
      id: (metadata && metadata.id) || app.utils.id("media"),
      blob: blob,
      mime: blob.type || (metadata && metadata.mime) || "application/octet-stream",
      name: (metadata && metadata.name) || "media",
      createdAt: Date.now()
    };
    var db = await database();
    if (!db) { memory[record.id] = record; return record; }
    await new Promise(function (resolve, reject) {
      var request = db.transaction("media", "readwrite").objectStore("media").put(record);
      request.onsuccess = function () { resolve(); };
      request.onerror = function () { reject(request.error); };
    });
    return record;
  }

  async function get(id) {
    var db = await database();
    if (!db) return memory[id] || null;
    return new Promise(function (resolve, reject) {
      var request = db.transaction("media", "readonly").objectStore("media").get(id);
      request.onsuccess = function () { resolve(request.result || null); };
      request.onerror = function () { reject(request.error); };
    });
  }

  async function remove(id) {
    var db = await database();
    if (!db) { delete memory[id]; return; }
    await new Promise(function (resolve, reject) {
      var request = db.transaction("media", "readwrite").objectStore("media").delete(id);
      request.onsuccess = function () { resolve(); };
      request.onerror = function () { reject(request.error); };
    });
  }

  async function toDataUrl(id) {
    var record = await get(id);
    return record ? app.utils.blobToDataUrl(record.blob) : null;
  }

  app.data.media = { put: put, get: get, remove: remove, toDataUrl: toDataUrl };
})(window.chataxi);
