(function (app) {
  "use strict";
  var backend = "local";
  var prefix = "chataxi.v1.";
  var collections = ["meta", "llm-profiles", "tts-profiles", "asr-profiles", "roles", "conversations", "messages"];

  function localKey(collection, key) { return prefix + collection + "." + key; }

  var localBackend = {
    get: async function (collection, key) {
      var raw = localStorage.getItem(localKey(collection, key));
      return raw == null ? null : { collection: collection, key: key, value: app.utils.safeJsonParse(raw, null), revision: "local" };
    },
    put: async function (collection, key, value) {
      localStorage.setItem(localKey(collection, key), JSON.stringify(value));
      return { collection: collection, key: key, revision: "local" };
    },
    delete: async function (collection, key) {
      var existed = localStorage.getItem(localKey(collection, key)) != null;
      localStorage.removeItem(localKey(collection, key));
      return { deleted: existed };
    },
    scan: async function (collection, keyPrefix) {
      var items = [];
      var start = localKey(collection, keyPrefix || "");
      for (var index = 0; index < localStorage.length; index += 1) {
        var key = localStorage.key(index);
        if (key && key.indexOf(start) === 0) {
          var entityKey = key.slice(localKey(collection, "").length);
          items.push({ collection: collection, key: entityKey, value: app.utils.safeJsonParse(localStorage.getItem(key), null), revision: "local" });
        }
      }
      items.sort(function (left, right) { return left.key.localeCompare(right.key); });
      return { items: items, nextAfterKey: null };
    }
  };

  var hermitBackend = {
    get: async function (collection, key) { return app.platform.hermit.api().data.get({ collection: collection, key: key }); },
    put: async function (collection, key, value) { return app.platform.hermit.api().data.put({ collection: collection, key: key, value: value }); },
    delete: async function (collection, key) { return app.platform.hermit.api().data.delete({ collection: collection, key: key }); },
    scan: async function (collection, keyPrefix) {
      var all = [];
      var afterKey = null;
      do {
        var page = await app.platform.hermit.api().data.scan({ collection: collection, prefix: keyPrefix || "", afterKey: afterKey || undefined, limit: 100 });
        all = all.concat(page.items || []);
        afterKey = page.nextAfterKey;
      } while (afterKey);
      return { items: all, nextAfterKey: null };
    }
  };

  function api() { return backend === "hermit" ? hermitBackend : localBackend; }

  async function init() {
    backend = (await app.platform.hermit.awaitReady(3500)) ? "hermit" : "local";
    await seed();
    return backend;
  }

  async function seed() {
    var settings = await get("meta", "settings");
    if (!settings) {
      await put("meta", "settings", {
        autoSpeak: true,
        defaultTtsProfileId: "system-tts",
        defaultAsrProfileId: "system-asr",
        language: "zh-CN",
        imageDetail: "auto",
        historyLimit: 40,
        theme: "system"
      });
    }
    if (!(await get("tts-profiles", "system-tts"))) {
      await put("tts-profiles", "system-tts", { id: "system-tts", name: "Android 系统朗读", type: "system", enabled: true, voice: "", rate: 1, pitch: 1 });
    }
    if (!(await get("asr-profiles", "system-asr"))) {
      await put("asr-profiles", "system-asr", { id: "system-asr", name: "Android 系统语音识别", type: "system", enabled: true, language: "zh-CN", onDevice: false });
    }
    if (!(await get("meta", "schema"))) await put("meta", "schema", { version: 1, createdAt: Date.now() });
  }

  async function get(collection, key) {
    var result = await api().get(collection, key);
    return result ? result.value : null;
  }

  async function put(collection, key, value) {
    if (collections.indexOf(collection) < 0) throw new Error("未知数据集合：" + collection);
    await api().put(collection, key, value);
    app.events.emit("data:changed", { collection: collection, key: key });
    return value;
  }

  async function remove(collection, key) {
    var result = await api().delete(collection, key);
    app.events.emit("data:changed", { collection: collection, key: key });
    return result.deleted;
  }

  async function list(collection, keyPrefix) {
    var result = await api().scan(collection, keyPrefix || "");
    return (result.items || []).map(function (item) { return item.value; }).filter(Boolean);
  }

  async function messages(conversationId) {
    var listItems = await list("messages", conversationId + ":");
    return listItems.sort(function (left, right) { return left.createdAt - right.createdAt; });
  }

  async function putMessage(message) {
    var key = message.conversationId + ":" + String(message.createdAt).padStart(15, "0") + ":" + message.id;
    return put("messages", key, message);
  }

  async function deleteConversation(conversationId) {
    var records = await api().scan("messages", conversationId + ":");
    for (var index = 0; index < records.items.length; index += 1) await api().delete("messages", records.items[index].key);
    await remove("conversations", conversationId);
  }

  app.data = app.data || {};
  app.data.store = {
    init: init,
    backend: function () { return backend; },
    get: get,
    put: put,
    remove: remove,
    list: list,
    messages: messages,
    putMessage: putMessage,
    deleteConversation: deleteConversation
  };
})(window.chataxi);
