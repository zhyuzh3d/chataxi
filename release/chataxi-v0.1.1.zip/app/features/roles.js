(function (app) {
  "use strict";
  var utils = app.utils;
  var ui = app.components;

  async function render() {
    var roles = (await app.data.store.list("roles")).sort(function (a, b) { return a.name.localeCompare(b.name, "zh-CN"); });
    var profiles = await app.data.store.list("llm-profiles");
    var profileMap = {};
    profiles.forEach(function (profile) { profileMap[profile.id] = profile; });
    var main = document.getElementById("mainContent");
    main.className = "main";
    document.getElementById("pageTitle").textContent = "角色";
    document.getElementById("pageSubtitle").textContent = roles.length ? roles.length + " 位 AI 角色" : "创建你的第一位 AI 角色";
    document.getElementById("topbarActions").innerHTML = '<button class="icon-button" type="button" data-add-role aria-label="添加角色">' + ui.icon("plus") + '</button>';
    main.innerHTML = '<section class="page"><div class="page-intro">角色决定名字、提示词和使用的模型连接。</div>' + (roles.length ? '<div class="list">' + roles.map(function (role) {
      var profile = profileMap[role.llmProfileId];
      return '<article class="card list-item">' + ui.avatar(role.name, role.avatarColor) + '<button class="card-button list-copy grow" type="button" data-edit-role="' + role.id + '"><strong>' + utils.escapeHtml(role.name) + '</strong><span>' + utils.escapeHtml(role.description || (profile ? profile.name + " · " + profile.model : "模型配置不可用")) + '</span></button><span class="badge">' + (role.enabled === false ? "停用" : "启用") + '</span><button class="icon-button danger-text" type="button" data-delete-role="' + role.id + '" aria-label="删除角色">' + ui.icon("trash") + '</button></article>';
    }).join("") + '</div>' : ui.empty("masks-theater", "还没有角色", profiles.length ? "创建角色并绑定一个模型连接。" : "先到设置里添加 LLM，再回来创建角色。", '<button class="button primary" type="button" data-add-role>' + ui.icon("plus") + '创建角色</button>')) + '</section>';
    document.querySelectorAll("[data-add-role]").forEach(function (button) { button.addEventListener("click", function () { openEditor(null); }); });
    main.querySelectorAll("[data-edit-role]").forEach(function (button) { button.addEventListener("click", async function () { openEditor(await app.data.store.get("roles", button.dataset.editRole)); }); });
    main.querySelectorAll("[data-delete-role]").forEach(function (button) { button.addEventListener("click", function () { removeRole(button.dataset.deleteRole); }); });
  }

  async function openEditor(role) {
    var llmProfiles = (await app.data.store.list("llm-profiles")).filter(function (item) { return item.enabled; });
    if (!llmProfiles.length) { ui.toast("请先在设置中添加并启用一个 LLM 配置", 4200); app.navigate("settings", { settingsTab: "llm" }); return; }
    var ttsProfiles = (await app.data.store.list("tts-profiles")).filter(function (item) { return item.enabled; });
    var editing = Boolean(role);
    role = role || { id: utils.id("role"), name: "", description: "", systemPrompt: "", llmProfileId: llmProfiles[0].id, ttsProfileId: "", avatarColor: "#805ad5", enabled: true };
    ui.openModal({
      title: editing ? "编辑角色" : "创建角色",
      html: '<div class="form-grid"><label class="field"><span>角色名称</span><input name="name" required maxlength="40" value="' + utils.escapeHtml(role.name) + '" placeholder="例如：小岚"></label><label class="field"><span>一句话介绍</span><input name="description" maxlength="100" value="' + utils.escapeHtml(role.description || "") + '" placeholder="例如：耐心的旅行规划师"></label><label class="field"><span>系统提示词</span><textarea name="systemPrompt" maxlength="12000" required placeholder="明确角色身份、目标、语气和边界。">' + utils.escapeHtml(role.systemPrompt || "") + '</textarea></label><label class="field"><span>LLM 连接</span><select name="llmProfileId">' + llmProfiles.map(function (item) { return '<option value="' + item.id + '"' + (item.id === role.llmProfileId ? " selected" : "") + '>' + utils.escapeHtml(item.name + " · " + item.model) + '</option>'; }).join("") + '</select></label><label class="field"><span>朗读配置</span><select name="ttsProfileId"><option value="">使用通用默认</option>' + ttsProfiles.map(function (item) { return '<option value="' + item.id + '"' + (item.id === role.ttsProfileId ? " selected" : "") + '>' + utils.escapeHtml(item.name) + '</option>'; }).join("") + '</select></label><label class="field"><span>头像颜色</span><input class="role-color-input" name="avatarColor" type="color" value="' + utils.escapeHtml(role.avatarColor || "#805ad5") + '"></label><label class="switch-row"><span>启用角色</span><input name="enabled" type="checkbox"' + (role.enabled !== false ? " checked" : "") + '></label></div>',
      submitText: editing ? "保存" : "创建",
      onSubmit: async function (form) {
        var next = {
          id: role.id,
          name: utils.formValue(form, "name"),
          description: utils.formValue(form, "description"),
          systemPrompt: utils.formValue(form, "systemPrompt"),
          llmProfileId: utils.formValue(form, "llmProfileId"),
          ttsProfileId: utils.formValue(form, "ttsProfileId"),
          avatarColor: utils.formValue(form, "avatarColor") || "#805ad5",
          enabled: utils.checked(form, "enabled"),
          createdAt: role.createdAt || Date.now(),
          updatedAt: Date.now()
        };
        await app.data.store.put("roles", next.id, next);
        ui.toast(editing ? "角色已更新" : "角色已创建");
        await render();
      }
    });
  }

  async function removeRole(id) {
    var conversations = await app.data.store.list("conversations");
    var used = conversations.find(function (conversation) { return (conversation.roleIds || []).indexOf(id) >= 0; });
    if (used) { ui.toast("角色仍在对话“" + used.title + "”中，不能删除", 4500); return; }
    if (await ui.confirm({ title: "删除角色", message: "角色提示词和绑定关系将从本机删除。", confirmText: "删除", danger: true })) {
      await app.data.store.remove("roles", id); await render();
    }
  }

  app.features = app.features || {};
  app.features.roles = { render: render, openEditor: openEditor };
})(window.chataxi);
