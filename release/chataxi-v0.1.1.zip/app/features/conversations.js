(function (app) {
  "use strict";
  var utils = app.utils;
  var ui = app.components;

  async function render() {
    var conversations = (await app.data.store.list("conversations")).sort(function (a, b) { return b.updatedAt - a.updatedAt; });
    var roles = await app.data.store.list("roles");
    var llms = await app.data.store.list("llm-profiles");
    var roleMap = {};
    roles.forEach(function (role) { roleMap[role.id] = role; });
    var main = document.getElementById("mainContent");
    main.className = "main";
    document.getElementById("pageTitle").textContent = "chataxi";
    document.getElementById("pageSubtitle").textContent = conversations.length ? conversations.length + " 个对话" : "你的 AI 角色车队";
    document.getElementById("topbarActions").innerHTML = '<button class="icon-button" type="button" data-add-conversation aria-label="创建对话">' + ui.icon("pen-to-square") + '</button>';
    if (!conversations.length) {
      var steps = [
        { done: llms.length > 0, icon: "server", text: "添加 LLM 连接", route: "settings" },
        { done: roles.length > 0, icon: "user-plus", text: "创建 AI 角色", route: "roles" },
        { done: false, icon: "comments", text: "开始第一次对话", route: "create" }
      ];
      main.innerHTML = '<section class="page">' + ui.empty("taxi", "准备发车", "完成三个小步骤，建立只属于你的 AI 对话空间。", '<div class="setup-steps">' + steps.map(function (step) { return '<button class="setup-step card-button ' + (step.done ? "done" : "") + '" type="button" data-setup-route="' + step.route + '">' + ui.icon(step.done ? "circle-check" : step.icon) + '<span>' + utils.escapeHtml(step.text) + '</span></button>'; }).join("") + '</div>') + '</section>';
      main.querySelectorAll("[data-setup-route]").forEach(function (button) { button.addEventListener("click", function () { if (button.dataset.setupRoute === "create") openEditor(); else app.navigate(button.dataset.setupRoute, button.dataset.setupRoute === "settings" ? { settingsTab: "llm" } : {}); }); });
    } else {
      main.innerHTML = '<section class="page"><div class="page-intro">单聊专注交流，群聊让多位角色依次回应。</div><div class="list">' + conversations.map(function (conversation) {
        var participants = (conversation.roleIds || []).map(function (id) { return roleMap[id] ? roleMap[id].name : "已删除角色"; });
        return '<article class="card list-item conversation-card"><button class="card-button list-copy grow" type="button" data-open-conversation="' + conversation.id + '"><strong>' + utils.escapeHtml(conversation.title) + '</strong><span>' + utils.escapeHtml(conversation.lastMessage || "还没有消息") + '</span><div class="meta"><span class="badge">' + (conversation.kind === "group" ? "群聊" : "单聊") + '</span><span class="badge">' + utils.escapeHtml(participants.join("、")) + '</span></div></button><time>' + utils.escapeHtml(utils.formatTime(conversation.updatedAt)) + '</time></article>';
      }).join("") + '</div></section>';
      main.querySelectorAll("[data-open-conversation]").forEach(function (button) { button.addEventListener("click", function () { app.openChat(button.dataset.openConversation); }); });
    }
    document.querySelectorAll("[data-add-conversation]").forEach(function (button) { button.addEventListener("click", openEditor); });
  }

  async function openEditor() {
    var roles = (await app.data.store.list("roles")).filter(function (role) { return role.enabled !== false; });
    var llms = await app.data.store.list("llm-profiles");
    var enabled = {};
    llms.forEach(function (profile) { if (profile.enabled) enabled[profile.id] = true; });
    roles = roles.filter(function (role) { return enabled[role.llmProfileId]; });
    if (!roles.length) { ui.toast("请先创建至少一个绑定可用 LLM 的角色", 4300); app.navigate("roles"); return; }
    var form = ui.openModal({
      title: "创建对话",
      submitText: "开始对话",
      html: '<div class="form-grid"><label class="field"><span>对话标题</span><input name="title" required maxlength="80" placeholder="例如：周末旅行讨论"></label><fieldset class="field"><span class="field-label">对话类型</span><div class="chip-row"><label class="chip"><input name="kind" type="radio" value="single" checked> 单聊</label><label class="chip"><input name="kind" type="radio" value="group"> 群聊</label></div></fieldset><fieldset class="field"><span class="field-label">选择角色</span><div class="stack">' + roles.map(function (role) { return '<label class="switch-row card card-body">' + ui.avatar(role.name, role.avatarColor) + '<span class="grow"><strong>' + utils.escapeHtml(role.name) + '</strong><small class="muted">' + utils.escapeHtml(role.description || "AI 角色") + '</small></span><input name="roleIds" type="checkbox" value="' + role.id + '"></label>'; }).join("") + '</div></fieldset><div class="inline-status">' + ui.icon("circle-info") + '<span>群聊每次最多让选中角色各回复一次，不会无限互聊。</span></div></div>',
      onSubmit: async function (target) {
        var kind = target.querySelector('[name="kind"]:checked').value;
        var roleIds = Array.prototype.map.call(target.querySelectorAll('[name="roleIds"]:checked'), function (item) { return item.value; });
        if (kind === "single" && roleIds.length !== 1) throw new Error("单聊需要且只能选择一个角色");
        if (kind === "group" && roleIds.length < 2) throw new Error("群聊至少需要两个角色");
        var conversation = { id: utils.id("conversation"), title: utils.formValue(target, "title"), kind: kind, roleIds: roleIds, activeRoleIds: roleIds.slice(), createdAt: Date.now(), updatedAt: Date.now(), lastMessage: "" };
        await app.data.store.put("conversations", conversation.id, conversation);
        ui.toast("对话已创建");
        setTimeout(function () { app.openChat(conversation.id); }, 0);
      }
    });
    var checkboxes = form.querySelectorAll('[name="roleIds"]');
    var syncKind = function () {
      var kind = form.querySelector('[name="kind"]:checked').value;
      if (kind === "single") {
        var selected = form.querySelectorAll('[name="roleIds"]:checked');
        if (selected.length > 1) Array.prototype.slice.call(selected, 1).forEach(function (item) { item.checked = false; });
      }
    };
    checkboxes.forEach(function (box) { box.addEventListener("change", function () { if (form.querySelector('[name="kind"]:checked').value === "single" && box.checked) checkboxes.forEach(function (item) { if (item !== box) item.checked = false; }); }); });
    form.querySelectorAll('[name="kind"]').forEach(function (radio) { radio.addEventListener("change", syncKind); });
  }

  app.features = app.features || {};
  app.features.conversations = { render: render, openEditor: openEditor };
})(window.chataxi);
