(function (app) {
  "use strict";
  var ui = app.components;

  function setNav(route) {
    document.querySelectorAll("#bottomNav [data-route]").forEach(function (button) {
      if (button.dataset.route === route) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
  }

  async function resetShell() {
    if (app.state.activeConversationId) await app.features.chat.close();
    document.getElementById("appShell").classList.remove("chat-open");
    document.getElementById("bottomNav").classList.remove("is-hidden");
    document.getElementById("backButton").classList.add("is-hidden");
    document.getElementById("brandBlock").querySelector(".brand-mark").classList.remove("is-hidden");
  }

  async function navigate(route, options) {
    options = options || {};
    await resetShell();
    if (options.settingsTab) app.state.settingsTab = options.settingsTab;
    app.state.previousRoute = app.state.route;
    app.state.route = route;
    setNav(route);
    if (location.hash !== "#/" + route) history.replaceState(null, "", "#/" + route);
    try {
      if (route === "roles") await app.features.roles.render();
      else if (route === "settings") await app.features.settings.render();
      else await app.features.conversations.render();
      document.getElementById("mainContent").focus({ preventScroll: true });
    } catch (error) {
      document.getElementById("mainContent").innerHTML = ui.empty("triangle-exclamation", "页面加载失败", app.utils.cleanError(error), '<button class="button primary" type="button" onclick="location.reload()">重新加载</button>');
    }
  }

  async function openChat(id) {
    app.state.previousRoute = "conversations";
    app.state.route = "chat";
    history.replaceState(null, "", "#/chat/" + encodeURIComponent(id));
    try { await app.features.chat.render(id); }
    catch (error) { ui.toast(app.utils.cleanError(error), 5000); await navigate("conversations"); }
  }

  async function closeChat() {
    await app.features.chat.close();
    await navigate("conversations");
  }

  async function init() {
    document.querySelectorAll("#bottomNav [data-route]").forEach(function (button) { button.addEventListener("click", function () { navigate(button.dataset.route); }); });
    document.getElementById("backButton").addEventListener("click", closeChat);
    window.addEventListener("hashchange", routeFromHash);
    try {
      await app.data.store.init();
      var hash = location.hash || "#/conversations";
      if (hash.indexOf("#/chat/") === 0) await openChat(decodeURIComponent(hash.slice(7)));
      else await navigate(["conversations", "roles", "settings"].indexOf(hash.slice(2)) >= 0 ? hash.slice(2) : "conversations");
      if (app.platform.hermit.available()) {
        try { await app.platform.hermit.api().app.ready(); } catch (_) {}
      } else ui.toast("当前为浏览器预览，系统语音和 Hermit 数据能力不可用", 4300);
    } catch (error) {
      document.getElementById("mainContent").innerHTML = ui.empty("triangle-exclamation", "chataxi 启动失败", app.utils.cleanError(error), '<button class="button primary" type="button" onclick="location.reload()">重试</button>');
    }
  }

  function routeFromHash() {
    var hash = location.hash || "#/conversations";
    if (hash.indexOf("#/chat/") === 0) openChat(decodeURIComponent(hash.slice(7)));
    else navigate(["conversations", "roles", "settings"].indexOf(hash.slice(2)) >= 0 ? hash.slice(2) : "conversations");
  }

  app.navigate = navigate;
  app.openChat = openChat;
  app.closeChat = closeChat;
  document.addEventListener("DOMContentLoaded", init);
})(window.chataxi);
