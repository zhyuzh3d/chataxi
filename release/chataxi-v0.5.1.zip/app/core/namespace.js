(function (global) {
  "use strict";
  global.chataxi = global.chataxi || {};
  global.chataxi.version = "0.5.1";
  global.chataxi.state = { route: "conversations", activeConversationId: null, modelsTab: "llm" };
})(window);
