(function (app) {
  "use strict";

  async function hydrateMessages(messages, settings) {
    var lastUserIndex = -1;
    for (var index = messages.length - 1; index >= 0; index -= 1) {
      if (messages[index].kind === "user") { lastUserIndex = index; break; }
    }
    var hydrated = [];
    messages.forEach(function (message, index) {
      hydrated.push({
        role: message.kind === "assistant" ? "assistant" : "user",
        roleName: message.roleName || "",
        text: message.text || "",
        images: []
      });
    });
    if (lastUserIndex >= 0) {
      var sourceImages = messages[lastUserIndex].media || [];
      for (var mediaIndex = 0; mediaIndex < sourceImages.length; mediaIndex += 1) {
        var media = sourceImages[mediaIndex];
        var dataUrl = media.dataUrl || (media.mediaId ? await app.data.media.toDataUrl(media.mediaId) : null);
        if (!dataUrl) throw new Error("这条消息的图片已不可用，请重新选择图片发送");
        if (dataUrl) hydrated[lastUserIndex].images.push({ dataUrl: dataUrl, detail: settings.imageDetail || "auto" });
      }
    }
    return hydrated;
  }

  function truncate(messages, limit) {
    var selected = messages.slice(-Math.min(50, Math.max(5, Number(limit || 10))));
    var remaining = 48000, output = [];
    for (var index = selected.length - 1; index >= 0 && remaining > 0; index -= 1) {
      var message = selected[index], text = String(message.text || "");
      if (text.length > remaining) {
        message = Object.assign({}, message, { text: text.slice(-remaining), contextTruncated: true });
        output.unshift(message); break;
      }
      remaining -= text.length; output.unshift(message);
    }
    return output;
  }

  function removeRoleEcho(text, roleName) {
    var value = String(text || "").trim();
    var prefix = "[" + String(roleName || "").trim() + "]";
    if (prefix !== "[]" && value.indexOf(prefix) === 0) value = value.slice(prefix.length).trim();
    return value;
  }

  function partialText(text, roleName) {
    var value = String(text || ""), prefix = "[" + String(roleName || "").trim() + "]";
    var leading = value.replace(/^\s+/, "");
    if (prefix !== "[]" && prefix.indexOf(leading) === 0 && leading.length < prefix.length) return "";
    if (prefix !== "[]" && leading.indexOf(prefix) === 0) return leading.slice(prefix.length).replace(/^\s+/, "");
    return value;
  }

  function appendImages(target, additions) {
    (additions || []).forEach(function (item) {
      if (item && item.dataUrl && !target.some(function (existing) { return existing.dataUrl === item.dataUrl; })) target.push(item);
    });
  }

  async function stream(profile, request, task, role) {
    var text = "", images = [], usage = null, emitted = false;
    if (!app.platform.network.requestSse) { var absent = new Error("当前运行环境没有流式网络接口"); absent.streamUnavailable = true; throw absent; }
    await app.platform.network.requestSse({
      url: request.url,
      method: "POST",
      headers: request.headers,
      bodyText: JSON.stringify(request.body),
      contentType: "application/json",
      timeoutMs: 120000,
      task: task,
      onEvent: async function (event) {
        var update = app.services.providers.parseStreamEvent(profile, event);
        if (update.delta) {
          text += update.delta; emitted = true;
          if (task && task.onDelta) task.onDelta({ delta: update.delta, text: partialText(text, role.name) });
        }
        if (update.usage) usage = update.usage;
        appendImages(images, update.images);
      }
    });
    if (!text.trim() && !images.length) throw new Error(emitted ? "模型流没有返回可显示内容" : "模型服务结束了流式连接，但没有返回内容");
    return { text: text, images: images, usage: usage, rawId: null, streamed: true };
  }

  async function complete(role, messages, task, conversation, participantRoles, userProfile) {
    var service = await app.data.store.get("llm-profiles", role.llmProfileId);
    if (!service || service.enabled === false) throw new Error("角色绑定的模型服务不存在或已停用");
    var profile = app.services.modelServices.resolveLlm(service, role);
    if (!profile.model) throw new Error("角色没有选择具体模型");
    var settings = await app.data.store.get("meta", "settings");
    var context = conversation
      ? await app.services.context.prepare(conversation, role, messages, settings, task || {})
      : { summary: null, recent: truncate(messages, 10) };
    if (task && task.phase === "compressing") { task.phase = "generating"; task.label = task.generateLabel || "正在等待 " + role.name; app.events.emit("chat:changed", { conversationId: conversation.id, phase: "generating" }); }
    var selected = context.recent;
    var hydrated = await hydrateMessages(selected, settings);
    if (task && task.cancelled) { var stopped = new Error("本轮已停止"); stopped.cancelled = true; throw stopped; }
    var appliedRole = app.services.context.applyToRole(role, context.summary, participantRoles, userProfile);
    var request = app.services.providers.build(profile, appliedRole, hydrated, { stream: profile.streaming !== false });
    var bodyText = JSON.stringify(request.body);
    var bodyBytes = new TextEncoder().encode(bodyText).length;
    if (bodyBytes > 900 * 1024) throw new Error("请求内容超过 900 KiB，请减少图片或新建对话");
    var parsed;
    if (request.streaming) {
      try { parsed = await stream(profile, request, task, role); }
      catch (error) {
        if (!error.streamUnavailable) throw error;
        if (task && task.cancelled) throw error;
        request = app.services.providers.build(profile, appliedRole, hydrated, { stream: false });
        bodyText = JSON.stringify(request.body);
        if (task) task.streamingFallback = true;
      }
    }
    if (!parsed) {
      var result = await app.platform.network.requestJson({
        url: request.url,
        method: "POST",
        headers: request.headers,
        bodyText: bodyText,
        contentType: "application/json",
        timeoutMs: 120000,
        task: task
      });
      parsed = app.services.providers.parse(profile, result.data);
      parsed.streamed = false;
      if (task && task.onDelta && parsed.text) task.onDelta({ delta: parsed.text, text: partialText(parsed.text, role.name), fallback: true });
    }
    parsed.text = removeRoleEcho(parsed.text, role.name);
    parsed.profileName = profile.name;
    parsed.contextTrimmed = Boolean(context.summary) || selected.length < messages.length || selected.some(function (message) { return message.contextTruncated; });
    parsed.contextCompressed = Boolean(context.summary);
    parsed.summaryUpdatedAt = context.summary && context.summary.updatedAt;
    return parsed;
  }

  async function test(service, modelId) {
    var role = { systemPrompt: "只执行连接测试。", model: modelId || service.model || (app.services.modelServices.models("llm", service)[0] || {}).id };
    var profile = app.services.modelServices.resolveLlm(service, role);
    profile = Object.assign({}, profile, { allowImageGeneration: false, maxOutputTokens: 256 });
    if (!profile.model) throw new Error("服务还没有可用模型，请先获取模型列表或填写模型 ID");
    var request = app.services.providers.build(profile, role, [{ role: "user", text: "仅回复 OK。", images: [] }]);
    var result = await app.platform.network.requestJson({
      url: request.url,
      method: "POST",
      headers: request.headers,
      bodyText: JSON.stringify(request.body),
      contentType: "application/json",
      timeoutMs: 60000
    });
    return app.services.providers.parse(profile, result.data);
  }

  app.services.llm = { complete: complete, test: test, truncate: truncate, hydrateMessages: hydrateMessages, removeRoleEcho: removeRoleEcho, partialText: partialText };
})(window.chataxi);
