(function (global) {
  "use strict";
  global.chataxi = global.chataxi || {};
  global.chataxi.version = "0.1.2";
  global.chataxi.state = {
    route: "conversations",
    previousRoute: null,
    activeConversationId: null,
    settingsTab: "llm",
    sending: false,
    speechSubscriptionId: null,
    draftMedia: [],
    selectedRoleIds: []
  };
})(window);
