(function (app) {
  "use strict";
  var u = app.utils, ui = app.components, store = app.data.store;
  var templates = [
    { name: "通用助手", color: "#59664d", icon: "robot", prompt: "你是一位清晰、耐心的个人助手。先理解用户的真实目标，用准确、简洁的中文回答。面对不确定的信息，明确说明，不编造事实。需要时提供可执行的下一步。" },
    { name: "写作伙伴", color: "#9a634b", icon: "pen-nib", prompt: "你是一位中文写作伙伴。帮助用户梳理观点、组织文章和润色文字，保留作者本意与个人语气。使用自然具体的表达，删去空话；必要时解释关键修改的原因。" },
    { name: "思考搭档", color: "#596ca0", icon: "lightbulb", prompt: "你是一位善于分析的思考搭档。理解问题后，区分事实、假设与判断，指出关键遗漏和反例。不要机械附和，也不要为了反对而反对；给出明确、可检验的建议。" }
  ];
  function option(value, label, selected) {
    return '<option value="' + u.escapeHtml(value) + '"' + (value === selected ? ' selected' : '') + '>' + u.escapeHtml(label) + '</option>';
  }
  function modelOptions(service, selected) {
    return app.services.modelServices.models("llm", service).map(function (item) { return '<option value="' + u.escapeHtml(item.id) + '">' + u.escapeHtml(item.name || item.id) + '</option>'; }).join("");
  }
  function ttsItems(service, type) {
    var items = type === "voice" ? app.services.modelServices.voices(service) : app.services.modelServices.models("tts", service);
    return items.map(function (item) { return '<option value="' + u.escapeHtml(item.id) + '">' + u.escapeHtml(item.name || item.id) + '</option>'; }).join("");
  }

  async function render() {
    var roles = (await store.list("roles")).sort(function (a, b) { return a.name.localeCompare(b.name, "zh-CN"); });
    var profiles = await store.list("llm-profiles");
    if (app.state.route !== "roles") return;
    ui.pageHeader("角色", roles.length + " 位角色", '<button class="button primary compact" type="button" data-add-role>' + ui.icon("plus") + '<span>新角色</span></button>');
    var main = document.getElementById("mainContent"); main.className = "main";
    main.innerHTML = '<section class="page">' + (roles.length ? ui.search("搜索角色名称或模型") + '<div class="role-grid" id="roleList"></div>' : '<div class="compact-empty"><div class="empty-icon">' + ui.icon("user-group") + '</div><h2>创建第一位角色</h2><p>设定角色提示词、模型和声音后即可开始对话。</p><button class="button primary" type="button" data-add-role>' + ui.icon("plus") + '新角色</button></div>') + '</section>';
    if (roles.length) {
      var paint = function (query) {
        var items = roles.filter(function (role) { var profile = profiles.find(function (item) { return item.id === role.llmProfileId; }); return (role.name + " " + role.model + " " + (profile ? profile.name : "")).toLowerCase().indexOf(query.toLowerCase()) >= 0; });
        document.getElementById("roleList").innerHTML = items.length ? items.map(function (role) {
          var status = app.services.profiles.roleStatus(role, profiles);
          var profile = profiles.find(function (item) { return item.id === role.llmProfileId; });
          return '<article class="card role-card"><div class="role-card-head">' + ui.roleAvatar(role, "role-list-avatar") + '<div class="list-copy"><strong>' + u.escapeHtml(role.name) + '</strong><span>' + u.escapeHtml(profile ? profile.name + " · " + (role.model || "待选模型") : "未绑定模型服务") + '</span></div><span class="badge ' + (status ? "warning" : "success") + '">' + (status ? u.escapeHtml(status) : "可对话") + '</span></div><div class="role-actions"><button class="button ghost" type="button" data-edit-role="' + u.escapeHtml(role.id) + '">' + ui.icon("pen") + '编辑角色</button><button class="button ' + (status ? "secondary" : "primary") + '" type="button" ' + (status ? 'data-edit-role' : 'data-chat-role') + '="' + u.escapeHtml(role.id) + '">' + ui.icon(status ? "wrench" : "comment-dots") + (status ? "修复配置" : "开始对话") + '</button></div></article>';
        }).join("") : ui.empty("magnifying-glass", "没有找到角色", "换个关键词试试。", "");
        main.querySelectorAll("[data-edit-role]").forEach(function (button) { button.addEventListener("click", ui.action(async function () { await openEditor(await store.get("roles", button.dataset.editRole)); })); });
        main.querySelectorAll("[data-chat-role]").forEach(function (button) { button.addEventListener("click", ui.action(function () { return app.features.conversations.openEditor(null, button.dataset.chatRole); })); });
      };
      main.querySelector("#listSearch").addEventListener("input", function (event) { paint(event.target.value); }); paint("");
    }
    document.querySelectorAll("[data-add-role]").forEach(function (button) { button.addEventListener("click", ui.action(function () { return openEditor(null); })); });
  }

  async function openEditor(existing, onSaved) {
    var llms = (await store.list("llm-profiles")).filter(function (item) { return item.enabled !== false || existing && item.id === existing.llmProfileId; });
    if (!llms.length && !existing) {
      await app.navigate("models", { modelsTab: "llm" });
      app.features.models.openService("llm", null, function () { return app.navigate("roles").then(function () { return openEditor(null, onSaved); }); });
      return;
    }
    var settings = await store.get("meta", "settings");
    var ttsServices = (await store.list("tts-profiles")).filter(function (item) { return item.enabled !== false || existing && item.id === existing.ttsProfileId; });
    var editing = Boolean(existing);
    var firstService = llms[0] || {};
    var role = existing || { id: u.id("role"), name: "", systemPrompt: "", llmProfileId: firstService.id || "", model: (app.services.modelServices.models("llm", firstService)[0] || {}).id || "", temperature: 0.7, maxOutputTokens: 4096, reasoningEffort: "", allowImageGeneration: false, ttsProfileId: "", ttsModel: "", ttsVoice: "", voicePrompt: "", avatarColor: "#59664d", avatarIcon: "robot", enabled: true };
    var activeLlm = llms.find(function (item) { return item.id === role.llmProfileId; }) || firstService;
    var activeTtsId = role.ttsProfileId || settings.defaultTtsProfileId;
    var activeTts = ttsServices.find(function (item) { return item.id === activeTtsId; }) || ttsServices[0] || {};
    var html = '<div class="form-grid">' + (!editing ? '<fieldset><legend>快速开始</legend><div class="chip-row">' + templates.map(function (item, index) { return '<button class="chip" type="button" data-template="' + index + '">' + ui.icon(item.icon) + u.escapeHtml(item.name) + '</button>'; }).join("") + '</div></fieldset>' : '') +
      '<section class="editor-section"><h3>角色</h3><div class="avatar-editor"><span id="avatarPreview">' + ui.avatar(role.name, role.avatarColor, "large", role.avatarIcon) + '</span><div class="avatar-controls"><label class="field"><span>头像图标</span><select name="avatarIcon">' + app.services.catalog.avatars.map(function (iconName) { return option(iconName, iconName, role.avatarIcon); }).join("") + '</select></label><label class="field color-field"><span>颜色</span><input name="avatarColor" type="color" value="' + u.escapeHtml(role.avatarColor) + '"></label></div></div><label class="field"><span>角色名称</span><input name="name" required maxlength="40" value="' + u.escapeHtml(role.name) + '" placeholder="怎么称呼这位角色？"></label><label class="field"><span>角色提示词</span><textarea class="prompt-editor" name="systemPrompt" required maxlength="12000" placeholder="描述身份、目标、边界与回答方式。">' + u.escapeHtml(role.systemPrompt) + '</textarea></label></section>' +
      '<section class="editor-section"><h3>语言模型</h3><label class="field"><span>模型服务</span><select name="llmProfileId" required>' + llms.map(function (item) { return option(item.id, item.name, role.llmProfileId); }).join("") + '</select></label><label class="field"><span>具体模型</span><input name="model" list="roleModelList" required maxlength="180" value="' + u.escapeHtml(role.model || "") + '" placeholder="选择或填写模型 ID"><datalist id="roleModelList">' + modelOptions(activeLlm, role.model) + '</datalist></label><details class="advanced" open><summary>模型进阶设置</summary><div class="form-grid"><label class="field range-field" id="temperatureField"><span>温度 <output data-output="temperature">' + Number(role.temperature == null ? 0.7 : role.temperature).toFixed(1) + '</output></span><input name="temperature" type="range" min="0" max="2" step="0.1" value="' + Number(role.temperature == null ? 0.7 : role.temperature) + '"><small>数值越高，表达越发散。</small></label><label class="field range-field"><span>最大输出 <output data-output="maxOutputTokens">' + Number(role.maxOutputTokens || 4096) + ' tokens</output></span><input name="maxOutputTokens" type="range" min="256" max="32768" step="256" value="' + Number(role.maxOutputTokens || 4096) + '"></label><label class="field range-field" id="reasoningField"><span>推理强度 <output data-output="reasoningEffort">自动</output></span><input name="reasoningLevel" type="range" min="0" max="0" step="1" value="0"></label><label class="switch-row" id="imageGenerationField"><span><strong>允许图片生成</strong><small>仅在所选模型与协议支持时调用图片生成工具</small></span><input name="allowImageGeneration" type="checkbox"' + (role.allowImageGeneration ? ' checked' : '') + '></label></div></details></section>' +
      '<section class="editor-section"><h3>朗读声音</h3><label class="field"><span>朗读服务</span><select name="ttsProfileId"><option value="">跟随通用设置 · ' + u.escapeHtml((ttsServices.find(function (item) { return item.id === settings.defaultTtsProfileId; }) || {}).name || "未设置") + '</option>' + ttsServices.map(function (item) { return option(item.id, item.name, role.ttsProfileId); }).join("") + '</select></label><div id="ttsDetails" class="form-grid"><label class="field"><span>TTS 模型</span><input name="ttsModel" list="roleTtsModelList" maxlength="180" value="' + u.escapeHtml(role.ttsModel || "") + '" placeholder="选择或填写模型 ID"><datalist id="roleTtsModelList">' + ttsItems(activeTts, "model") + '</datalist></label><label class="field"><span>音色</span><input name="ttsVoice" list="roleVoiceList" maxlength="180" value="' + u.escapeHtml(role.ttsVoice || "") + '" placeholder="选择或填写 Voice ID"><datalist id="roleVoiceList">' + ttsItems(activeTts, "voice") + '</datalist><small id="voiceHelp">按服务支持的音色选择。</small></label><label class="field" id="voicePromptField"><span>音色提示词 <em>所选模型支持时生效</em></span><textarea name="voicePrompt" maxlength="2000" placeholder="例如：温暖、沉稳，语速自然，停顿清晰。">' + u.escapeHtml(role.voicePrompt || "") + '</textarea></label></div></section>' +
      '<label class="switch-row"><span><strong>启用角色</strong><small>停用后保留历史，不接收新消息</small></span><input name="enabled" type="checkbox"' + (role.enabled !== false ? ' checked' : '') + '></label>' + (editing ? '<button class="button danger full" type="button" data-delete-role>' + ui.icon("trash") + '删除角色</button>' : '') + '</div>';
    var form = ui.openModal({ title: editing ? "编辑角色" : "创建角色", submitText: editing ? "保存更改" : "创建角色", html: html, onSubmit: async function (target) {
      var llm = llms.find(function (item) { return item.id === u.formValue(target, "llmProfileId"); });
      var modelId = u.formValue(target, "model"), definition = app.services.modelServices.modelDefinition("llm", llm, modelId);
      var levels = definition.reasoning || [];
      var ttsProfileId = u.formValue(target, "ttsProfileId");
      var ttsService = ttsServices.find(function (item) { return item.id === ttsProfileId; }) || {};
      var ttsModel = ttsProfileId ? u.formValue(target, "ttsModel") : "";
      var ttsDefinition = app.services.modelServices.modelDefinition("tts", ttsService, ttsModel);
      var next = Object.assign({}, role, {
        name: u.formValue(target, "name"), systemPrompt: u.formValue(target, "systemPrompt"), avatarIcon: u.formValue(target, "avatarIcon"), avatarColor: u.formValue(target, "avatarColor"),
        llmProfileId: llm && llm.id || "", model: modelId,
        temperature: definition.temperature === false ? null : Number(u.formValue(target, "temperature")), maxOutputTokens: Number(u.formValue(target, "maxOutputTokens")), reasoningEffort: levels[Number(u.formValue(target, "reasoningLevel"))] || "", allowImageGeneration: definition.imageGeneration ? u.checked(target, "allowImageGeneration") : false,
        ttsProfileId: ttsProfileId, ttsModel: ttsModel, ttsVoice: ttsProfileId && (ttsService.family || ttsService.type) !== "system" ? u.formValue(target, "ttsVoice") : "", voicePrompt: ttsProfileId && ttsDefinition.voicePrompt ? u.formValue(target, "voicePrompt") : "",
        enabled: u.checked(target, "enabled"), updatedAt: Date.now(), createdAt: role.createdAt || Date.now()
      });
      delete next.description;
      if (!next.name || !next.systemPrompt) throw new Error("请填写角色名称与提示词");
      if (!next.llmProfileId || !next.model) throw new Error("请选择模型服务与具体模型");
      if (next.enabled && app.services.profiles.roleStatus(next, await store.list("llm-profiles"))) throw new Error("请为启用的角色配置可用模型");
      await store.put("roles", next.id, next); return next;
    }, onSuccess: async function (next) { ui.toast(editing ? "角色已更新" : "角色已创建"); if (onSaved) return onSaved(next); if (app.state.route === "roles") await render(); } });

    function selectedLlm() { return llms.find(function (item) { return item.id === form.elements.namedItem("llmProfileId").value; }) || {}; }
    function selectedTts() { var id = form.elements.namedItem("ttsProfileId").value || settings.defaultTtsProfileId; return ttsServices.find(function (item) { return item.id === id; }) || {}; }
    function fillList(id, html) { form.querySelector(id).innerHTML = html; }
    function syncModel(reset) {
      var service = selectedLlm(); fillList("#roleModelList", modelOptions(service));
      var input = form.elements.namedItem("model"); if (reset) input.value = (app.services.modelServices.models("llm", service)[0] || {}).id || "";
      var definition = app.services.modelServices.modelDefinition("llm", service, input.value);
      var temp = form.elements.namedItem("temperature"); temp.disabled = definition.temperature === false; form.querySelector("#temperatureField").classList.toggle("is-disabled", temp.disabled);
      var output = form.elements.namedItem("maxOutputTokens"); output.max = Number(definition.maxOutputTokens || 32768); if (Number(output.value) > Number(output.max)) output.value = output.max;
      var levels = definition.reasoning || [], reasoning = form.elements.namedItem("reasoningLevel");
      reasoning.max = Math.max(0, levels.length - 1); reasoning.disabled = !levels.length;
      var current = levels.indexOf(role.reasoningEffort); reasoning.value = String(current >= 0 ? current : 0);
      form.querySelector('[data-output="reasoningEffort"]').textContent = levels[Number(reasoning.value)] || "不支持";
      var image = form.elements.namedItem("allowImageGeneration"); image.disabled = !definition.imageGeneration; if (image.disabled) image.checked = false;
      form.querySelector("#imageGenerationField").classList.toggle("is-disabled", image.disabled);
      syncRanges();
    }
    function syncTts(reset) {
      var service = selectedTts(), inherited = !form.elements.namedItem("ttsProfileId").value;
      fillList("#roleTtsModelList", ttsItems(service, "model")); fillList("#roleVoiceList", ttsItems(service, "voice"));
      if (reset) { form.elements.namedItem("ttsModel").value = inherited ? "" : (app.services.modelServices.models("tts", service)[0] || {}).id || ""; form.elements.namedItem("ttsVoice").value = inherited ? "" : (app.services.modelServices.voices(service)[0] || {}).id || ""; }
      var system = (service.family || service.type) === "system";
      form.elements.namedItem("ttsModel").disabled = inherited;
      form.elements.namedItem("ttsVoice").disabled = inherited || system;
      form.elements.namedItem("voicePrompt").disabled = inherited;
      form.querySelector("#voiceHelp").textContent = system ? "系统音色由 Android 设置决定；当前 Hermit 公开接口不能指定单个系统音色。" : "按服务支持的音色选择。";
      var modelId = form.elements.namedItem("ttsModel").value || (app.services.modelServices.models("tts", service)[0] || {}).id || "";
      var definition = app.services.modelServices.modelDefinition("tts", service, modelId);
      form.querySelector("#voicePromptField").classList.toggle("is-hidden", inherited || !definition.voicePrompt);
    }
    function syncRanges() {
      form.querySelector('[data-output="temperature"]').textContent = Number(form.elements.namedItem("temperature").value).toFixed(1);
      form.querySelector('[data-output="maxOutputTokens"]').textContent = form.elements.namedItem("maxOutputTokens").value + " tokens";
      var definition = app.services.modelServices.modelDefinition("llm", selectedLlm(), form.elements.namedItem("model").value); var levels = definition.reasoning || [];
      form.querySelector('[data-output="reasoningEffort"]').textContent = levels[Number(form.elements.namedItem("reasoningLevel").value)] || "不支持";
    }
    form.querySelectorAll("[data-template]").forEach(function (button) { button.addEventListener("click", function () { var template = templates[Number(button.dataset.template)]; form.elements.namedItem("name").value = template.name; form.elements.namedItem("systemPrompt").value = template.prompt; form.elements.namedItem("avatarColor").value = template.color; form.elements.namedItem("avatarIcon").value = template.icon; syncAvatar(); }); });
    function syncAvatar() { form.querySelector("#avatarPreview").innerHTML = ui.avatar(form.elements.namedItem("name").value || "AI", form.elements.namedItem("avatarColor").value, "large", form.elements.namedItem("avatarIcon").value); }
    ["name", "avatarColor", "avatarIcon"].forEach(function (name) { form.elements.namedItem(name).addEventListener("input", syncAvatar); });
    form.elements.namedItem("llmProfileId").addEventListener("change", function () { syncModel(true); }); form.elements.namedItem("model").addEventListener("change", function () { syncModel(false); });
    form.elements.namedItem("ttsProfileId").addEventListener("change", function () { syncTts(true); }); form.elements.namedItem("ttsModel").addEventListener("change", function () { syncTts(false); });
    form.querySelectorAll('input[type="range"]').forEach(function (input) { input.addEventListener("input", syncRanges); });
    syncModel(false); syncTts(false); syncAvatar();
    var remove = form.querySelector("[data-delete-role]");
    if (remove) remove.addEventListener("click", ui.action(async function () {
      var refs = (await store.list("conversations")).filter(function (conversation) { return conversation.roleIds.indexOf(role.id) >= 0; });
      if (refs.length) { ui.toast("角色仍参与“" + refs[0].title + "”，请先编辑该对话"); return; }
      if (await ui.confirm({ title: "删除“" + role.name + "”？", message: "角色提示词与模型设置将从当前设备删除。", danger: true, confirmText: "删除角色" })) { await store.remove("roles", role.id); if (app.state.route === "roles") await render(); }
    }));
    return form;
  }

  app.features = app.features || {};
  app.features.roles = { render: render, openEditor: openEditor };
})(window.chataxi);
