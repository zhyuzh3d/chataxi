(function (app) {
  "use strict";
  var generation = 0, activeAudio = null, playbackId = null, utteranceId = null, logicalFileId = null, unsubscribers = [], currentTask = null;
  function state(speaking) { app.events.emit('tts:state', { speaking: speaking }); }
  async function cleanup() {
    unsubscribers.splice(0).forEach(function (off) { off(); });
    if (activeAudio) { var audio = activeAudio; activeAudio = null; audio.onended = null; audio.onerror = null; audio.pause(); URL.revokeObjectURL(audio.src); }
    var api = app.platform.hermit.api();
    if (api && playbackId) { var id = playbackId; playbackId = null; await api.audio.stopPlayback({ playbackId: id }).catch(function () {}); }
    if (api && utteranceId) { utteranceId = null; await api.tts.stop().catch(function () {}); }
    if (api && logicalFileId) { var file = logicalFileId; logicalFileId = null; await api.files.delete({ logicalFileId: file }).catch(function () {}); }
    state(false);
  }
  async function stop() {
    generation += 1;
    if (currentTask) { currentTask.cancelled = true; if (currentTask.controller) currentTask.controller.abort(); }
    currentTask = null;
    await cleanup();
  }
  function headers(profile) {
    var result = { 'Content-Type': 'application/json' };
    if (profile.apiKey) result[profile.type === 'elevenlabs' ? 'xi-api-key' : 'Authorization'] = profile.type === 'elevenlabs' ? profile.apiKey : 'Bearer ' + profile.apiKey;
    Object.assign(result, app.utils.parseHeaders(profile.customHeaders));
    return result;
  }
  async function speak(text, role) {
    var clean = String(text || '').replace(/```[\s\S]*?```/g, '').trim().slice(0, 10000);
    if (!clean) return;
    await stop();
    var token = ++generation, task = { cancelled: false }; currentTask = task;
    var settings = await app.data.store.get('meta', 'settings');
    var service = await app.data.store.get('tts-profiles', role && role.ttsProfileId || settings.defaultTtsProfileId || 'system-tts');
    if (!service || service.enabled === false) throw new Error('朗读服务不存在或已停用，请在模型页选择可用服务');
    var profile = app.services.modelServices.resolveTts(service, role || {}, settings);
    if (token !== generation) return;
    state(true);
    try {
      if (profile.type === 'system') {
        if (!(await app.platform.hermit.awaitReady(1000))) throw new Error('系统朗读需要在 HermitApp 中使用');
        var api = app.platform.hermit.api();
        await api.tts.voices();
        if (token !== generation) return;
        ['tts.done', 'tts.error'].forEach(function (event) { unsubscribers.push(app.platform.hermit.on(event, function (data) { if (token === generation && (!utteranceId || data.utteranceId === utteranceId)) { if (event === 'tts.error') app.events.emit('tts:error', { message: '系统朗读失败，请检查系统语音服务' }); stop(); } })); });
        var result = await api.tts.speak({ text: clean, language: profile.language || settings.language || 'zh-CN', rate: Number(profile.rate || 1), pitch: Number(profile.pitch || 1) });
        if (token !== generation) { await api.tts.stop(); return; }
        utteranceId = result.utteranceId; return;
      }
      var endpoint = String(profile.endpoint || '').replace(/\{voice\}/g, encodeURIComponent(profile.voice || ''));
      var body = profile.type === 'elevenlabs' ? { text: clean, model_id: profile.model || 'eleven_multilingual_v2' } : { model: profile.model, input: clean, voice: profile.voice, response_format: profile.format || 'mp3' };
      if (profile.instructions && profile.type !== 'elevenlabs') body.instructions = profile.instructions;
      var response = await app.platform.network.request({ url: endpoint, method: 'POST', headers: headers(profile), bodyText: JSON.stringify(body), contentType: 'application/json', timeoutMs: 90000, task: task });
      if (token !== generation) { if (response.file && response.file.logicalFileId) await app.platform.hermit.api().files.delete({ logicalFileId: response.file.logicalFileId }).catch(function () {}); return; }
      if (response.status < 200 || response.status >= 300) { await app.platform.network.readText(response); throw new Error('朗读服务请求失败（' + response.status + '）'); }
      if (response.file && response.file.logicalFileId && app.platform.hermit.available()) {
        logicalFileId = response.file.logicalFileId;
        ['audio.playback.done', 'audio.playback.error'].forEach(function (event) { unsubscribers.push(app.platform.hermit.on(event, function (data) { if (token === generation && (!playbackId || playbackId === data.playbackId)) stop(); })); });
        var playback = await app.platform.hermit.api().audio.play({ logicalFileId: logicalFileId });
        if (token !== generation) { await app.platform.hermit.api().audio.stopPlayback({ playbackId: playback.playbackId }); return; }
        playbackId = playback.playbackId;
      } else {
        if (!response.bodyBase64) throw new Error('语音服务没有返回可播放音频');
        var mime = response.headers && (response.headers['content-type'] || response.headers['Content-Type']) || 'audio/mpeg';
        activeAudio = new Audio(URL.createObjectURL(app.utils.base64ToBlob(response.bodyBase64, mime)));
        activeAudio.onended = function () { if (token === generation) stop(); };
        activeAudio.onerror = function () { if (token === generation) { app.events.emit('tts:error', { message: '音频无法播放，请检查服务的输出格式' }); stop(); } };
        await activeAudio.play();
      }
    } catch (error) { if (token === generation) { await stop(); throw error; } }
  }
  app.services.tts = { speak: speak, stop: stop, headers: headers };
})(window.chataxi);
