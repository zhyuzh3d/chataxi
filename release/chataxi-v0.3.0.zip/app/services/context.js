(function (app) {
  "use strict";
  var store = app.data.store;

  function summaryKey(conversationId) { return conversationId; }
  function characters(messages) { return messages.reduce(function (total, message) { return total + String(message.text || "").length; }, 0); }
  function transcript(messages) {
    return messages.map(function (message) {
      return (message.kind === "user" ? "用户" : message.roleName || "AI") + "：" + (message.text || ((message.media || []).length ? "[图片]" : ""));
    }).join("\n\n");
  }
  function afterSummary(messages, summary) {
    if (!summary || !summary.throughMessageId) return messages.slice();
    var index = messages.findIndex(function (message) { return message.id === summary.throughMessageId; });
    return index < 0 ? messages.slice() : messages.slice(index + 1);
  }

  async function getSummary(conversationId) {
    var summary = await store.get("summaries", summaryKey(conversationId));
    if (summary) return summary;
    var legacy = await store.list("summaries", conversationId + ":");
    if (!legacy.length) return null;
    legacy.sort(function (a, b) { return Number(b.updatedAt || 0) - Number(a.updatedAt || 0); });
    summary = Object.assign({}, legacy[0], { id: summaryKey(conversationId), conversationId: conversationId, compressedByRoleId: legacy[0].roleId || "", compressedByRoleName: legacy[0].roleName || "" });
    delete summary.roleId; delete summary.roleName;
    await store.put("summaries", summary.id, summary);
    return summary;
  }

  async function prepare(conversation, role, messages, settings, task) {
    var key = summaryKey(conversation.id);
    var summary = await getSummary(conversation.id);
    var done = messages.filter(function (message) { return message.status === "done"; });
    var recentCount = Math.min(40, Math.max(2, Number(conversation.recentFullMessages || settings.recentFullMessages || 12)));
    var uncompressed = afterSummary(done, summary);
    var currentSize = (summary ? summary.text.length : 0) + characters(uncompressed);
    var canCompress = settings.autoCompress && currentSize > Number(settings.compressionThresholdChars || 32000) && uncompressed.length > recentCount;
    if (canCompress) {
      var prefix = uncompressed.slice(0, -recentCount);
      if (prefix.length) {
        task.phase = "compressing";
        task.label = "正在压缩历史上下文 · " + role.name;
        app.events.emit("chat:changed", { conversationId: conversation.id, phase: "compressing" });
        var service = await store.get("llm-profiles", role.llmProfileId);
        if (!service) throw new Error("无法压缩：角色的模型服务不存在");
        var profile = app.services.modelServices.resolveLlm(service, role);
        profile.allowImageGeneration = false;
        profile.maxOutputTokens = Math.min(profile.maxOutputTokens, Math.max(512, Math.ceil(Number(settings.compressionTargetChars || 2400) * 1.25)));
        var prompt = (settings.compressionPrompt || "压缩历史上下文") + "\n\n目标长度：不超过约 " + Number(settings.compressionTargetChars || 2400) + " 个中文字符。";
        var source = (summary && summary.text ? "已有压缩上下文：\n" + summary.text + "\n\n需要合并的新历史：\n" : "需要压缩的历史：\n") + transcript(prefix);
        var request = app.services.providers.build(profile, { systemPrompt: prompt }, [{ role: "user", text: source, images: [] }]);
        var response = await app.platform.network.requestJson({ url: request.url, method: "POST", headers: request.headers, bodyText: JSON.stringify(request.body), contentType: "application/json", timeoutMs: 120000, task: task });
        var parsed = app.services.providers.parse(profile, response.data);
        if (task.cancelled) { var stopped = new Error("本轮已停止"); stopped.cancelled = true; throw stopped; }
        summary = {
          id: key,
          conversationId: conversation.id,
          compressedByRoleId: role.id,
          compressedByRoleName: role.name,
          text: parsed.text.slice(0, Math.max(400, Number(settings.compressionTargetChars || 2400))),
          throughMessageId: prefix[prefix.length - 1].id,
          throughCreatedAt: prefix[prefix.length - 1].createdAt,
          sourceMessageCount: Number(summary && summary.sourceMessageCount || 0) + prefix.length,
          updatedAt: Date.now()
        };
        await store.put("summaries", key, summary);
        uncompressed = afterSummary(done, summary);
      }
    }
    return { summary: summary, recent: uncompressed.slice(-recentCount), compressed: Boolean(summary), retainedCount: recentCount };
  }

  function applyToRole(role, summary, participantRoles) {
    var participants = (participantRoles || [role]).map(function (item) {
      return (item.id === role.id ? "当前发言角色" : "参与角色") + "「" + item.name + "」：\n" + (item.systemPrompt || "未设置提示词");
    }).join("\n\n");
    var prompt = "你当前以「" + role.name + "」的身份回答。以下是本对话全部参与角色的设定；你需要理解其他角色，但只执行当前发言角色的设定。\n<conversation_roles>\n" + participants + "\n</conversation_roles>";
    if (summary && summary.text) prompt += "\n\n以下是本对话更早内容的压缩上下文。它可能由用户手工修订，应作为既有对话背景使用：\n<conversation_summary>\n" + summary.text + "\n</conversation_summary>";
    return Object.assign({}, role, { systemPrompt: prompt });
  }

  async function list(conversationId) {
    var summary = await getSummary(conversationId);
    return summary ? [summary] : [];
  }

  async function editable(messages, conversationId, recentCount) {
    var summary = await getSummary(conversationId);
    var boundary = Number(summary && summary.throughCreatedAt || 0);
    var recent = messages.filter(function (message) { return message.status === "done"; }).slice(-Math.min(40, Math.max(2, Number(recentCount || 12))));
    var allowed = {};
    recent.forEach(function (message) { if (message.createdAt > boundary) allowed[message.id] = true; });
    return allowed;
  }

  app.services.context = { prepare: prepare, applyToRole: applyToRole, list: list, get: getSummary, editable: editable, summaryKey: summaryKey, characters: characters };
})(window.chataxi);
