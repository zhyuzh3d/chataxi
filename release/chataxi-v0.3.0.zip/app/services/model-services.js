(function (app) {
  "use strict";
  var catalog = app.services.catalog;

  function families(kind) {
    return catalog[kind === "llm" ? "llmFamilies" : kind === "tts" ? "ttsFamilies" : "asrFamilies"];
  }

  function family(kind, id) {
    return families(kind).find(function (item) { return item.id === id; }) || families(kind).find(function (item) { return item.id === "custom"; });
  }

  function uniqueModels(items) {
    var seen = {};
    return (items || []).map(function (item) {
      return typeof item === "string" ? { id: item, name: item } : item;
    }).filter(function (item) {
      if (!item || !item.id || seen[item.id]) return false;
      seen[item.id] = true;
      return true;
    });
  }

  function models(kind, service) {
    var definition = family(kind, service && (service.family || service.type));
    var stored = service && service.models || [];
    var legacy = service && service.model ? [{ id: service.model, name: service.model }] : [];
    return uniqueModels(stored.concat(definition.models || [], legacy));
  }

  function voices(service) {
    var definition = family("tts", service && (service.family || service.type));
    var stored = service && service.voices || [];
    var legacy = service && service.voice ? [{ id: service.voice, name: service.voice }] : [];
    return uniqueModels(stored.concat((definition.voices || []).map(function (name) { return { id: name, name: name }; }), legacy));
  }

  function serviceStatus(kind, service) {
    if (!service) return "服务不存在";
    if (service.enabled === false) return "已停用";
    var definition = family(kind, service.family || service.type);
    if (definition.type === "system") return "";
    if (!service.endpoint && !definition.endpoint) return "缺少服务地址";
    if (!definition.keyOptional && !service.apiKey) return "缺少 API Key";
    return "";
  }

  function resolveLlm(service, role) {
    var definition = family("llm", service.family || service.type);
    return Object.assign({}, service, {
      family: definition.id,
      apiStyle: service.apiStyle || definition.apiStyle,
      endpoint: service.endpoint || definition.endpoint,
      model: role.model || service.model || (models("llm", service)[0] || {}).id || "",
      temperature: role.temperature == null ? (service.temperature == null ? "" : service.temperature) : role.temperature,
      maxOutputTokens: Number(role.maxOutputTokens || service.maxOutputTokens || 4096),
      reasoningEffort: role.reasoningEffort || service.reasoningEffort || "",
      allowImageGeneration: Boolean(role.allowImageGeneration)
    });
  }

  function resolveTts(service, role, settings) {
    var definition = family("tts", service.family || service.type);
    return Object.assign({}, service, {
      family: definition.id,
      type: service.type || definition.type,
      endpoint: service.endpoint || definition.endpoint,
      model: role && role.ttsModel || service.model || (models("tts", service)[0] || {}).id || "system",
      voice: role && role.ttsVoice || service.voice || (voices(service)[0] || {}).id || "",
      instructions: role && role.voicePrompt || "",
      language: role && role.ttsLanguage || service.language || settings.language || "zh-CN",
      rate: role && role.ttsRate || service.rate || 1,
      pitch: role && role.ttsPitch || service.pitch || 1
    });
  }

  function resolveAsr(service, conversation, settings) {
    var definition = family("asr", service.family || service.type);
    return Object.assign({}, service, {
      family: definition.id,
      type: service.type || definition.type,
      endpoint: service.endpoint || definition.endpoint,
      model: conversation && conversation.asrModel || service.model || (models("asr", service)[0] || {}).id || "system",
      language: conversation && conversation.asrLanguage || service.language || settings.language || "zh-CN"
    });
  }

  function authHeaders(kind, service) {
    var definition = family(kind, service.family || service.type);
    var key = service.apiKey || "";
    if (definition.id === "anthropic") return key ? { "x-api-key": key, "anthropic-version": "2023-06-01" } : { "anthropic-version": "2023-06-01" };
    if (definition.id === "gemini") return key ? { "x-goog-api-key": key } : {};
    if (definition.id === "elevenlabs") return key ? { "xi-api-key": key } : {};
    return key ? { Authorization: "Bearer " + key } : {};
  }

  async function discover(kind, service) {
    var definition = family(kind, service.family || service.type);
    var url = kind === "tts" ? definition.voicesEndpoint : definition.modelsEndpoint;
    if (!url) return { models: models(kind, service), voices: voices(service) };
    var result = await app.platform.network.requestJson({ url: url, method: "GET", headers: authHeaders(kind, service), timeoutMs: 45000 });
    if (kind === "tts") {
      var accountVoices = (result.data.voices || []).map(function (item) { return { id: item.voice_id || item.id, name: item.name || item.voice_id || item.id }; });
      service.voices = uniqueModels(accountVoices);
    } else {
      var raw = result.data.data || result.data.models || [];
      var discovered = raw.filter(function (item) {
        if (definition.id === "gemini") return !item.supportedGenerationMethods || item.supportedGenerationMethods.indexOf("generateContent") >= 0;
        return true;
      }).map(function (item) {
        var id = String(item.id || item.baseModelId || item.name || "").replace(/^models\//, "");
        return { id: id, name: item.displayName || id };
      }).filter(function (item) { return item.id; });
      service.models = uniqueModels(discovered);
    }
    service.discoveredAt = Date.now();
    await app.data.store.put(kind + "-profiles", service.id, service);
    return { models: models(kind, service), voices: voices(service) };
  }

  function modelDefinition(kind, service, modelId) {
    return models(kind, service).find(function (item) { return item.id === modelId; }) || { id: modelId, name: modelId, maxOutputTokens: 32768, temperature: true, reasoning: [], imageGeneration: (service.apiStyle || "") === "openai-responses" };
  }

  app.services.modelServices = {
    families: families,
    family: family,
    models: models,
    voices: voices,
    serviceStatus: serviceStatus,
    resolveLlm: resolveLlm,
    resolveTts: resolveTts,
    resolveAsr: resolveAsr,
    discover: discover,
    modelDefinition: modelDefinition
  };
})(window.chataxi);
