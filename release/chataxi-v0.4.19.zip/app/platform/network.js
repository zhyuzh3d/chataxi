(function (app) {
  "use strict";
  var utils = app.utils;

  function buildHeaders(options) {
    var headers = {};
    utils.parseHeaders(options.headers || {});
    Object.keys(options.headers || {}).forEach(function (name) {
      if (options.headers[name] != null && String(options.headers[name]).trim()) headers[name] = String(options.headers[name]);
    });
    return headers;
  }

  async function request(options) {
    if (!options || !/^https?:\/\//i.test(options.url || "")) throw new Error("请求地址必须是完整的 HTTP(S) URL");
    utils.validateEndpoint(options.url);
    if (options.task && options.task.cancelled) { var stopped = new Error("本轮已停止"); stopped.cancelled = true; throw stopped; }
    var method = String(options.method || "GET").toUpperCase();
    var headers = buildHeaders(options);
    if (app.platform.hermit.available() || await app.platform.hermit.awaitReady(800)) {
      if (options.task && options.task.cancelled) { var stopped = new Error("本轮已停止"); stopped.cancelled = true; throw stopped; }
      var params = { url: options.url, method: method, headers: headers, timeoutMs: options.timeoutMs || 60000 };
      if (options.bodyBytes) {
        params.bodyBase64 = utils.bytesToBase64(options.bodyBytes);
        params.contentType = options.contentType || "application/octet-stream";
      } else if (typeof options.bodyText === "string") {
        params.bodyText = options.bodyText;
        params.contentType = options.contentType || headers["Content-Type"] || headers["content-type"] || "application/json";
      }
      return app.platform.hermit.api().network.request(params);
    }

    if (options.task && options.task.cancelled) { var cancelled = new Error("本轮已停止"); cancelled.cancelled = true; throw cancelled; }
    var controller = typeof AbortController === "function" ? new AbortController() : null;
    if (options.task) options.task.controller = controller;
    if (options.bodyBytes && options.contentType) headers["Content-Type"] = options.contentType;
    var timer = controller ? setTimeout(function () { controller.abort(); }, options.timeoutMs || 60000) : null;
    try {
      var response = await fetch(options.url, {
        method: method,
        headers: headers,
        body: options.bodyBytes || options.bodyText,
        signal: controller ? controller.signal : undefined
      });
      var type = response.headers.get("content-type") || "application/octet-stream";
      var responseHeaders = {};
      response.headers.forEach(function (value, name) { responseHeaders[name] = value; });
      if (/json|text|xml|javascript/i.test(type)) {
        return { status: response.status, headers: responseHeaders, url: response.url, bodyText: await response.text() };
      }
      var bytes = new Uint8Array(await response.arrayBuffer());
      return { status: response.status, headers: responseHeaders, url: response.url, bodyBase64: utils.bytesToBase64(bytes) };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  async function requestJson(options) {
    var result = await request(options);
    var bodyText = await readText(result);
    var payload = utils.safeJsonParse(bodyText, null);
    if (result.status < 200 || result.status >= 300) {
      var detail = payload && (payload.error || payload.detail || payload.message);
      var message = detail && typeof detail === "object"
        ? (detail.message || detail.status || detail.code || JSON.stringify(detail))
        : detail || "服务未返回可读错误说明，请检查地址、授权或稍后重试";
      Object.keys(options.headers || {}).forEach(function (name) {
        if (/authorization|key|token|secret/i.test(name)) {
          var secret = String(options.headers[name] || "").replace(/^Bearer\s+/i, "");
          if (secret.length >= 4) message = String(message).split(secret).join("***");
        }
      });
      var error = new Error("请求失败（" + result.status + "）：" + utils.cleanError(String(message)).slice(0, 300));
      error.status = result.status;

      throw error;
    }
    if (!payload) throw new Error("服务返回的不是有效 JSON");
    return { data: payload, response: result };
  }

  function streamUnavailable(message, cause) {
    var error = new Error(message);
    error.streamUnavailable = true;
    error.cause = cause;
    return error;
  }

  async function requestSse(options) {
    if (!options || !/^https?:\/\//i.test(options.url || "")) throw new Error("请求地址必须是完整的 HTTP(S) URL");
    utils.validateEndpoint(options.url);
    if (typeof fetch !== "function" || typeof TextDecoder !== "function") throw streamUnavailable("当前 WebView 不支持响应流读取");
    var headers = buildHeaders(options); headers.Accept = "text/event-stream";
    var controller = typeof AbortController === "function" ? new AbortController() : null;
    if (options.task) options.task.controller = controller;
    var timer = controller ? setTimeout(function () { controller.abort(); }, options.timeoutMs || 120000) : null;
    var response, received = false;
    try {
      try {
        response = await fetch(options.url, { method: String(options.method || "POST").toUpperCase(), headers: headers, body: options.bodyText, signal: controller ? controller.signal : undefined });
      } catch (error) {
        if (options.task && options.task.cancelled) { error.cancelled = true; throw error; }
        throw streamUnavailable("当前服务无法通过 WebView 建立流式连接，将改用兼容模式", error);
      }
      if (response.status < 200 || response.status >= 300) {
        var failedText = await response.text(), failed = utils.safeJsonParse(failedText, null);
        var message = failed && failed.error ? failed.error.message || failed.error.code || JSON.stringify(failed.error) : failedText || "服务未返回错误说明";
        var statusError = new Error("请求失败（" + response.status + "）：" + utils.cleanError(String(message)).slice(0, 300)); statusError.status = response.status; throw statusError;
      }
      var reader = response.body && typeof response.body.getReader === "function" ? response.body.getReader() : null, decoder = new TextDecoder("utf-8"), buffer = "", eventName = "message", dataLines = [];
      async function dispatch() {
        if (!dataLines.length) { eventName = "message"; return; }
        received = true;
        var payload = { event: eventName, data: dataLines.join("\n") };
        dataLines = []; eventName = "message";
        if (options.onEvent) await options.onEvent(payload);
      }
      async function consume(line) {
        if (!line) { await dispatch(); return; }
        if (line.charAt(0) === ":") return;
        if (line.indexOf("event:") === 0) { eventName = line.slice(6).trim() || "message"; return; }
        if (line.indexOf("data:") === 0) { dataLines.push(line.slice(5).replace(/^ /, "")); return; }
        if (line.charAt(0) === "{") { dataLines.push(line); await dispatch(); }
      }
      if (reader) {
        while (true) {
          if (options.task && options.task.cancelled) { var cancelled = new Error("本轮已停止"); cancelled.cancelled = true; throw cancelled; }
          var part = await reader.read();
          if (part.done) break;
          buffer += decoder.decode(part.value, { stream: true });
          var lines = buffer.split(/\r?\n/); buffer = lines.pop() || "";
          for (var index = 0; index < lines.length; index += 1) await consume(lines[index]);
        }
        buffer += decoder.decode();
      } else {
        buffer = await response.text();
        var bufferedLines = buffer.split(/\r?\n/); buffer = bufferedLines.pop() || "";
        for (var bufferedIndex = 0; bufferedIndex < bufferedLines.length; bufferedIndex += 1) await consume(bufferedLines[bufferedIndex]);
      }
      if (buffer) await consume(buffer);
      await dispatch();
      return { status: response.status, streamed: received, headers: response.headers, url: response.url };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  async function readText(result) {
    var bodyText = result && result.bodyText || "";
    var logicalFileId = result && result.file && result.file.logicalFileId;
    if (!bodyText && logicalFileId && app.platform.hermit.available()) {
      try {
        var stored = await app.platform.hermit.api().files.readText({ logicalFileId: logicalFileId, maxBytes: 8 * 1024 * 1024 });
        bodyText = stored.text || "";
      } finally {
        try { await app.platform.hermit.api().files.delete({ logicalFileId: logicalFileId }); } catch (_) {}
      }
    }
    return bodyText;
  }

  app.platform.network = { request: request, readText: readText, requestJson: requestJson, requestSse: requestSse };
})(window.chataxi);
