(function (app) {
  "use strict";
  var generation = 0, current = null, ready = {}, muted = false, lastState = { speaking: false };
  var audioContext = null, playbackUnlocked = false;

  function emit(detail) { lastState = Object.assign({}, detail || { speaking: false }, { muted: muted }); app.events.emit("tts:state", lastState); }
  function setMuted(value) {
    muted = Boolean(value);
    if (current && current.audio) current.audio.muted = muted;
    if (current && current.audioGain) current.audioGain.gain.value = muted ? 0 : 1;
    if (current && current.playbackId && app.platform.hermit.available()) {
      var audioApi = app.platform.hermit.api().audio;
      if (typeof audioApi.setPlaybackVolume === "function") audioApi.setPlaybackVolume({ playbackId: current.playbackId, volume: muted ? 0 : 1 }).catch(function () {});
    }
    emit(lastState); return muted;
  }

  function unlockPlayback() {
    var AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return false;
    try {
      if (audioContext && playbackUnlocked && audioContext.state === "running") return true;
      if (!audioContext || audioContext.state === "closed") audioContext = new AudioContext();
      if (audioContext.state !== "running" && typeof audioContext.resume === "function") {
        var resumed = audioContext.resume(); if (resumed && typeof resumed.catch === "function") resumed.catch(function () {});
      }
      var source = audioContext.createBufferSource();
      source.buffer = audioContext.createBuffer(1, 1, 22050); source.connect(audioContext.destination); source.start(0);
      playbackUnlocked = true; return true;
    } catch (_) { return false; }
  }

  function decodeAudio(blob) {
    return blob.arrayBuffer().then(function (bytes) {
      return new Promise(function (resolve, reject) {
        var settled = false;
        function done(value) { if (!settled) { settled = true; resolve(value); } }
        function fail(error) { if (!settled) { settled = true; reject(error || new Error("音频解码失败")); } }
        try {
          var result = audioContext.decodeAudioData(bytes.slice(0), done, fail);
          if (result && typeof result.then === "function") result.then(done, fail);
        } catch (error) { fail(error); }
      });
    });
  }

  function headers(profile) {
    var result = { "Content-Type": "application/json" };
    var eleven = profile.protocol === "elevenlabs" || profile.type === "elevenlabs";
    var doubao = profile.protocol === "doubao-speech-v3" || profile.type === "doubao";
    if (profile.apiKey) {
      if (eleven) result["xi-api-key"] = profile.apiKey;
      else if (doubao) result["X-Api-Key"] = profile.apiKey;
      else result.Authorization = "Bearer " + profile.apiKey;
    }
    if (doubao) {
      result.Accept = "text/event-stream";
      result["X-Api-Resource-Id"] = profile.model || "seed-tts-2.0";
      result["X-Api-Request-Id"] = requestId();
    }
    Object.assign(result, app.utils.parseHeaders(profile.customHeaders));
    return result;
  }

  function requestId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (letter) {
      var value = Math.floor(Math.random() * 16); return (letter === "x" ? value : value & 3 | 8).toString(16);
    });
  }

  function cleanText(text) { return String(text || "").replace(/```[\s\S]*?```/g, "").trim().slice(0, 10000); }

  async function profileFor(role) {
    var settings = await app.data.store.get("meta", "settings");
    var service = await app.data.store.get("tts-profiles", role && role.ttsProfileId || settings.defaultTtsProfileId || "system-tts");
    if (!service || service.enabled === false) throw new Error("朗读服务不存在或已停用，请在模型页选择可用服务");
    return { settings: settings, profile: app.services.modelServices.resolveTts(service, role || {}, settings), service: service };
  }

  function requestBody(profile, text, formatOverride) {
    if (profile.protocol === "elevenlabs" || profile.type === "elevenlabs") {
      var elevenBody = { text: text, model_id: profile.model || "eleven_multilingual_v2" };
      return elevenBody;
    }
    if (profile.protocol === "doubao-speech-v3" || profile.type === "doubao") return {
      user: { uid: "chataxi" },
      req_params: {
        text: text,
        speaker: profile.voice,
        sample_rate: Number(profile.sampleRate || 24000),
        audio_params: {
          format: formatOverride || profile.format || "mp3",
          speech_rate: Math.max(-50, Math.min(100, Number(profile.speechRate || 0))),
          loudness_rate: Math.max(-50, Math.min(100, Number(profile.loudnessRate || 0))),
          bit_rate: 64000
        },
        additions: JSON.stringify({ post_process: { pitch: Math.max(-12, Math.min(12, Number(profile.pitchRate || 0))) }, disable_markdown_filter: true, enable_latex_tn: false })
      }
    };
    var body = { model: profile.model, input: text, voice: profile.voice, response_format: formatOverride || profile.format || "mp3" };
    if (profile.instructions) body.instructions = profile.instructions;
    return body;
  }

  function endpoint(profile, stream) {
    var value = String(stream ? profile.streamEndpoint || profile.endpoint : profile.endpoint || "");
    return value.replace(/\{voice\}/g, encodeURIComponent(profile.voice || ""));
  }

  function pcmStreamProfile(profile) {
    var eleven = profile.protocol === "elevenlabs" || profile.type === "elevenlabs";
    var doubao = profile.protocol === "doubao-speech-v3" || profile.type === "doubao";
    var openai = profile.protocol === "openai-speech" || profile.type === "openai";
    if (eleven) return { kind: "raw", format: "pcm_24000", sampleRate: 24000 };
    if (doubao) return { kind: "sse", format: "pcm", sampleRate: Number(profile.sampleRate || 24000) };
    if (openai) return { kind: "raw", format: "pcm", sampleRate: 24000 };
    return null;
  }

  function pcmStreamUrl(profile, config) {
    var value = endpoint(profile, true);
    if (profile.protocol === "elevenlabs" || profile.type === "elevenlabs") value += (value.indexOf("?") >= 0 ? "&" : "?") + "output_format=" + encodeURIComponent(config.format);
    return value;
  }

  function streamUnavailable(message, cause) {
    var error = new Error(message); error.streamUnavailable = true; error.cause = cause; return error;
  }

  function base64Bytes(value) {
    var binary = atob(String(value || "").replace(/\s/g, "")), bytes = new Uint8Array(binary.length);
    for (var index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return bytes;
  }

  async function streamPcm(text, profile, task, onAudio) {
    var config = pcmStreamProfile(profile);
    if (!config || typeof fetch !== "function" || typeof TextDecoder !== "function") throw streamUnavailable("当前环境没有可用的流式音频通道");
    var controller = typeof AbortController === "function" ? new AbortController() : null;
    if (task) task.controller = controller;
    var response;
    try {
      response = await fetch(pcmStreamUrl(profile, config), { method: "POST", headers: headers(profile), body: JSON.stringify(requestBody(profile, text, config.format)), signal: controller ? controller.signal : undefined });
    } catch (error) {
      if (task && task.cancelled) { error.cancelled = true; throw error; }
      throw streamUnavailable("当前 WebView 无法建立流式音频连接", error);
    }
    if (response.status < 200 || response.status >= 300) throw responseError(response.status, await response.text());
    var reader = response.body && typeof response.body.getReader === "function" ? response.body.getReader() : null;
    if (!reader) throw streamUnavailable("当前 WebView 只能读取完整音频响应");
    var received = false;
    if (config.kind === "raw") {
      while (true) {
        if (task && task.cancelled) { if (controller) controller.abort(); var stopped = new Error("本轮已停止"); stopped.cancelled = true; throw stopped; }
        var part = await reader.read(); if (part.done) break;
        if (part.value && part.value.length) { received = true; onAudio(part.value, config.sampleRate); }
      }
    } else {
      var decoder = new TextDecoder("utf-8"), buffer = "";
      async function consume(line) {
        if (line.indexOf("data:") !== 0) return;
        var event = app.utils.safeJsonParse(line.slice(5).trim(), null); if (!event) return;
        var code = Number(event.code || 0);
        if (code !== 0 && code !== 20000000) throw new Error("豆包语音返回错误（" + code + "）" + (event.message ? "：" + app.utils.cleanError(event.message) : ""));
        if (event.data) { var bytes = base64Bytes(event.data); if (bytes.length) { received = true; onAudio(bytes, config.sampleRate); } }
      }
      while (true) {
        if (task && task.cancelled) { if (controller) controller.abort(); var cancelled = new Error("本轮已停止"); cancelled.cancelled = true; throw cancelled; }
        var chunk = await reader.read(); if (chunk.done) break;
        buffer += decoder.decode(chunk.value, { stream: true }); var lines = buffer.split(/\r?\n/); buffer = lines.pop() || "";
        for (var lineIndex = 0; lineIndex < lines.length; lineIndex += 1) await consume(lines[lineIndex]);
      }
      buffer += decoder.decode(); if (buffer) await consume(buffer);
    }
    if (!received) throw new Error("朗读服务没有返回流式音频数据");
    return true;
  }

  async function disposeClip(clip) {
    if (!clip) return;
    if (clip.url) { URL.revokeObjectURL(clip.url); clip.url = ""; }
    if (clip.logicalFileId && app.platform.hermit.available()) await app.platform.hermit.api().files.delete({ logicalFileId: clip.logicalFileId }).catch(function () {});
    clip.logicalFileId = ""; clip.blob = null;
  }

  async function synthesize(text, profile, task, stream) {
    var response = await app.platform.network.request({ url: endpoint(profile, stream), method: "POST", headers: headers(profile), bodyText: JSON.stringify(requestBody(profile, text)), contentType: "application/json", timeoutMs: 90000, task: task });
    if (task.cancelled) { if (response.file && response.file.logicalFileId && app.platform.hermit.available()) await app.platform.hermit.api().files.delete({ logicalFileId: response.file.logicalFileId }).catch(function () {}); return null; }
    var doubao = profile.protocol === "doubao-speech-v3" || profile.type === "doubao";
    if (doubao) {
      var sseText = await app.platform.network.readText(response);
      if (response.status < 200 || response.status >= 300) throw responseError(response.status, sseText);
      var audio = parseDoubaoSse(sseText, profile.format || "mp3");
      if (!audio || !audio.size) throw new Error("豆包语音没有返回可播放音频");
      return { blob: audio, mime: audio.type, seconds: estimateSeconds(text) };
    }
    if (response.status < 200 || response.status >= 300) { var failedText = await app.platform.network.readText(response); throw responseError(response.status, failedText); }
    if (response.file && response.file.logicalFileId) return { logicalFileId: response.file.logicalFileId, seconds: estimateSeconds(text) };
    if (!response.bodyBase64) throw new Error("语音服务没有返回可播放音频");
    var mime = response.headers && (response.headers["content-type"] || response.headers["Content-Type"]) || "audio/mpeg";
    return { blob: app.utils.base64ToBlob(response.bodyBase64, mime), mime: mime, seconds: estimateSeconds(text) };
  }

  function responseError(status, bodyText) {
    var payload = app.utils.safeJsonParse(bodyText, null), detail = payload && (payload.error || payload.detail || payload.message || payload);
    var message = detail && typeof detail === "object" ? detail.message || detail.status || detail.code : detail;
    return new Error("朗读服务请求失败（" + status + "）" + (message ? "：" + app.utils.cleanError(String(message)) : ""));
  }

  function parseDoubaoSse(text, format) {
    var chunks = [], lines = String(text || "").split(/\r?\n/);
    lines.forEach(function (line) {
      if (line.indexOf("data:") !== 0) return;
      var event = app.utils.safeJsonParse(line.slice(5).trim(), null); if (!event) return;
      var code = Number(event.code || 0);
      if (code !== 0 && code !== 20000000) throw new Error("豆包语音返回错误（" + code + "）" + (event.message ? "：" + app.utils.cleanError(event.message) : ""));
      if (!event.data) return;
      chunks.push(base64Bytes(event.data));
    });
    return chunks.length ? new Blob(chunks, { type: format === "ogg_opus" ? "audio/ogg" : format === "pcm" ? "audio/pcm" : "audio/mpeg" }) : null;
  }

  function estimateSeconds(text) {
    var value = String(text || ""), cjk = (value.match(/[\u3400-\u9fff]/g) || []).length;
    var other = value.replace(/[\u3400-\u9fff\s.,!?;:'"，。！？；：、“”‘’（）()\[\]{}<>《》—…-]/g, "").length;
    return Math.max(0.6, cjk / 4.2 + other / 12);
  }

  function attachPcmPlayer(owner, token, options) {
    owner.pcmQueue = []; owner.pcmSources = []; owner.pcmRemainder = null; owner.bufferedSeconds = 0; owner.started = false; owner.starved = false; owner.finished = false; owner.pcmActive = 0; owner.pcmNextTime = 0;
    var resolveDone, rejectDone;
    owner.pcmDone = new Promise(function (resolve, reject) { resolveDone = resolve; rejectDone = reject; });
    owner.pcmDone.catch(function () {});
    owner.pcmResolve = resolveDone; owner.pcmReject = rejectDone;
    if (!audioContext || !playbackUnlocked) throw streamUnavailable("请先触摸页面以启用流式音频播放");
    owner.audioGain = audioContext.createGain(); owner.audioGain.gain.value = muted ? 0 : 1; owner.audioGain.connect(audioContext.destination);

    function settle(error) {
      if (!owner.pcmResolve && !owner.pcmReject) return;
      var resolve = owner.pcmResolve, reject = owner.pcmReject; owner.pcmResolve = null; owner.pcmReject = null;
      error ? reject(error) : resolve();
    }
    function maybeDone() {
      if (owner.cancelled) { settle(); return; }
      if (owner.finished && owner.pcmActive === 0 && !owner.pcmQueue.length) { owner.starved = false; settle(); return; }
      if (owner.started && !owner.finished && owner.pcmActive === 0 && !owner.pcmQueue.length) { owner.starved = true; emit({ speaking: false, paused: true, messageId: owner.messageId }); }
    }
    function schedule(entry) {
      var samples = entry.samples, buffer = audioContext.createBuffer(1, samples.length, entry.sampleRate), channel = buffer.getChannelData(0);
      channel.set(samples);
      var source = audioContext.createBufferSource(); source.buffer = buffer; source.connect(owner.audioGain);
      var when = Math.max(owner.pcmNextTime || 0, audioContext.currentTime + 0.035); owner.pcmNextTime = when + samples.length / entry.sampleRate; owner.pcmActive += 1; owner.pcmSources.push(source);
      source.onended = function () { owner.pcmSources = owner.pcmSources.filter(function (item) { return item !== source; }); owner.pcmActive = Math.max(0, owner.pcmActive - 1); maybeDone(); };
      source.start(when);
    }
    function startQueue() {
      if (owner.cancelled || token !== generation || owner.started && !owner.starved) return;
      owner.started = true; owner.starved = false; emit({ speaking: true, messageId: owner.messageId });
      while (owner.pcmQueue.length) schedule(owner.pcmQueue.shift());
    }
    function push(bytes, sampleRate) {
      if (owner.cancelled || token !== generation || !bytes || !bytes.length) return;
      var input = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes), merged;
      if (owner.pcmRemainder != null) { merged = new Uint8Array(input.length + 1); merged[0] = owner.pcmRemainder; merged.set(input, 1); input = merged; owner.pcmRemainder = null; }
      if (input.length % 2) { owner.pcmRemainder = input[input.length - 1]; input = input.slice(0, -1); }
      if (!input.length) return;
      var view = new DataView(input.buffer, input.byteOffset, input.byteLength), samples = new Float32Array(input.byteLength / 2);
      for (var index = 0; index < samples.length; index += 1) samples[index] = view.getInt16(index * 2, true) / 32768;
      var entry = { samples: samples, sampleRate: sampleRate }, seconds = samples.length / sampleRate; owner.bufferedSeconds += seconds;
      if (owner.started && !owner.starved) schedule(entry); else owner.pcmQueue.push(entry);
      emit({ speaking: owner.started && !owner.starved, buffering: !owner.started, paused: owner.starved, messageId: owner.messageId, bufferedSeconds: owner.bufferedSeconds });
      if (options.autoPlay !== false && !owner.started && owner.bufferedSeconds >= Number(options.minBufferSeconds == null ? 3 : options.minBufferSeconds)) startQueue();
    }
    function finish() { owner.finished = true; owner.pcmRemainder = null; if (options.autoPlay !== false && !owner.started) startQueue(); maybeDone(); return owner.pcmDone; }
    function resumePcm() { if (!owner.starved || !owner.pcmQueue.length) return false; startQueue(); return true; }
    owner.pushPcm = push; owner.finishPcm = finish; owner.resume = resumePcm; owner.failPcm = function (error) { settle(error); };
    return owner;
  }

  function playClip(clip, owner, token) {
    return new Promise(async function (resolve, reject) {
      if (token !== generation || owner.cancelled) { await disposeClip(clip); resolve(); return; }
      owner.activeClip = clip; owner.playbackResolve = resolve;
      if (clip.logicalFileId && app.platform.hermit.available()) {
        var finished = false, offs = [];
        function done(error) { if (finished) return; finished = true; offs.splice(0).forEach(function (off) { off(); }); owner.playbackId = null; owner.activeClip = null; owner.playbackResolve = null; disposeClip(clip).then(function () { error ? reject(error) : resolve(); }); }
        offs.push(app.platform.hermit.on("audio.playback.done", function (data) { if (!owner.playbackId || data.playbackId === owner.playbackId) done(); }));
        offs.push(app.platform.hermit.on("audio.playback.error", function (data) { if (!owner.playbackId || data.playbackId === owner.playbackId) done(new Error("音频播放失败")); }));
        try { var playback = await app.platform.hermit.api().audio.play({ logicalFileId: clip.logicalFileId, volume: muted ? 0 : 1 }); if (owner.cancelled || token !== generation) { await app.platform.hermit.api().audio.stopPlayback({ playbackId: playback.playbackId }).catch(function () {}); done(); return; } owner.playbackId = playback.playbackId; }
        catch (error) { done(error); }
        return;
      }
      if (clip.blob && playbackUnlocked && audioContext) {
        try {
          if (audioContext.state !== "running" && typeof audioContext.resume === "function") await audioContext.resume();
          var decoded = await decodeAudio(clip.blob);
          if (token !== generation || owner.cancelled) { await disposeClip(clip); resolve(); return; }
          var source = audioContext.createBufferSource(), gain = audioContext.createGain();
          source.buffer = decoded; gain.gain.value = muted ? 0 : 1; source.connect(gain); gain.connect(audioContext.destination);
          owner.audioSource = source; owner.audioGain = gain;
          source.onended = function () { owner.audioSource = null; owner.audioGain = null; owner.activeClip = null; owner.playbackResolve = null; disposeClip(clip).then(resolve); };
          source.start(0); return;
        } catch (_) { owner.audioSource = null; owner.audioGain = null; }
      }
      if (!clip.url && clip.blob) clip.url = URL.createObjectURL(clip.blob);
      if (!clip.url || typeof Audio !== "function") { await disposeClip(clip); reject(new Error("当前环境不能播放语音")); return; }
      var audio = new Audio(clip.url); audio.muted = muted; owner.audio = audio;
      audio.onended = function () { owner.audio = null; owner.activeClip = null; owner.playbackResolve = null; disposeClip(clip).then(resolve); };
      audio.onerror = function () { owner.audio = null; owner.activeClip = null; owner.playbackResolve = null; disposeClip(clip).then(function () { reject(new Error("音频无法播放，请检查服务输出格式")); }); };
      try { await audio.play(); } catch (error) { owner.audio = null; await disposeClip(clip); reject(/gesture|notallowed/i.test(String(error && (error.message || error))) ? new Error("当前 WebView 阻止了网页音频播放，请触摸页面后重试") : error); }
    });
  }

  async function stopOwner(owner) {
    if (!owner) return;
    owner.cancelled = true;
    if (owner.task) { owner.task.cancelled = true; if (owner.task.controller) owner.task.controller.abort(); }
    if (owner.audio) { owner.audio.onended = null; owner.audio.onerror = null; owner.audio.pause(); owner.audio = null; }
    if (owner.audioSource) { owner.audioSource.onended = null; try { owner.audioSource.stop(0); } catch (_) {} owner.audioSource = null; }
    while (owner.pcmSources && owner.pcmSources.length) { var source = owner.pcmSources.shift(); source.onended = null; try { source.stop(0); } catch (_) {} }
    owner.pcmQueue = []; owner.pcmActive = 0; if (owner.pcmResolve) { owner.pcmResolve(); owner.pcmResolve = null; owner.pcmReject = null; }
    if (owner.socketTimer) { clearTimeout(owner.socketTimer); owner.socketTimer = null; }
    if (owner.socket) { owner.socket.onopen = null; owner.socket.onmessage = null; owner.socket.onerror = null; owner.socket.onclose = null; try { owner.socket.close(); } catch (_) {} owner.socket = null; }
    if (owner.audioGain && typeof owner.audioGain.disconnect === "function") { try { owner.audioGain.disconnect(); } catch (_) {} }
    owner.audioGain = null;
    if (owner.playbackId && app.platform.hermit.available()) await app.platform.hermit.api().audio.stopPlayback({ playbackId: owner.playbackId }).catch(function () {});
    owner.playbackId = null;
    if (owner.activeClip) await disposeClip(owner.activeClip); owner.activeClip = null;
    if (owner.playbackResolve) owner.playbackResolve(); owner.playbackResolve = null;
    while (owner.clips && owner.clips.length) await disposeClip(owner.clips.shift());
    (owner.offs || []).forEach(function (off) { off(); }); owner.offs = [];
    if (owner.utteranceId && app.platform.hermit.available()) await app.platform.hermit.api().tts.stop().catch(function () {});
  }

  async function stop() {
    generation += 1;
    var owner = current; current = null;
    await stopOwner(owner);
    emit({ speaking: false });
  }

  async function speakSystem(text, profile, settings, owner, token) {
    if (!(await app.platform.hermit.awaitReady(1000))) throw new Error("系统朗读需要在 HermitApp 中使用");
    var api = app.platform.hermit.api(); await api.tts.voices();
    if (token !== generation) return;
    owner.offs = ["tts.done", "tts.error"].map(function (event) { return app.platform.hermit.on(event, function (data) {
      if (token !== generation || owner.utteranceId && data.utteranceId !== owner.utteranceId) return;
      if (event === "tts.error") app.events.emit("tts:error", { message: "系统朗读失败，请检查系统语音服务" });
      stop();
    }); });
    var result = await api.tts.speak({ text: text, language: profile.language || settings.language || "zh-CN", rate: Number(profile.rate || 1), pitch: Number(profile.pitch || 1) });
    if (token !== generation) { await api.tts.stop(); return; }
    owner.utteranceId = result.utteranceId;
  }

  async function speak(text, role) {
    var clean = cleanText(text); if (!clean) return;
    await stop();
    var token = ++generation, owner = { cancelled: false, task: { cancelled: false }, clips: [] }; current = owner;
    var resolved = await profileFor(role);
    if (token !== generation) return;
    emit({ speaking: true });
    try {
      if (resolved.profile.type === "system") { await speakSystem(clean, resolved.profile, resolved.settings, owner, token); return; }
      var capabilities = app.services.modelServices.ttsCapabilities(resolved.service, resolved.profile.model);
      if (capabilities.audioStreaming && pcmStreamProfile(resolved.profile) && playbackUnlocked && audioContext) {
        try {
          owner.messageId = ""; attachPcmPlayer(owner, token, { autoPlay: true, minBufferSeconds: 3 });
          await streamPcm(clean, resolved.profile, owner.task, function (bytes, sampleRate) { owner.streamReceived = true; owner.pushPcm(bytes, sampleRate); });
          await owner.finishPcm(); if (token === generation) await stop(); return;
        } catch (streamError) {
          if (!streamError.streamUnavailable || owner.streamReceived) throw streamError;
          await stopOwner(owner); token = ++generation; owner = { cancelled: false, task: { cancelled: false }, clips: [] }; current = owner; emit({ speaking: true });
        }
      }
      var clip = await synthesize(clean, resolved.profile, owner.task, false); if (!clip || token !== generation) return;
      await playClip(clip, owner, token); if (token === generation) await stop();
    } catch (error) { if (token === generation) { await stop(); throw error; } }
  }

  async function prepare(text, role, messageId) {
    var clean = cleanText(text); if (!clean || !messageId) return false;
    var resolved = await profileFor(role);
    if (resolved.profile.type === "system") return false;
    await stop(); var token = ++generation, owner = { cancelled: false, task: { cancelled: false }, clips: [], messageId: messageId }; current = owner;
    emit({ speaking: false, preparing: true, messageId: messageId });
    var clip;
    try { clip = await synthesize(clean, resolved.profile, owner.task, false); }
    catch (error) { if (current === owner) current = null; emit({ speaking: false, messageId: messageId }); throw error; }
    if (!clip || owner.cancelled || token !== generation) { await disposeClip(clip); return false; }
    if (ready[messageId]) await disposeClip(ready[messageId].clip);
    ready[messageId] = { clip: clip, role: role, createdAt: Date.now() };
    var readyIds = Object.keys(ready).sort(function (left, right) { return ready[left].createdAt - ready[right].createdAt; });
    while (readyIds.length > 8) { var oldest = readyIds.shift(); await disposeClip(ready[oldest].clip); delete ready[oldest]; }
    current = null;
    emit({ speaking: false, ready: true, messageId: messageId }); return true;
  }

  async function testService(service) {
    var settings = await app.data.store.get("meta", "settings");
    var model = (app.services.modelServices.allModels("tts", service)[0] || {}).id || service.model || "";
    var voice = (app.services.modelServices.voices(service, model)[0] || {}).id || service.voice || "";
    var profile = app.services.modelServices.resolveTts(service, { ttsModel: model, ttsVoice: voice }, settings);
    if (!profile.model || profile.type !== "system" && !profile.voice) throw new Error("服务缺少可测试的模型或音色");
    var task = { cancelled: false }, clip = await synthesize("你好", profile, task, false); await disposeClip(clip); return true;
  }

  async function playReady(messageId) {
    var item = ready[messageId]; if (!item) return false;
    delete ready[messageId]; await stop();
    var token = ++generation, owner = { cancelled: false, task: { cancelled: false }, clips: [] }; current = owner; emit({ speaking: true, messageId: messageId });
    try { await playClip(item.clip, owner, token); if (token === generation) await stop(); return true; }
    catch (error) { if (token === generation) await stop(); throw error; }
  }

  function takeSpeechSegments(owner, flush) {
    var limit = Math.min(240, Math.max(80, Number(owner.maxCharacters || 240))), output = [];
    while (owner.textBuffer) {
      var paragraph = owner.textBuffer.search(/\n/), length = paragraph >= 0 ? paragraph + 1 : 0, match;
      if (!length) {
        var stops = /[。！？!?；;]/g;
        while ((match = stops.exec(owner.textBuffer))) { if (match.index + 1 >= 40) { length = match.index + 1; break; } }
      }
      if (!length && owner.textBuffer.length >= limit) {
        var windowText = owner.textBuffer.slice(0, limit), punctuation = Math.max(windowText.lastIndexOf("。"), windowText.lastIndexOf("！"), windowText.lastIndexOf("？"), windowText.lastIndexOf("!"), windowText.lastIndexOf("?"), windowText.lastIndexOf("；"), windowText.lastIndexOf(";"));
        length = punctuation >= Math.floor(limit * 0.55) ? punctuation + 1 : limit;
      }
      if (!length && flush) length = owner.textBuffer.length;
      if (!length) break;
      var part = cleanText(owner.textBuffer.slice(0, length)); owner.textBuffer = owner.textBuffer.slice(length);
      if (part) output.push(part);
    }
    return output;
  }

  function createPcmTextOwner(profile, role, messageId, options, token) {
    var owner = attachPcmPlayer({ cancelled: false, task: { cancelled: false }, clips: [], textBuffer: "", receivedText: "", chain: Promise.resolve(), profile: profile, role: role, messageId: messageId, maxCharacters: app.services.modelServices.modelDefinition("tts", profile, profile.model).maxCharacters || 240 }, token, options);
    async function enqueue(text) {
      if (owner.cancelled || owner.failure || token !== generation) return;
      await streamPcm(text, profile, owner.task, function (bytes, sampleRate) { owner.streamReceived = true; owner.pushPcm(bytes, sampleRate); });
    }
    function append(delta) {
      if (owner.cancelled || !delta) return;
      owner.receivedText += delta; owner.textBuffer += delta;
      takeSpeechSegments(owner, false).forEach(function (part) { owner.chain = owner.chain.then(function () { return enqueue(part); }).catch(function (error) { owner.failure = owner.failure || error; }); });
    }
    async function finish(finalText) {
      if (owner.cancelled) return;
      var finalClean = cleanText(finalText);
      if (finalClean && finalClean.indexOf(owner.receivedText) === 0) append(finalClean.slice(owner.receivedText.length));
      takeSpeechSegments(owner, true).forEach(function (part) { owner.chain = owner.chain.then(function () { return enqueue(part); }).catch(function (error) { owner.failure = owner.failure || error; }); });
      await owner.chain;
      if (owner.failure) { owner.failure.streamReceived = Boolean(owner.streamReceived); owner.failPcm(owner.failure); var failure = owner.failure; await stop(); throw failure; }
      owner.finished = true; await owner.finishPcm();
      if (current === owner) { current = null; emit({ speaking: false, messageId: messageId }); }
    }
    owner.append = append; owner.finish = finish; return owner;
  }

  function createElevenSocketOwner(profile, role, messageId, options, token) {
    if (typeof WebSocket !== "function") throw streamUnavailable("当前 WebView 不支持 ElevenLabs 增量文字连接");
    var owner = attachPcmPlayer({ cancelled: false, task: { cancelled: false }, clips: [], textBuffer: "", receivedText: "", chain: Promise.resolve(), profile: profile, role: role, messageId: messageId, maxCharacters: app.services.modelServices.modelDefinition("tts", profile, profile.model).maxCharacters || 240 }, token, options);
    var v3 = /^eleven_v3(?:_|$)/.test(profile.model || ""), base;
    try { var parsed = new URL(profile.endpoint || "https://api.elevenlabs.io"); base = (parsed.protocol === "http:" ? "ws:" : "wss:") + "//" + parsed.host; } catch (_) { base = "wss://api.elevenlabs.io"; }
    var path = v3 ? "/v1/text-to-dialogue/stream-input" : "/v1/text-to-speech/" + encodeURIComponent(profile.voice || "") + "/stream-input";
    var socket = new WebSocket(base + path + "?model_id=" + encodeURIComponent(profile.model || "") + "&output_format=pcm_24000" + (v3 ? "" : "&auto_mode=true")); owner.socket = socket;
    var readyResolve, readyReject, doneResolve, doneReject, socketFinished = false, socketReady = false;
    var ready = new Promise(function (resolve, reject) { readyResolve = resolve; readyReject = reject; });
    var done = new Promise(function (resolve, reject) { doneResolve = resolve; doneReject = reject; });
    var timer = setTimeout(function () { var error = new Error("ElevenLabs 流式连接超时"); if (!socketReady) readyReject(error); if (!socketFinished) { socketFinished = true; owner.socketTimer = null; doneReject(error); try { socket.close(); } catch (_) {} } }, 90000); owner.socketTimer = timer;
    ready.catch(function () {}); done.catch(function () {});
    function finishSocket(error) { if (socketFinished) return; socketFinished = true; clearTimeout(timer); owner.socketTimer = null; error ? doneReject(error) : doneResolve(); }
    socket.onopen = function () {
      try {
        socket.send(JSON.stringify(v3 ? { voices: [profile.voice], xi_api_key: profile.apiKey } : { text: " ", xi_api_key: profile.apiKey, generation_config: { chunk_length_schedule: [80, 120, 180, 240] } }));
        socketReady = true; readyResolve();
      } catch (error) { readyReject(error); finishSocket(error); }
    };
    socket.onmessage = function (event) {
      var data = app.utils.safeJsonParse(event.data, null); if (!data) return;
      if (data.error || data.type === "error") { var detail = data.error && (data.error.message || data.error) || data.message || "ElevenLabs 流式合成失败"; finishSocket(new Error(app.utils.cleanError(String(detail)))); return; }
      if (data.audio) { var bytes = base64Bytes(data.audio); if (bytes.length) { owner.streamReceived = true; owner.pushPcm(bytes, 24000); } }
      if (data.isFinal || data.is_final || data.type === "final") finishSocket();
    };
    socket.onerror = function () { var error = streamUnavailable("ElevenLabs 流式连接失败"); readyReject(error); finishSocket(error); };
    socket.onclose = function () { var closed = owner.streamReceived ? null : streamUnavailable("ElevenLabs 流式连接在音频返回前关闭"); if (!socketReady) readyReject(closed || streamUnavailable("ElevenLabs 流式连接未建立")); if (!socketFinished) finishSocket(closed); };
    async function sendPart(text) {
      await ready; if (owner.cancelled || token !== generation) return;
      socket.send(JSON.stringify(v3 ? { inputs: [{ text: text, voice_id: profile.voice }] } : { text: text + " ", try_trigger_generation: true }));
    }
    function append(delta) {
      if (owner.cancelled || !delta) return;
      owner.receivedText += delta; owner.textBuffer += delta;
      takeSpeechSegments(owner, false).forEach(function (part) { owner.chain = owner.chain.then(function () { return sendPart(part); }).catch(function (error) { owner.failure = owner.failure || error; }); });
    }
    async function finish(finalText) {
      if (owner.cancelled) return;
      var finalClean = cleanText(finalText); if (finalClean && finalClean.indexOf(owner.receivedText) === 0) append(finalClean.slice(owner.receivedText.length));
      takeSpeechSegments(owner, true).forEach(function (part) { owner.chain = owner.chain.then(function () { return sendPart(part); }).catch(function (error) { owner.failure = owner.failure || error; }); });
      try {
        await owner.chain; if (owner.failure) throw owner.failure; await ready;
        if (v3) socket.send(JSON.stringify({ close_socket: true }));
        else socket.send(JSON.stringify({ text: "", flush: true }));
        await done; owner.finished = true; await owner.finishPcm();
        if (owner.socket) { owner.socket.onopen = null; owner.socket.onmessage = null; owner.socket.onerror = null; owner.socket.onclose = null; try { owner.socket.close(); } catch (_) {} owner.socket = null; }
        if (current === owner) { current = null; emit({ speaking: false, messageId: messageId }); }
      } catch (error) {
        error.streamReceived = Boolean(owner.streamReceived); await stopOwner(owner); throw error;
      }
    }
    owner.append = append; owner.finish = finish; return owner;
  }

  async function createStream(role, messageId, options) {
    await stop();
    var resolved = await profileFor(role), capabilities = app.services.modelServices.ttsCapabilities(resolved.service, resolved.profile.model);
    if (resolved.profile.type === "system" || !capabilities.audioStreaming || !pcmStreamProfile(resolved.profile) || !playbackUnlocked || !audioContext) return null;
    var token = ++generation, owner;
    if ((resolved.profile.protocol === "elevenlabs" || resolved.profile.type === "elevenlabs") && capabilities.textStreaming) {
      try { owner = createElevenSocketOwner(resolved.profile, role, messageId, options || {}, token); }
      catch (error) { if (!error.streamUnavailable) throw error; owner = createPcmTextOwner(resolved.profile, role, messageId, options || {}, token); }
    } else owner = createPcmTextOwner(resolved.profile, role, messageId, options || {}, token);
    current = owner;
    emit({ speaking: false, buffering: true, messageId: messageId, bufferedSeconds: 0 }); return owner;
  }

  async function resume(messageId) {
    if (!current || current.messageId !== messageId || !current.starved || !(current.clips && current.clips.length || current.pcmQueue && current.pcmQueue.length)) return false;
    await current.resume(); return true;
  }

  function hasReady(messageId) { return Boolean(ready[messageId]); }
  function canResume(messageId) { return Boolean(current && current.messageId === messageId && current.starved && (current.clips && current.clips.length || current.pcmQueue && current.pcmQueue.length)); }

  if (typeof window.addEventListener === "function") {
    window.addEventListener("pointerdown", unlockPlayback, true);
    window.addEventListener("touchstart", unlockPlayback, true);
    window.addEventListener("keydown", unlockPlayback, true);
  }

  app.services.tts = { speak: speak, stop: stop, headers: headers, requestBody: requestBody, parseDoubaoSse: parseDoubaoSse, prepare: prepare, testService: testService, playReady: playReady, hasReady: hasReady, createStream: createStream, resume: resume, canResume: canResume, unlockPlayback: unlockPlayback, setMuted: setMuted, isMuted: function () { return muted; }, isPlaying: function () { return Boolean(lastState.speaking); } };
})(window.chataxi);
