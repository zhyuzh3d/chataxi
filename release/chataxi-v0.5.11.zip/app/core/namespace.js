(function (global) {
  "use strict";
  global.chataxi = global.chataxi || {};
  global.chataxi.version = "0.5.11";
  global.chataxi.state = { route: "conversations", activeConversationId: null, modelsTab: "llm" };
})(window);
