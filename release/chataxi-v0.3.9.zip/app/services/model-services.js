(function (app) {
  "use strict";
  var catalog = app.services.catalog;

  function families(kind) {
    return catalog[kind === "llm" ? "llmFamilies" : kind === "tts" ? "ttsFamilies" : "asrFamilies"];
  }

  function family(kind, id) {
    return families(kind).find(function (item) { return item.id === id; }) || families(kind).find(function (item) { return item.id === "custom"; });
  }

  function uniqueModels(items) {
    var seen = {};
    return (items || []).map(function (item) {
      return typeof item === "string" ? { id: item, name: item } : item;
    }).filter(function (item) {
      if (!item || !item.id || seen[item.id]) return false;
      seen[item.id] = true;
      return true;
    });
  }

  function allModels(kind, service) {
    var definition = family(kind, service && (service.family || service.type));
    var stored = service && service.models || [];
    var legacy = service && service.model ? [{ id: service.model, name: service.model }] : [];
    var source = service && service.modelsDiscovered ? stored.concat(legacy) : stored.concat(definition.models || [], legacy);
    return uniqueModels(source).map(function (item) {
      var known = (definition.models || []).find(function (entry) { return entry.id === item.id; });
      return Object.assign({}, known || {}, item);
    });
  }

  function models(kind, service) {
    var result = allModels(kind, service);
    if (!service || !Array.isArray(service.enabledModelIds)) return result;
    return result.filter(function (item) { return service.enabledModelIds.indexOf(item.id) >= 0; });
  }

  function voices(service) {
    var definition = family("tts", service && (service.family || service.type));
    var stored = service && service.voices || [];
    var legacy = service && service.voice ? [{ id: service.voice, name: service.voice }] : [];
    return uniqueModels(stored.concat((definition.voices || []).map(function (name) { return { id: name, name: name }; }), legacy));
  }

  function serviceStatus(kind, service) {
    if (!service) return "服务不存在";
    if (service.enabled === false) return "已停用";
    var definition = family(kind, service.family || service.type);
    if (definition.type === "system") return "";
    if (!service.endpoint && !definition.endpoint) return "缺少服务地址";
    if (!definition.keyOptional && !service.apiKey) return "缺少 API Key";
    return "";
  }

  function resolveLlm(service, role) {
    var definition = family("llm", service.family || service.type);
    return Object.assign({}, service, {
      family: definition.id,
      apiStyle: service.apiStyle || definition.apiStyle,
      endpoint: service.endpoint || definition.endpoint,
      model: role.model || service.model || (models("llm", service)[0] || {}).id || "",
      temperature: role.temperature == null ? (service.temperature == null ? "" : service.temperature) : role.temperature,
      maxOutputTokens: Number(role.maxOutputTokens || service.maxOutputTokens || 4096),
      reasoningEffort: role.reasoningEffort || service.reasoningEffort || "",
      allowImageGeneration: Boolean(role.allowImageGeneration)
    });
  }

  function resolveTts(service, role, settings) {
    var definition = family("tts", service.family || service.type);
    return Object.assign({}, service, {
      family: definition.id,
      type: service.type || definition.type,
      endpoint: service.endpoint || definition.endpoint,
      model: role && role.ttsModel || service.model || (models("tts", service)[0] || {}).id || "system",
      voice: role && role.ttsVoice || service.voice || (voices(service)[0] || {}).id || "",
      instructions: role && role.voicePrompt || "",
      language: role && role.ttsLanguage || service.language || settings.language || "zh-CN",
      rate: role && role.ttsRate || service.rate || 1,
      pitch: role && role.ttsPitch || service.pitch || 1
    });
  }

  function resolveAsr(service, conversation, settings) {
    var definition = family("asr", service.family || service.type);
    return Object.assign({}, service, {
      family: definition.id,
      type: service.type || definition.type,
      endpoint: service.endpoint || definition.endpoint,
      model: conversation && conversation.asrModel || service.model || (models("asr", service)[0] || {}).id || "system",
      language: conversation && conversation.asrLanguage || service.language || settings.language || "zh-CN"
    });
  }

  function authHeaders(kind, service) {
    var definition = family(kind, service.family || service.type);
    var key = service.apiKey || "";
    if (definition.id === "anthropic") return key ? { "x-api-key": key, "anthropic-version": "2023-06-01" } : { "anthropic-version": "2023-06-01" };
    if (definition.id === "gemini") return key ? { "x-goog-api-key": key } : {};
    if (definition.id === "elevenlabs") return key ? { "xi-api-key": key } : {};
    return key ? { Authorization: "Bearer " + key } : {};
  }

  function discoveryUrl(kind, service) {
    var definition = family(kind, service && (service.family || service.type));
    if (kind === "tts") return definition.voicesEndpoint || "";
    if (definition.modelsEndpoint) return definition.modelsEndpoint;
    if (kind !== "llm" || !service || !service.endpoint) return "";
    try {
      var url = new URL(service.endpoint);
      if (!/\/v\d+(?:beta)?\/(?:responses|chat\/completions|messages)\/?$/i.test(url.pathname)) return "";
      url.pathname = url.pathname.replace(/(?:responses|chat\/completions|messages)\/?$/i, "models"); url.search = ""; url.hash = ""; return url.toString();
    } catch (_) { return ""; }
  }

  function discoveredModel(item, definition) {
    var id = String(item.id || item.baseModelId || item.name || "").replace(/^models\//, "");
    var parameters = item.supported_parameters || item.supportedParameters || (item.capabilities && item.capabilities.parameters) || [];
    var next = { id: id, name: item.displayName || item.display_name || id, supportedParameters: Array.isArray(parameters) ? parameters.map(String) : [] };
    if (Array.isArray(parameters) && parameters.length) {
      next.temperature = parameters.indexOf("temperature") >= 0;
      next.imageInput = parameters.some(function (value) { return /image.*input|vision/i.test(value); });
      next.imageGeneration = parameters.some(function (value) { return /image.*generation/i.test(value); });
    }
    var inputModalities = item.input_modalities || item.inputModalities;
    var outputModalities = item.output_modalities || item.outputModalities;
    if (Array.isArray(inputModalities)) next.imageInput = inputModalities.some(function (value) { return String(value).toLowerCase() === "image"; });
    if (Array.isArray(outputModalities)) next.imageGeneration = outputModalities.some(function (value) { return String(value).toLowerCase() === "image"; });
    var contextLength = Number(item.context_length || item.contextLength || 0); if (contextLength > 0) next.contextLength = contextLength;
    var max = Number(item.max_output_tokens || item.maxOutputTokens || 0); if (max > 0) next.maxOutputTokens = max;
    var efforts = item.reasoning_efforts || item.reasoningEfforts; if (Array.isArray(efforts)) next.reasoning = efforts.map(String);
    var known = (definition.models || []).find(function (entry) { return entry.id === id; });
    return Object.assign({}, known || {}, next);
  }

  async function discover(kind, service, options) {
    var definition = family(kind, service.family || service.type);
    var url = discoveryUrl(kind, service);
    if (!url) return { models: allModels(kind, service), voices: voices(service), discovered: false };
    var result = await app.platform.network.requestJson({ url: url, method: "GET", headers: authHeaders(kind, service), timeoutMs: 45000 });
    if (kind === "tts") {
      var accountVoices = (result.data.voices || []).map(function (item) { return { id: item.voice_id || item.id, name: item.name || item.voice_id || item.id }; });
      service.voices = uniqueModels(accountVoices);
    } else {
      var raw = Array.isArray(result.data) ? result.data : result.data.data || result.data.models || result.data.items || [];
      var discovered = raw.filter(function (item) {
        if (definition.id === "gemini") return !item.supportedGenerationMethods || item.supportedGenerationMethods.indexOf("generateContent") >= 0;
        return true;
      }).map(function (item) { return discoveredModel(item, definition); }).filter(function (item) { return item.id; });
      service.models = uniqueModels(discovered);
      service.modelsDiscovered = true;
    }
    service.discoveredAt = Date.now();
    if (!options || options.persist !== false) await app.data.store.put(kind + "-profiles", service.id, service);
    return { models: allModels(kind, service), voices: voices(service), discovered: true };
  }

  function modelDefinition(kind, service, modelId) {
    var definition = family(kind, service && (service.family || service.type));
    var listed = allModels(kind, service).find(function (item) { return item.id === modelId; });
    var known = (definition.models || []).find(function (item) { return item.id === modelId; });
    return Object.assign({ id: modelId, name: modelId, maxOutputTokens: 8192, temperature: false, reasoning: [], imageInput: false, imageGeneration: false, voicePrompt: false, supportedParameters: [] }, known || {}, listed || {});
  }

  function parameterProfile(kind, service) {
    var list = allModels(kind, service).map(function (item) { return modelDefinition(kind, service, item.id); });
    var names = list.map(function (item) {
      var result = (item.supportedParameters || []).slice();
      if (item.temperature !== false && result.indexOf("temperature") < 0) result.push("temperature");
      if (item.maxOutputTokens && result.indexOf("max_output_tokens") < 0) result.push("max_output_tokens");
      if ((item.reasoning || []).length && result.indexOf("reasoning_effort") < 0) result.push("reasoning_effort");
      if (item.imageInput && result.indexOf("image_input") < 0) result.push("image_input");
      if (item.imageGeneration && result.indexOf("image_generation") < 0) result.push("image_generation");
      return result;
    });
    var common = names.length ? names[0].filter(function (name) { return names.every(function (values) { return values.indexOf(name) >= 0; }); }) : [];
    return { common: common, models: list.map(function (item, index) { return { id: item.id, parameters: names[index], special: names[index].filter(function (name) { return common.indexOf(name) < 0; }) }; }) };
  }

  app.services.modelServices = {
    families: families,
    family: family,
    allModels: allModels,
    models: models,
    voices: voices,
    serviceStatus: serviceStatus,
    resolveLlm: resolveLlm,
    resolveTts: resolveTts,
    resolveAsr: resolveAsr,
    discoveryUrl: discoveryUrl,
    discover: discover,
    modelDefinition: modelDefinition,
    parameterProfile: parameterProfile
  };
})(window.chataxi);
