(function (app) {
  "use strict";

  function model(id, name, options) {
    return Object.assign({ id: id, name: name, maxOutputTokens: 8192, temperature: true, reasoning: [], imageInput: true, imageGeneration: false }, options || {});
  }

  var llmFamilies = [
    { id: "llmserver", name: "llmserver", description: "局域网统一网关", apiStyle: "openai-responses", endpoint: "http://192.168.1.2:4815/v1/responses", customEndpoint: true, editableProtocol: true, keyOptional: true, models: [] },
    {
      id: "openai", name: "OpenAI", description: "Responses API", apiStyle: "openai-responses",
      endpoint: "https://api.openai.com/v1/responses", modelsEndpoint: "https://api.openai.com/v1/models",
      models: [
        model("gpt-5.1", "GPT-5.1", { reasoning: ["none", "low", "medium", "high"], imageGeneration: true, temperature: false, maxOutputTokens: 32768 }),
        model("gpt-5", "GPT-5", { reasoning: ["none", "low", "medium", "high"], imageGeneration: true, temperature: false, maxOutputTokens: 32768 }),
        model("gpt-5-mini", "GPT-5 mini", { reasoning: ["none", "low", "medium", "high"], imageGeneration: true, temperature: false, maxOutputTokens: 16384 }),
        model("gpt-4.1", "GPT-4.1", { imageGeneration: true, maxOutputTokens: 32768 })
      ]
    },
    {
      id: "deepseek", name: "DeepSeek", description: "DeepSeek 官方 API", apiStyle: "openai-chat",
      endpoint: "https://api.deepseek.com/chat/completions", modelsEndpoint: "https://api.deepseek.com/models",
      models: [
        model("deepseek-v4-flash", "DeepSeek V4 Flash", { maxOutputTokens: 32768 }),
        model("deepseek-v4-pro", "DeepSeek V4 Pro", { maxOutputTokens: 32768 }),
        model("deepseek-v4-flash-vision-exp", "DeepSeek V4 Flash Vision", { maxOutputTokens: 32768 })
      ]
    },
    { id: "anthropic", name: "Anthropic Claude", description: "Claude Messages API", apiStyle: "anthropic-messages", endpoint: "https://api.anthropic.com/v1/messages", modelsEndpoint: "https://api.anthropic.com/v1/models", models: [] },
    {
      id: "gemini", name: "Google Gemini", description: "Gemini GenerateContent", apiStyle: "gemini-generate-content",
      endpoint: "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent", modelsEndpoint: "https://generativelanguage.googleapis.com/v1beta/models",
      models: [
        model("gemini-3.8-flash", "Gemini 3.8 Flash", { reasoning: ["low", "medium", "high"], maxOutputTokens: 32768 }),
        model("gemini-3.1-pro-preview", "Gemini 3.1 Pro Preview", { reasoning: ["low", "medium", "high"], maxOutputTokens: 32768 }),
        model("gemini-3.5-flash-lite", "Gemini 3.5 Flash-Lite", { maxOutputTokens: 16384 })
      ]
    },
    { id: "xai", name: "xAI / Grok", description: "OpenAI 兼容接口", apiStyle: "openai-chat", endpoint: "https://api.x.ai/v1/chat/completions", modelsEndpoint: "https://api.x.ai/v1/language-models", models: [] },
    { id: "kimi", name: "Kimi / Moonshot", description: "OpenAI 兼容接口", apiStyle: "openai-chat", endpoint: "https://api.moonshot.cn/v1/chat/completions", modelsEndpoint: "https://api.moonshot.cn/v1/models", models: [] },
    { id: "glm", name: "GLM / 智谱", description: "OpenAI 兼容接口", apiStyle: "openai-chat", endpoint: "https://open.bigmodel.cn/api/paas/v4/chat/completions", modelsEndpoint: "https://open.bigmodel.cn/api/paas/v4/models", models: [] },
    { id: "custom", name: "自定义兼容服务", description: "自托管或其他供应商", apiStyle: "openai-responses", endpoint: "", customEndpoint: true, editableProtocol: true, keyOptional: true, models: [] }
  ];

  var ttsFamilies = [
    { id: "system", name: "Android 系统朗读", description: "使用设备安装的语音引擎", type: "system", models: [{ id: "system", name: "系统语音引擎" }], voices: [] },
    {
      id: "openai", name: "OpenAI TTS", description: "OpenAI 音频语音接口", type: "openai", endpoint: "https://api.openai.com/v1/audio/speech",
      models: [
        { id: "gpt-4o-mini-tts", name: "GPT-4o mini TTS", voicePrompt: true },
        { id: "tts-1", name: "TTS-1", voicePrompt: false },
        { id: "tts-1-hd", name: "TTS-1 HD", voicePrompt: false }
      ],
      voices: ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer", "verse"]
    },
    {
      id: "elevenlabs", name: "ElevenLabs", description: "从账户读取可用音色", type: "elevenlabs",
      endpoint: "https://api.elevenlabs.io/v1/text-to-speech/{voice}", voicesEndpoint: "https://api.elevenlabs.io/v2/voices",
      models: [
        { id: "eleven_multilingual_v2", name: "Eleven Multilingual v2", voicePrompt: false },
        { id: "eleven_flash_v2_5", name: "Eleven Flash v2.5", voicePrompt: false }
      ],
      voices: []
    },
    { id: "custom", name: "自定义 TTS", description: "OpenAI 风格 JSON 接口", type: "custom", endpoint: "", customEndpoint: true, keyOptional: true, models: [], voices: [] }
  ];

  var asrFamilies = [
    { id: "system", name: "Android 系统语音识别", description: "默认使用设备提供的识别服务", type: "system", models: [{ id: "system", name: "系统语音识别" }] },
    {
      id: "openai", name: "OpenAI 语音识别", description: "上传短音频进行识别", type: "openai", endpoint: "https://api.openai.com/v1/audio/transcriptions",
      models: [
        { id: "gpt-4o-transcribe", name: "GPT-4o Transcribe" },
        { id: "gpt-4o-mini-transcribe", name: "GPT-4o mini Transcribe" },
        { id: "whisper-1", name: "Whisper" }
      ]
    },
    { id: "custom", name: "自定义语音识别", description: "OpenAI 风格 multipart 接口", type: "custom", endpoint: "", customEndpoint: true, keyOptional: true, models: [] }
  ];

  app.services = app.services || {};
  app.services.catalog = {
    llmFamilies: llmFamilies,
    ttsFamilies: ttsFamilies,
    asrFamilies: asrFamilies,
    apiStyles: [
      { id: "openai-responses", name: "OpenAI Responses" },
      { id: "openai-chat", name: "OpenAI Chat Completions" },
      { id: "anthropic-messages", name: "Anthropic Messages" },
      { id: "gemini-generate-content", name: "Gemini GenerateContent" }
    ]
  };
})(window.chataxi);
